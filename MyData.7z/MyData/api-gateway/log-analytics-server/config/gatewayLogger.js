import winston from 'winston';

// define the custom settings for each transport (file, console)
const loggerOptions = {
  file: {
    level: process.env.LOGGER_LEVEL,
    filename: process.env.LOGGER_FILE_PATH,
    handleExceptions: true,
    maxsize: 5242880, // 5MB
    maxFiles: 5,
    colorize: false,
    format: winston.format.combine(
      winston.format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss'
      }),
      winston.format.json()
    )
  }
};

// instantiate a new Winston Logger with the settings defined above
const gatewayLogger = new winston.createLogger({
  transports: [
    new winston.transports.File(loggerOptions.file)
  ],
  exitOnError: false // do not exit on handled exceptions
});

// create a stream object with a 'write' function that will be used by `morgan`
gatewayLogger.stream = {
  write: function(message) {

    //Log the request's basic information to the info level log
    gatewayLogger.info(message);
  }
};

export default gatewayLogger;
