import gatewayLogger from '../../config/gatewayLogger';
import sseGlobalConfig from '../globals/sseGlobalConfig';

//TODO handle connection closure and reconnection by UI.
export default class SseConnectionCreator {
  constructor(router, path) {
    this.router = router;
    this.path = path;
    this.responseReady = null;
    this.routeSetupCompleted = false;
  }

  /**
   * This method will set up the route and handle the first connection
   * that is received from the UI. This method will save the initialized connection
   * in the global sseConfig object against the route on which the server is listening
   * @param method indicates the HTTP method that must be used to connect to the listener in the UI
   */
  initializeConnection(method = 'GET') {
    if(!this.routeSetupCompleted) {

      //Save the current instance so that it can be pulled from anywhere.
      sseGlobalConfig.sseConnections[this.path] = this;
      this.routeSetupCompleted = true;
      switch(method) {
        case 'GET':
          this.router.get(this.path, (req, res) => {

            //Save the response object for further use. Existence signifies that the route is ready.
            this.responseReady = res;
            this.responseReady.status(200).set({
              'Content-Type': 'text/event-stream',
              'Cache-Control': 'no-cache',
              'Connection': 'keep-alive'
            });
          });
          break;
        default:

          //default value of GET already provided hence this case is not possible.
          break;
      }
    } else {
      gatewayLogger.info(
        'SSE connection: Connection for path: '+
        this.path + ' already established'
      );
    }
  }

  /**
   * This method will send the message to the listener in the UI.
   * If this is called before the responseReady is set then it will throw
   * an error indicating that connection has not yet been established.
   * @param message the message that must be sent
   */
  sendMessage(message) {
    if(this.responseReady) {
      let messageToSend = message;

      //TODO add more validations
      if(typeof message !== "string") {
        messageToSend = JSON.stringify(message);
      }

      this.responseReady.write(`data: ${messageToSend}\n\n`);
    } else {
      throw "Connection not yet established";
    }
  }

  /**
   * This method will end the connection to the listener in the UI.
   * If this is called before the responseReady is set then it will throw
   * an error indicating that connection has not yet been established.
   * @param message the message that must be sent
   */
  closeConnection() {
    if(this.responseReady) {
      this.responseReady.end();
      this.responseReady = null;
      //TODO check later in case of recon whether the route setup needs to be repeated or not.
    } else {
      throw "Connection not yet established";
    }
  }
};