import {
  validateRequest,
  sendUnauthorizedResponse,
  sendServerNotReadyResponse,
  createChannelAndPublishMessage,
  channelStatusCallback
} from '../../utils/utility-functions';
import globalProperties from '../../globals/globalProperties';
import sseGlobalConfig from '../../globals/sseGlobalConfig';
import gatewayLogger from '../../../config/gatewayLogger';
import TrainTestModel from '../models/TrainTestModel';
import PerformanceMetrics from '../models/PerformanceMetrics';
import SupportedMethods from '../models/SupportedMethods';
import uuidv4 from 'uuid/v4';
import notificationManager from '../../globals/notificationManager';
import {
  TRAIN_TEST_ROUTE,

  ASYNC_TASK_COMPLETE,
  ASYNC_TASK_FAILED
} from '../../utils/constants';
import SseConnectionCreator from '../../server-sent-event-connection/SseConnectionCreator';
import {createTaskPollUri} from '../../utils/utility-functions';
import TaskModel from '../../task-processing/models/TaskModel';
import {persistToDb} from '../../task-processing/task-helper';

export default function logAnalyserRouter(mlRouter) {

  let connectionInstance, properties, channelName, queueName;

  //Add authentication middleware for this route
  mlRouter.use((req, res, next) => {
    if(validateRequest(req)) {
      next();
    } else {
      sendUnauthorizedResponse(res);
    }
  });

  //Proceed only if the desired connection exists
  mlRouter.use((req, res, next) => {
    ({connectionInstance, properties} = globalProperties.gProductConfig.connection[0]);
    const logAnalyzerChannelProps = properties.channelProperties[1];
    channelName = logAnalyzerChannelProps.channelName;
    queueName = logAnalyzerChannelProps.queuesToBind[1];
    if(connectionInstance) {
      next();
    } else {
      sendServerNotReadyResponse(res);
    }
  });

  mlRouter.get('/supported-methods', (req,res) => {
    const taskId = uuidv4();
    const command = SupportedMethods.prototype.command;
    createChannelAndPublishMessage(connectionInstance, channelName, queueName,
      { productID: req.get('Product-Id'), taskId, command },
      channelStatusCallback(channelName)).then( () => {
        notificationManager.subscribe(taskId, command).onNotification(function(message, commandForNotification) {
          gatewayLogger.debug(`received notification for taskId: ${taskId} and command: ${commandForNotification}`);
          res.status(200);
          res.json(new SupportedMethods(message));
          notificationManager.unsubscribe(taskId, this, commandForNotification);
        });
      }).catch( error => {
        res.status(500);
        res.json({
          error
        });
      });

  });

  mlRouter.get('/performance-metrics', (req,res) => {
    const taskId = uuidv4();
    const command = PerformanceMetrics.prototype.command;
    createChannelAndPublishMessage(connectionInstance, channelName, queueName,
      { productID: req.get('Product-Id'), taskId, command },
      channelStatusCallback(channelName)).then( () => {
        notificationManager.subscribe(taskId, command).onNotification(function(message, commandForNotification) {
          gatewayLogger.debug(`received notification for taskId: ${taskId} and command: ${commandForNotification}`);
          res.status(200);
          res.json(new PerformanceMetrics(message));
          notificationManager.unsubscribe(taskId, this, commandForNotification);
        });
      }).catch( error => {
        res.status(500);
        res.json({
          error
        });
      });
  });

  mlRouter.post('/train-test-model', (req,res) => {
    const taskId = uuidv4();
    const trainTest = new TrainTestModel(req.get('Product-Id'), req.body.packagesName,
      req.body.isTrain, req.body.isHyperParameterTuning, req.body.mlPreprocessingMethods,
      req.body.wordEmbeddingType, req.body.wordEmbeddingParameters,
      req.body.algorithmName, req.body.alogrithmParameters,
      req.body.modelValidationMethods, req.body.actionFlag,
      req.body.trainFolderPath, req.body.testFolderPath
    );

    persistToDb(new TaskModel({
      _id: taskId,
      commandProperties: {
        command: 'TRAIN_TEST_STATUS',
        channelName,
        queueName
      }
    })).then(() => {
      createChannelAndPublishMessage(connectionInstance, channelName, queueName,
        { ...trainTest, taskId, command: trainTest.command },
        channelStatusCallback(channelName)).then(() => {

          //Subscribe to the notification and send the response through SSE
          notificationManager.subscribe(taskId, TrainTestModel.prototype.command)
            .onNotification(function (message, commandForNotification) {
              gatewayLogger.debug(`received notification for taskId: ${taskId} and command: ${commandForNotification}`);

              try {
                sseGlobalConfig.sseConnections[TRAIN_TEST_ROUTE].sendMessage(message);
              } catch (error) {
                gatewayLogger.warn(`SSE for taskId: ${taskId} and command: ${commandForNotification} could not be sent, reason: ${error}`);
              }

              if (message.status === ASYNC_TASK_COMPLETE || message.status === ASYNC_TASK_FAILED) {
                notificationManager.unsubscribe(taskId, this, commandForNotification);
              }
            });

          res.status(202);
          res.json({
            taskId,
            pollUri: createTaskPollUri(taskId)
          });
        }).catch(error => {

          TaskModel.findByIdAndDelete(taskId).exec();
          res.status(500);
          res.json({
            error
          });
        });
    }).catch(error => {
      res.status(500);
      res.json({
        error
      });
    });
  });

  new SseConnectionCreator(mlRouter, TRAIN_TEST_ROUTE).initializeConnection();

  return mlRouter;
}
