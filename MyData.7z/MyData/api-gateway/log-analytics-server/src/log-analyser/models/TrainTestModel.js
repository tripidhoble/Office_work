export default function TrainTestModel(productID, packagesName, isTrain, isHyperParameterTuning,
  mlPreprocessingMethods, wordEmbeddingType, wordEmbeddingParameters,
  algorithmName, alogrithmParameters, modelValidationMethods,
  actionFlag, trainFolderPath, testFolderPath) {

  this.productID = productID;
  this.packagesName = packagesName;
  this.isTrain = isTrain;
  this.isHyperParameterTuning = isHyperParameterTuning;
  this.mlPreprocessingMethods = mlPreprocessingMethods;
  this.wordEmbeddingType = wordEmbeddingType;
  this.wordEmbeddingParameters = wordEmbeddingParameters;
  this.algorithmName = algorithmName;
  this.alogrithmParameters = alogrithmParameters;
  this.modelValidationMethods = modelValidationMethods;
  this.actionFlag = actionFlag;
  this.train_csv_path = trainFolderPath;
  this.test_csv_path = testFolderPath;
}

Object.defineProperty(TrainTestModel.prototype, 'command', {
  value: 'TRAIN_TEST_DATA',
  writable: false,
  configurable: false,
  enumerable: false
});
