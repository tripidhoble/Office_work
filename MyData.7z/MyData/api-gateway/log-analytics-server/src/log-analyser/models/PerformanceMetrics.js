export default function PerformanceMetrics(message) {
  this.performanceMetrics = message['PERFORMANCE_METRICS'];
};

Object.defineProperty(PerformanceMetrics.prototype, 'command', {
  value: 'PERFORMANCE_METRICS',
  writable: false,
  configurable: false,
  enumerable: false
});
