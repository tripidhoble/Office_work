export default function SupportedMethods(message) {
  this.wordEmbeddingMethod = message['WORDEMBEDDING_METHODS'];
  this.mlPrePRocessingMethods = message['ML_PREPROCESSING_METHODS'];
  this.mlPackages = message['PACKAGES'];
}

Object.defineProperty(SupportedMethods.prototype, 'command', {
  value: 'SUPPORTED_METHODS',
  writable: false,
  configurable: false,
  enumerable: false
});
