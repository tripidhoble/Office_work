export default function CommitActiveMLModel(productId, trainModelId) {
  this.productID = productId;
  this.trainModelID = trainModelId;
}

Object.defineProperty(CommitActiveMLModel.prototype, 'command', {
  value: 'COMMIT_ML_MODEL',
  writable: false,
  configurable: false,
  enumerable: false
});
