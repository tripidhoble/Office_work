export default function CommitActiveFilterModel(productId, filterModelId) {
  this.productID = productId;
  this.model_no = filterModelId;
}

Object.defineProperty(CommitActiveFilterModel.prototype, 'command', {
  value: 'COMMIT_FILTER_MODEL',
  writable: false,
  configurable: false,
  enumerable: false
});
