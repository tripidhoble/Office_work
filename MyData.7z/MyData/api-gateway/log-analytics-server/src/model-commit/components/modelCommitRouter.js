import {
  validateRequest,
  sendUnauthorizedResponse,
  sendServerNotReadyResponse,
  createChannelAndPublishMessage,
  channelStatusCallback
} from '../../utils/utility-functions';
import globalProperties from '../../globals/globalProperties';
import CommitActiveMLModel from '../models/CommitActiveMLModel';
import CommitActiveFilterModel from '../models/CommitActiveFilterModel';
import MultipleMessageHandler from '../../utils/MultipleMessageHandler';
import uuidv4 from 'uuid/v4';

export default function modelCommitRouter(configRouter) {

  let connectionInstance, properties, logAnalyzerChannelName, logAnalyzerQueueName,
    dataProcessChannelName, dataProcessQueueName;

  //Add authentication middleware for this route
  configRouter.use((req, res, next) => {
    if(validateRequest(req)) {
      next();
    } else {
      sendUnauthorizedResponse(res);
    }
  });

  //Proceed only if the desired connection exists
  configRouter.use((req, res, next) => {
    ({connectionInstance, properties} = globalProperties.gProductConfig.connection[0]);
    const logAnalyzerChannelProps = properties.channelProperties[1];
    logAnalyzerChannelName = logAnalyzerChannelProps.channelName;
    logAnalyzerQueueName = logAnalyzerChannelProps.queuesToBind[1];

    const dataProcessChannelProps = properties.channelProperties[0];
    dataProcessChannelName = dataProcessChannelProps.channelName;
    dataProcessQueueName = dataProcessChannelProps.queuesToBind[1];
    if(connectionInstance) {
      next();
    } else {
      sendServerNotReadyResponse(res);
    }
  });

  configRouter.post('/commit', (req,res) => {
    const taskId = uuidv4();
    const mlCommit = new CommitActiveMLModel(req.get('Product-Id'), req.body.trainModelID);
    const dpCommit = new CommitActiveFilterModel(req.get('Product-Id'),
      req.body.filterModelID);

    const multipleMessageHandler = new MultipleMessageHandler();

    multipleMessageHandler.addMessages(createChannelAndPublishMessage(connectionInstance,
      logAnalyzerChannelName, logAnalyzerQueueName, {...mlCommit, taskId, command: mlCommit.command},
      channelStatusCallback(logAnalyzerChannelName)));
    multipleMessageHandler.addMessages(createChannelAndPublishMessage(connectionInstance,
      dataProcessChannelName, dataProcessQueueName, {...dpCommit, taskId, command: dpCommit.command},
      channelStatusCallback(dataProcessChannelName)));

    multipleMessageHandler.executeMessages().then( () => {
      res.status(202);
      res.json();
    }).catch( messageFailedReasons => {
      res.status(500);
      res.json({
        failures: messageFailedReasons
      });
    });
  });

  return configRouter;
}
