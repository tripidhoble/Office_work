import bodyParser from 'body-parser';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import gatewayLogger from '../config/gatewayLogger';
import globalProperties from './globals/globalProperties';
import dataPreProcessingRouter from './data-pre-processing/components/dataPreProcessingRouter';
import logAnalyserRouter from './log-analyser/components/logAnalyserRouter';
import modelConfigRouter from './model-config/components/modelConfigRouter';
import modelCommitRouter from './model-commit/components/modelCommitRouter';
import taskProcessingRouter from './task-processing/components/taskProcessingRouter';
import mongoose from 'mongoose';

import createUiStore from './render-ui/createUiStore';
import React from 'react';
import {Provider} from 'react-redux';
import {renderToString} from 'react-dom/server';
import {StaticRouter, Route } from 'react-router-dom';
import App from '../../log-analytics-gui/src/js/components/App';
import createConnection from './mircoservice-connect/createConnection';

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

/*
  Use the helmet middleware to add the necessary headers
  Use it before processing any requests so that the headers are applied to each response.
*/
app.use(helmet());

/*
  Combined is a standard logging type for morgan.
  Morgan is used to log all HTTP requests. Pass it the logger stream
  so that all the logs are written to the logger file
*/
app.use(morgan('combined', { stream: gatewayLogger.stream }));

//Will render all static files such as css, js, html. Use before any other route is hit.
app.use(express.static('lib'));

app.use('/api/data-pre-processing', dataPreProcessingRouter(express.Router()));
app.use('/api/log-analyser', logAnalyserRouter(express.Router()));
app.use('/api/model-config', modelConfigRouter(express.Router()));
app.use('/api/model-commit', modelCommitRouter(express.Router()));
app.use('/api/task-processing', taskProcessingRouter(express.Router()));

//Once all the processing is done let the server listen for all browser requests.
app.get('*', (req, res) => {
  const store = createUiStore(req);
  const markup = renderToString(
    <Provider store={store}>
      <StaticRouter location={req.url} context={{}}>
        <Route path='/' component={App} />
      </StaticRouter>
    </Provider>
  );

  res.send(require('./render-ui/HtmlContent')(markup,store.getState()));
});

const {databaseProperties} = globalProperties.gProductConfig;
const dbConnectionUrl = `${databaseProperties.dbUrl}/${databaseProperties.dbName}`;
mongoose.connect(dbConnectionUrl, {useNewUrlParser: true, useUnifiedTopology: true});
const mongoConnection = mongoose.connection;
mongoConnection.on('error', function(error) {
  //TODO handle the error and shut down the server.
  gatewayLogger.error("mongodb connection stopped: " + error);
});

mongoConnection.once('open', function() {
  gatewayLogger.info(`Mongo db connected on ${dbConnectionUrl}` );

  //Start the server once the db has been connected.
  const port = process.env.PORT || 8000;
  app.listen(port, function() {
    gatewayLogger.info(`Express server listening on port ${port}` );

    createConnection();
  });
});
