'use strict';

/**
    Render all of the data required by the client for the campaigns
    because all of the data is pulled from one GET call only
**/
const setInitialStateOfProduct = function(_) {
    return {
        randomDataLoadSuccess: {success: true},
        randomDataLoadFailure : {success: false}
    };
};

export const getProductRoutes = function() {
    return [
        {
            path: '/',
            setInitialState: setInitialStateOfProduct,
            reducerKey:'module1'
        },
        {
            path: '/about-us',
            setInitialState: setInitialStateOfProduct,
            reducerKey:'module1'
        }
    ];
};