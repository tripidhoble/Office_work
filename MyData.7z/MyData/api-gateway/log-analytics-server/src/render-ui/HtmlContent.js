module.exports = function (reactContent,preloadedState) {
	return (`<!DOCTYPE html>
		<html lang="en">
			<head>
				<meta name="viewport" content="width=device-width" />
                <link rel="apple-touch-icon" sizes="180x180" href="/favico/apple-touch-icon.png">
                <link rel="icon" type="image/png" sizes="32x32" href="/favico/favicon-32x32.png">
                <link rel="icon" type="image/png" sizes="16x16" href="/favico/favicon-16x16.png">
                <link rel="manifest" href="/favico/site.webmanifest">
                <link rel="mask-icon" href="/favico/safari-pinned-tab.svg" color="#5bbad5">
                <meta name="msapplication-TileColor" content="#da532c">
                <meta name="theme-color" content="#2d7262">
				<title>
					Jarvis
				</title>
				<link href="/css/CustomStyleForWebsite.css" rel="stylesheet" type="text/css">
			</head>
			<body>
				<div id="container">${reactContent}</div>
				<script>
					window.__PRELOADED_STATE__ = ${JSON.stringify(preloadedState).replace(/</g, '\\u003c')}
				</script>
				<script type="text/javascript" src="/bundle.js"></script>
			</body>
		</html>`
	);
};
