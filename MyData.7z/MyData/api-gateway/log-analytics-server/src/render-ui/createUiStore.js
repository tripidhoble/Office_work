import { matchPath } from 'react-router-dom';
import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import module1 from '../../../log-analytics-gui/src/js/reducer/module1';
import module2 from '../../../log-analytics-gui/src/js/reducer/module2';

import {getProductRoutes} from './AllWebComponentsRoutes';

const matchCurrentPathAndSetInitialState =function (request) {
  const productRoutes=getProductRoutes();
  for(let index=0; index<productRoutes.length; index++) {
      const path=matchPath(request.path, { path: productRoutes[index].path,exact: true});
      if(path) {
          return {
              [productRoutes[index].reducerKey]: productRoutes[index].setInitialState(path.params)
          };
      }
  }
};

export default function createUiStore(request) {
  return createStore(
    combineReducers({
      module1,
      module2
    }),
    matchCurrentPathAndSetInitialState(request),
    applyMiddleware(thunk)
  );
};
