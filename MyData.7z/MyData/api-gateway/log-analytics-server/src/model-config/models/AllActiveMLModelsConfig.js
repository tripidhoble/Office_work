export default function AllActiveMLModelsConfig(message) {
  this.mlModelConfig = message['MODEL_CONFIG'];
}

Object.defineProperty(AllActiveMLModelsConfig.prototype, 'command', {
  value: 'ACTIVE_ML_MODEL_CONFIG',
  writable: false,
  configurable: false,
  enumerable: false
});
