export default function AllActiveFilterModelsConfig(message) {
  this.filterModelConfig = message['MODELS_CONFIG'];
}

Object.defineProperty(AllActiveFilterModelsConfig.prototype, 'command', {
  value: 'ACTIVE_FILTER_MODEL_CONFIG',
  writable: false,
  configurable: false,
  enumerable: false
});
