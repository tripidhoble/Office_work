import {
  validateRequest,
  sendUnauthorizedResponse,
  sendServerNotReadyResponse,
  createChannelAndPublishMessage,
  channelStatusCallback
} from '../../utils/utility-functions';
import globalProperties from '../../globals/globalProperties';
import gatewayLogger from '../../../config/gatewayLogger';
import AllActiveMLModelsConfig from '../models/AllActiveMLModelsConfig';
import AllActiveFilterModelsConfig from '../models/AllActiveFilterModelsConfig';
import MultipleMessageHandler from '../../utils/MultipleMessageHandler';
import uuidv4 from 'uuid/v4';
import notificationManager from '../../globals/notificationManager';

export default function modelConfigRouter(configRouter) {

  let connectionInstance, properties, logAnalyzerChannelName, logAnalyzerQueueName,
    dataProcessChannelName, dataProcessQueueName;

  //Add authentication middleware for this route
  configRouter.use((req, res, next) => {
    if(validateRequest(req)) {
      next();
    } else {
      sendUnauthorizedResponse(res);
    }
  });

  //Proceed only if the desired connection exists
  configRouter.use((req, res, next) => {
    ({connectionInstance, properties} = globalProperties.gProductConfig.connection[0]);
    const logAnalyzerChannelProps = properties.channelProperties[1];
    logAnalyzerChannelName = logAnalyzerChannelProps.channelName;
    logAnalyzerQueueName = logAnalyzerChannelProps.queuesToBind[1];

    const dataProcessChannelProps = properties.channelProperties[0];
    dataProcessChannelName = dataProcessChannelProps.channelName;
    dataProcessQueueName = dataProcessChannelProps.queuesToBind[1];

    if(connectionInstance) {
      next();
    } else {
      sendServerNotReadyResponse(res);
    }
  });

  configRouter.get('/all-model-config', (req,res) => {
    const taskId = uuidv4();
    const mlCommand = AllActiveMLModelsConfig.prototype.command;
    const dpCommand = AllActiveFilterModelsConfig.prototype.command;

    const multipleMessageHandler = new MultipleMessageHandler();

    multipleMessageHandler.addMessages(createChannelAndPublishMessage(connectionInstance,
      logAnalyzerChannelName, logAnalyzerQueueName, {
        productID: req.get('Product-Id'), taskId, command: mlCommand
      }, channelStatusCallback(logAnalyzerChannelName)));
    multipleMessageHandler.addMessages(createChannelAndPublishMessage(connectionInstance,
      dataProcessChannelName, dataProcessQueueName, {
        productID: req.get('Product-Id'), taskId, command: dpCommand
      }, channelStatusCallback(dataProcessChannelName)));

    multipleMessageHandler.executeMessages().then( () => {
      const allResponses = [];
      notificationManager.subscribe(taskId, mlCommand, dpCommand)
        .onNotification(function(message, commandForNotification) {
          gatewayLogger.debug(`received notification for taskId: ${taskId} and command: ${commandForNotification}`);
          switch(commandForNotification) {
            case mlCommand:
              allResponses.push(new AllActiveMLModelsConfig(message));
              break;
            case dpCommand:
              allResponses.push(new AllActiveFilterModelsConfig(message));
              break;
            default:
              gatewayLogger.warn(`In default case while processing notification for task: ${taskId} with command: ${commandForNotification}`);
              break;
          }

          notificationManager.unsubscribe(taskId, this, commandForNotification);

          //All responses received, send the response
          if(allResponses.length === multipleMessageHandler.messageExecutors.length) {
            res.status(200);
            let responseToSend = {};
            allResponses.forEach( response => {
              responseToSend = {...responseToSend, ...response};
            });

            res.json(responseToSend);
          }
        });
    }).catch( messageFailedReasons => {
      res.status(500);
      res.json({
        failures: messageFailedReasons
      });
    });
  });

  configRouter.post('/compare-model', (req,res) => {
    res.status(405);
    res.json({
      message: 'The request cannot be fulfilled because this feature is not yet available'
    });
  });

  return configRouter;
}
