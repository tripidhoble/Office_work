export default function PredefinedFilterModel(message) {
  this.predefinedFilters = message['PRE_FILTERS'];
}

Object.defineProperty(PredefinedFilterModel.prototype, 'command', {
  value: 'PRE_DEFINED_FILTERS',
  writable: false,
  configurable: false,
  enumerable: false
});
