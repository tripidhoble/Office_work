export default function FilterTrainModel(productId, path, filterExpressions) {
  this.productID = productId;
  this.train_path = path;
  this.filters = filterExpressions;
}

Object.defineProperty(FilterTrainModel.prototype, 'command', {
  value: 'FILTER_TRAIN_DATA',
  writable: false,
  configurable: false,
  enumerable: false
});
