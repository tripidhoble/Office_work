export default function CopyModel(productId, isLinux, hostIp, sourcePath, sourceUserName, sourceUserPassword) {
  this.productID = productId;
  this.is_linux = isLinux;
  this.host_ip = hostIp;
  this.source_path = sourcePath;
  this.source_user_name = sourceUserName;
  this.source_user_password = sourceUserPassword;
}

Object.defineProperty(CopyModel.prototype, 'command', {
  value: 'COPY_DATA',
  writable: false,
  configurable: false,
  enumerable: false
});
