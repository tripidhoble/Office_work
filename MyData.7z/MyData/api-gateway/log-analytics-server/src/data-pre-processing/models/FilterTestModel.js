export default function FilterTestModel(productId, path, labelData = 0) {
  this.productID = productId;
  this.test_path = path;
  this.data_with_labels = labelData;
}

Object.defineProperty(FilterTestModel.prototype, 'command', {
  value: 'FILTER_TEST_DATA',
  writable: false,
  configurable: false,
  enumerable: false
});
