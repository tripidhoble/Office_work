import {
  validateRequest,
  sendUnauthorizedResponse,
  sendServerNotReadyResponse,
  createChannelAndPublishMessage,
  channelStatusCallback
} from '../../utils/utility-functions';
import globalProperties from '../../globals/globalProperties';
import notificationManager from '../../globals/notificationManager';
import gatewayLogger from '../../../config/gatewayLogger';
import CopyModel from '../models/CopyModel';
import PredefinedFilterModel from '../models/PredefinedFilterModel';
import FilterTestModel from '../models/FilterTestModel';
import FilterTrainModel from '../models/FilterTrainModel';
import uuidv4 from 'uuid/v4';
import TaskModel from '../../task-processing/models/TaskModel';
import {persistToDb} from '../../task-processing/task-helper';
import {createTaskPollUri} from '../../utils/utility-functions';

export default function dataPreProcessingRouter(preProcessRouter) {

  let connectionInstance, properties, channelName, queueName;

  //Add authentication middleware for this route
  preProcessRouter.use((req, res, next) => {
    if (validateRequest(req)) {
      next();
    } else {
      sendUnauthorizedResponse(res);
    }
  });

  //Proceed only if the desired connection exists
  preProcessRouter.use((req, res, next) => {
    ({ connectionInstance, properties } = globalProperties.gProductConfig.connection[0]);
    const dataProcessChannelProps = properties.channelProperties[0];
    channelName = dataProcessChannelProps.channelName;
    queueName = dataProcessChannelProps.queuesToBind[1];

    if (connectionInstance) {
      next();
    } else {
      sendServerNotReadyResponse(res);
    }
  });

  preProcessRouter.post('/copy-data', (req, res) => {
    const taskId = uuidv4();
    //Copy data from remote linux or windows
    const copyData = new CopyModel(req.get('Product-Id'), req.body.isLinux,
      req.body.hostIp, req.body.sourcePath, req.body.sourceUserName, req.body.sourceUserPassword);

    persistToDb(new TaskModel({
      _id: taskId,
      commandProperties: {
        command: 'COPY_STATUS',
        channelName,
        queueName
      }
    })).then(() => {
      createChannelAndPublishMessage(connectionInstance, channelName, queueName,
        { ...copyData, taskId, command: copyData.command },
        channelStatusCallback(channelName)).then(() => {
          res.status(202);
          res.json({
            taskId,
            pollUri: createTaskPollUri(taskId)
          });
        }).catch(error => {

          TaskModel.findByIdAndDelete(taskId).exec();
          res.status(500);
          res.json({
            error
          });
        })
    }).catch(error => {
      res.status(500);
      res.json({
        error
      });
    });
  });

  preProcessRouter.get('/predefined-filters', (req, res) => {
    const taskId = uuidv4();
    const command = PredefinedFilterModel.prototype.command;

    createChannelAndPublishMessage(connectionInstance, channelName, queueName,
      { productID: req.get('Product-Id'), taskId, command },
      channelStatusCallback).then(() => {
        notificationManager.subscribe(taskId, command).onNotification(function(message, commandForNotification) {
          gatewayLogger.debug(`received notification for taskId: ${taskId} and command: ${commandForNotification}`);
          res.status(200);
          res.json(new PredefinedFilterModel(message));
          notificationManager.unsubscribe(taskId, this, commandForNotification);
        });
      }).catch(error => {
        res.status(500);
        res.json({
          error
        });
      });
  });

  preProcessRouter.post('/apply-filters-for-train', (req, res) => {
    const taskId = uuidv4();
    const filterTrainData = new FilterTrainModel(req.get('Product-Id'), req.body.path,
      req.body.filterExpressions);

    persistToDb(new TaskModel({
      _id: taskId,
      commandProperties: {
        command: 'FILTER_TRAIN_STATUS',
        channelName,
        queueName
      }
    })).then(() => {
      createChannelAndPublishMessage(connectionInstance, channelName, queueName,
        { ...filterTrainData, taskId, command: filterTrainData.command },
        channelStatusCallback(channelName)).then(() => {
          res.status(202);
          res.json({
            taskId,
            pollUri: createTaskPollUri(taskId)
          });
        }).catch(error => {

          TaskModel.findByIdAndDelete(taskId).exec();
          res.status(500);
          res.json({
            error
          });
        });
    }).catch(error => {
      res.status(500);
      res.json({
        error
      });
    });
  });

  preProcessRouter.post('/apply-filters-for-test', (req, res) => {
    const taskId = uuidv4();
    //Apply filters for test
    const filterTestData = new FilterTestModel(req.get('Product-Id'),
      req.body.path, req.body.labelData);

    persistToDb(new TaskModel({
      _id: taskId,
      commandProperties: {
        command: 'FILTER_TEST_STATUS',
        channelName,
        queueName
      }
    })).then(() => {
      createChannelAndPublishMessage(connectionInstance, channelName, queueName,
        { ...filterTestData, taskId, command: filterTestData.command },
        channelStatusCallback(channelName)).then(() => {
          res.status(202);
          res.json({
            taskId,
            pollUri: createTaskPollUri(taskId)
          });
        }).catch(error => {
          TaskModel.findByIdAndDelete(taskId).exec();

          res.status(500);
          res.json({
            error
          });
        });
    }).catch(error => {
      res.status(500);
      res.json({
        error
      });
    });
  });

  return preProcessRouter;
}
