import gatewayLogger from '../../config/gatewayLogger';

export const persistToDb = function (dbModel) {
  return new Promise( (resolve,reject) => {
    dbModel.save(function (err) {
      if (err) {
        gatewayLogger.error(`Could not persist ${dbModel} to connected db: ${err}`);
        reject(err);
      } else {
        resolve();
      }
    });
  });
};