import {
  validateRequest,
  sendUnauthorizedResponse,
  sendServerNotReadyResponse,
  createChannelAndPublishMessage,
  channelStatusCallback
} from '../../utils/utility-functions';
import globalProperties from '../../globals/globalProperties';
import notificationManager from '../../globals/notificationManager';
import gatewayLogger from '../../../config/gatewayLogger';
import TaskModel from '../models/TaskModel';
import TaskResponse from '../models/TaskResponse';

export default function taskProcessingRouter(taskProcessRouter) {

  let connectionInstance;

  //Add authentication middleware for this route
  taskProcessRouter.use((req, res, next) => {
    if (validateRequest(req)) {
      next();
    } else {
      sendUnauthorizedResponse(res);
    }
  });

  //Proceed only if the desired connection exists
  taskProcessRouter.use((req, res, next) => {
    ({ connectionInstance } = globalProperties.gProductConfig.connection[0]);
    if (connectionInstance) {
      next();
    } else {
      sendServerNotReadyResponse(res);
    }
  });

  taskProcessRouter.get('/status/:taskId', (req, res) => {
    const { taskId } = req.params;
    TaskModel.findById(taskId).exec((error, taskDetails) => {
      if (error || !taskDetails) {
        res.status(404);
        res.json({
          message: `No task available for ${taskId}`
        });
        return;
      }

      const { commandProperties } = taskDetails;
      const command = commandProperties.command;
      createChannelAndPublishMessage(connectionInstance, commandProperties.channelName,
        commandProperties.queueName, {
        productID: req.get('Product-Id'), taskId, command
      }, channelStatusCallback).then(() => {
        notificationManager.subscribe(taskId, command)
          .onNotification(function(message, commandForNotification) {
            gatewayLogger.debug(`received notification for taskId: ${taskId} and command: ${commandForNotification}`);
            res.status(200);
            res.json(new TaskResponse(message));
            notificationManager.unsubscribe(taskId, this, commandForNotification);

            //Update task details on best effort basis
            taskDetails.taskStatus = message.status;
            taskDetails.save();
          });
      }).catch(error => {
        res.status(500);
        res.json({
          error
        });
      });
    });
  });

  return taskProcessRouter;
}
