export default function TaskResponse(message) {
  for(const key in message) {
    if(!message.hasOwnProperty(key) || key === 'taskId' || key === 'command') {
      continue;
    }

    this[key] = message[key];
  }
};