import mongoose from 'mongoose';
import {ASYNC_TASK_INPROGRESS} from '../../utils/constants';
const Schema = mongoose.Schema;

const TaskModelSchema = new Schema({
  _id: String,
  commandProperties: {
    command: String,
    channelName: String,
    queueName: String
  },
  taskStatus: {
    type: String,
    default: ASYNC_TASK_INPROGRESS
  }
}, {_id: false});

const TaskModel = mongoose.model('TaskModel', TaskModelSchema );
export default TaskModel;
