import {
  ConnectionDetails,
  ExchangeDetails,
  connectionStatusEnum,
  channelStatusEnum
} from 'javascript-amqp-library';

import { EXCHANGE_TYPE_DIRECT } from '../utils/constants';
import gatewayLogger from '../../config/gatewayLogger';
import notificationManager from '../globals/notificationManager';

export default class AmqpConnection {
  constructor(connectionProperties, amqpConnectionLib) {
    this.connectionProperties = connectionProperties;
    this.clientLib = amqpConnectionLib;
  }

  processMessagesCallback(clientLibFromCb, channelName, queueName, messageProperties, message) {

    if(notificationManager.routeMessageToSubscribers(message)) {
      try {
        clientLibFromCb.basicAck(messageProperties, channelName);
      } catch (error) {
        gatewayLogger.error(`Could not ack the message with properties: ${messageProperties} received on queue: ${queueName} on channel: ${channelName}, reason: ${error}`);
      }
    } else {

      //No subscriber found, remove the message from the queue
      try {
        clientLibFromCb.basicNack(messageProperties, channelName);
      } catch (error) {
        gatewayLogger.error(`Could not nack the message with properties: ${messageProperties} received on queue: ${queueName} on channel: ${channelName}, reason: ${error}`);
      }
    }
  }

  setupConsumptionChannel() {
    this.connectionProperties.channelProperties.forEach( channelProperty => {

      //TODO implement channel re-creation startegy
      this.clientLib.createChannel(channelProperty.channelName, (type, error) => {
        if (channelStatusEnum.ERROR === type) {
          gatewayLogger.error(`channel: ${channelProperty.channelName} created on connection to host: ${this.connectionProperties.host} received an error, reason: ${error}`);
        } else if (channelStatusEnum.CLOSED === type) {
          gatewayLogger.warn(`channel: ${channelProperty.channelName} created on connection to host: ${this.connectionProperties.host} was stopped, reason: ${error}`);
        }
      }).then(() => {
        this.clientLib.consumeMessage(channelProperty.channelName, channelProperty.queuesToBind[0],
          this.processMessagesCallback).then(() => {
            gatewayLogger.info(`channel: ${channelProperty.channelName} with queue: ${channelProperty.queuesToBind[0]} has begun consuming`);
          }).catch(error => {
            gatewayLogger.error(`channel: ${channelProperty.channelName} with queue: ${channelProperty.queuesToBind[0]}, could not begin consuming, reason: ${error}`);
          });
      }).catch( channelError => {
        gatewayLogger.error(`channel: ${channelProperty.channelName} could not be created, reason: ${channelError}`);
      });
    });
  }

  /**
   * This method will return the connection instance of the message broker that is used.
   * It will set all the properties in the configuration so that in all other places
   * one can simply create the channel and start sending or receiving messages.
   * @returns a Promise which will indicate the status of a connection
   */
  establishConnection(errorHandler, closeHandler) {
    const connectionDetails = new ConnectionDetails(
      this.connectionProperties.host,
      this.connectionProperties.port,
      this.connectionProperties.virtualHost,
      this.connectionProperties.username,
      this.connectionProperties.password
    );
    this.clientLib = this.clientLib.setConnectionDetails(connectionDetails);

    const channelsToSave = this.connectionProperties.channelProperties;
    for (let index = 0; index < channelsToSave.length; index++) {
      const channelAttributes = channelsToSave[index];

      /*
        Map the config exchange types to the one present in the client Lib
        this ensures that no dependancy is created between the client library and
        the gateway code.
      */
      let exchangeType = null;
      switch(channelAttributes.exchangeType) {
        case EXCHANGE_TYPE_DIRECT:
          exchangeType = this.clientLib.exchangeTypes.DIRECT;
          break;
        default:

          // Default to broadcast type of exchange
          exchangeType = this.clientLib.exchangeTypes.FANOUT;
          gatewayLogger.warn('AMQP: No exchange type specified for exchange: '+
            channelAttributes.exchangeName + ' belonging to host ' + this.connectionProperties.host
            + ' using client broker: ' + this.connectionProperties.client);
          break;
      }

      const channelDetails = new ExchangeDetails(
        channelAttributes.channelName,
        exchangeType,
        channelAttributes.exchangeName,
        channelAttributes.queuesToBind
      );

      try {
        this.clientLib.setChannelExchangeProperties(channelDetails);
      }catch(error) {

        /*
          TODO decide on how best to handle errors introduced in the config file.
          For now simply return a reject promise and do not establish the connection
        */
        return Promise.reject(error);
      }
    }

    return this.clientLib.createConnection((type, error) => {
      if(connectionStatusEnum.ERROR === type) {
        errorHandler(error);
      }else if(connectionStatusEnum.CLOSED === type) {
        closeHandler(error);
      }
    }).then(() => {

      //TODO decide how best to chain promise for start-up of the gateway.
      this.setupConsumptionChannel();

      //Pass the instance that was created once the connection has been established
      return this.clientLib;
    });
  }
}