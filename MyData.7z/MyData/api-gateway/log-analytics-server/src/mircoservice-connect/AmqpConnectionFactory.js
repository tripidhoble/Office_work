import { RABBIT_MQ_CLIENT } from '../utils/constants';
import {
  RabbitMqMessageConnection
} from 'javascript-amqp-library';

export default class AmqpConnectionFactory {
  constructor(configToCreate) {
    this.configToCreate = configToCreate;
  }

  protocolFactory() {
    let protocolConnectionFactory = null;
    switch(this.configToCreate.client) {
      case RABBIT_MQ_CLIENT:
        protocolConnectionFactory = new RabbitMqMessageConnection();
        break;
      default:
        break;
    }

    return protocolConnectionFactory;
  }
}