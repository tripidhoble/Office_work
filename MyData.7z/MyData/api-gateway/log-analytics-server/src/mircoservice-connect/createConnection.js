import globalProperties from '../globals/globalProperties';
import gatewayLogger from '../../config/gatewayLogger';
import AmqpConnectionFactory from './AmqpConnectionFactory';
import AmqpConnection from './AmqpConnection';
import { AMQP_PROTOCOL } from '../utils/constants';

function establishAmqpConnection(connectionConfig) {
  const connectionProperties = connectionConfig.properties;
  const amqpConnectionLib = new AmqpConnectionFactory(connectionProperties).protocolFactory();
  const amqpConnection = new AmqpConnection(connectionProperties, amqpConnectionLib);

  /*
    TODO decide and implement reconnection srategy. Will probably be implemented
    in the client lib only. For now simply log and proceed
  */
  amqpConnection.establishConnection(error => {
    gatewayLogger.error('connection error received: ' + error);
    delete connectionConfig.connectionInstance;
  }, error => {
    gatewayLogger.warn('connection closed: ' + error);
    delete connectionConfig.connectionInstance;
  }).then(connectionInstance => {

    //Adding it to the global properties based on reference update.
    connectionConfig.connectionInstance = connectionInstance;
    gatewayLogger.info(`connected to ${connectionProperties.host} on port: ${connectionProperties.port} using protocol: ${connectionConfig.protocol}`);
  }).catch(connectionError => {
    gatewayLogger.error(`Could not connect to ${connectionProperties.host} on port: ${connectionProperties.port} using protocol: ${connectionProperties.protocol}. Reason: ${connectionError}`);
  });
}

export default function createConnection() {
  const connectionsToEstablish = globalProperties.gProductConfig.connection;
  connectionsToEstablish.forEach(connectionConfig => {
    switch(connectionConfig.protocol) {
      case AMQP_PROTOCOL:
        establishAmqpConnection(connectionConfig);
        break;
      default:
        break;
    }
  });
}