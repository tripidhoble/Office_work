// Product configurations
import productConfig from '../../config/config.json';

/*
  All global variables should be referenced via a global object.
  Their names will begin with g to indicate thtat the variable is global
*/

const globalProperties = {
  gDirectoryRoot: __dirname,
  gProductConfig: JSON.parse(JSON.stringify(productConfig))
};

export default globalProperties;
