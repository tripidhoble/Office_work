/*
  Export an object that can be called globally.
  This object will contain all the server side event connection instances
  using which the status of operations can be sent to the UI.
  The object will be a key value pair of the URI of the connection along with its connection.
*/
export default {
  sseConnections: {}
};