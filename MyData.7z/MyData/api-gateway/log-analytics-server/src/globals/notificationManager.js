import gatewayLogger from '../../config/gatewayLogger';

class Notifier {
  constructor() {
    this.callBackFunction = null;
  }

  _notify(message, command) {
    this.callBackFunction(message, command);
  }

  onNotification(callBackFunction) {
    this.callBackFunction = callBackFunction;
  }

}

class NotificationManager {
  constructor() {
    this.subscriberList = {};
  }

  subscribe(taskId, ...taskTypes) {
    if(taskTypes.length === 0) {
      gatewayLogger.error(`Registering a subscriber without any type info is invalid`);
      throw `Registering a subscriber without any type info is invalid`;
    }

    const notifier = new Notifier();

    const existingSubscribers = this.subscriberList[taskId];
    if(existingSubscribers && existingSubscribers.subscriberDetails) {
      existingSubscribers.subscriberDetails.push({
        taskTypes,
        notifier
      });
    } else {
      this.subscriberList[taskId] = {
        subscriberDetails: [{
          taskTypes,
          notifier
        }]
      };
    }

    gatewayLogger.debug(`Subscriber List after subscribe is: ${JSON.stringify(this.subscriberList)}`);

    return notifier;
  }

  unsubscribe(taskId, notifier, ...taskTypes) {
    const existingSubscribers = this.subscriberList[taskId];
    if(!existingSubscribers) {
      gatewayLogger.error(`No subscriber exists for the provided Task Id: ${taskId}`);
      throw `No subscriber exists for the provided Task Id: ${taskId}`;
    }

    let indexToCheck = -1;
    const {subscriberDetails} = existingSubscribers;
    for (let index = 0; index < subscriberDetails.length; index++) {
      const subscriberProperties = subscriberDetails[index];

      // Passed notifier is the same as the one that was registered. Proceed to clear the taskTypes
      if (subscriberProperties.notifier === notifier) {
        const subscribedTaskTypes = subscriberProperties.taskTypes;
        subscriberProperties.taskTypes = subscribedTaskTypes.filter(subscribedTaskType => {
          for (let index = 0; index < taskTypes.length; index++) {
            const taskType = taskTypes[index];
            if (taskType === subscribedTaskType) {
              return false;
            }
          }

          //No match for the current subscriber, keep it in the list.
          return true;
        });

        indexToCheck = index;
        break;
      }
    }

    //Subscriber details found
    if(indexToCheck === -1) {
      gatewayLogger.error('No subscriber exists for the provided notifier. ' +
        'Ensure that the notifier instance provided is the one that is passed');

      throw 'No subscriber exists for the provided notifier. ' +
        'Ensure that the notifier instance provided is the one that is passed';
    }

    const modifiedSubscriberProperties = subscriberDetails[indexToCheck];
    gatewayLogger.debug(`Subscriber details after modification for taskId: ${taskId} is ${JSON.stringify(modifiedSubscriberProperties)}`);
    if(modifiedSubscriberProperties.taskTypes.length === 0) {

      // Delete this subscriber's properties from the list
      subscriberDetails.splice(indexToCheck, 1);
    }

    //No subscribers left for this taskId, delete this info
    if(subscriberDetails.length === 0) {
      delete this.subscriberList[taskId];
    }

    gatewayLogger.debug(`Subscriber List after unsubscribe is: ${JSON.stringify(this.subscriberList)}`);
  }

  routeMessageToSubscribers(message) {
    let notificationSent = false;
    const {taskId, command} = message;
    if(!taskId) {
      gatewayLogger.error(`No task Id present in the message: ${message}`);
      return notificationSent;
    }

    if(!command) {
      gatewayLogger.error(`No command present in the message: ${message}`);
      return notificationSent;
    }

    const existingSubscribers = this.subscriberList[taskId];
    gatewayLogger.debug(`subscriber details for task Id: ${taskId} is ${JSON.stringify(existingSubscribers)}`);
    if(existingSubscribers && existingSubscribers.subscriberDetails) {
      const {subscriberDetails} = existingSubscribers;

      // Go through all the subscribers and notify all those who have subscribed for the received command
      for (let subscriberIndex = 0; subscriberIndex < subscriberDetails.length; subscriberIndex++) {
        const subscriberProperties = subscriberDetails[subscriberIndex];

        //Go through the task types of each subscriber and if matched then notify the subscriber
        for (let index = 0; index < subscriberProperties.taskTypes.length; index++) {
          const subscriberTaskType = subscriberProperties.taskTypes[index];
          if(subscriberTaskType === command) {
            gatewayLogger.debug(`notified for taskId: ${taskId} and command: ${command}`);
            subscriberProperties.notifier._notify(message, command);
            notificationSent = true;

            //A single message will have a single command only Move on to the next subscriber
            break;
          }
        }
      }
    }

    return notificationSent;
  }
}

const notificationManager = new NotificationManager();

//Prevent the object from being cloned or changed.
Object.defineProperty(NotificationManager.prototype, 'routeMessageToSubscribers', {
  enumerable: false
});
Object.defineProperty(NotificationManager.prototype, 'unsubscribe', {
  enumerable: false
});
Object.defineProperty(NotificationManager.prototype, 'subscribe', {
  enumerable: false
});
Object.defineProperty(notificationManager, 'subscriberList', {
  enumerable: false
});

Object.freeze(notificationManager);
Object.freeze(NotificationManager.prototype);

export default notificationManager;
