export const AMQP_PROTOCOL = 'amqp';

export const RABBIT_MQ_CLIENT = 'rabbitMQ';

export const EXCHANGE_TYPE_DIRECT = 'direct';

export const ASYNC_TASK_INPROGRESS = 'INPROGRESS';

export const ASYNC_TASK_COMPLETE = 'COMPLETE';

export const ASYNC_TASK_FAILED = 'FAILED';

export const TRAIN_TEST_ROUTE = '/train-test-status';
