export default class MultipleMessageHandler {
  constructor() {
    this.messageExecutors=[];
  }

  addMessages(messageExecutor) {
    this.messageExecutors.push(messageExecutor);
  }

  executeMessages() {

    return Promise.all(this.messageExecutors.map( promisePending => {
      return promisePending.then(value => {
        return {
          status: 'fulfilled',
          value
        };
      }).catch(reason => {
        return {
          status: 'rejected',
          reason
        };
      });
    })).then( (results) => {
      const messageFailedReasons = [];
      results.forEach( messageResult => {
        if(messageResult.status === "rejected") {
          messageFailedReasons.push(messageResult.reason);
        }
      });

      if(messageFailedReasons.length) {
        return Promise.reject(messageFailedReasons);
      } else {
        return Promise.resolve();
      }
    });
  }
}