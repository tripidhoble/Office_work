import gatewayLogger from '../../config/gatewayLogger';

export function validateRequest(request) {
  //TODO add the correct token validation
  return true;
};

export function sendUnauthorizedResponse(response) {
  response.status(401);
  response.send({
    message: 'Unauthorized'
  });
};

export function sendServerNotReadyResponse(response) {
  response.status(500);
  response.send({
    message: 'Cannot establish connection for contacting the services'
  });
}

export function createChannelAndPublishMessage(connectionInstance, channelName, queueName, dataToPublish, channelStatusCallback){ 

  return connectionInstance.createChannel(channelName,channelStatusCallback).then(() => {
    gatewayLogger.info(`creating channel: ${channelName}`);
    return connectionInstance.publishMessage(channelName, queueName, dataToPublish).then(() => {
      gatewayLogger.info(`Message: ${JSON.stringify(dataToPublish)} published on queue ${queueName}`);
      return Promise.resolve();
    }).catch(error=> {
      gatewayLogger.error(error);
      return Promise.reject(error);
    })
  });
}

/**
 * A simple channel listener that will log the reason for the closure of the channel.
 * @param channelName the channel for which the callback is invoked.
 */
export function channelStatusCallback(channelName) {
  return (type, error) => {
    if(channelStatusEnum.ERROR === type) {
      gatewayLogger.error(`channel: ${channelName} has received an error: ${error}`);
    }else if(channelStatusEnum.CLOSED === type) {
      gatewayLogger.error(`channel: ${channelName} has been closed, reason: ${error}`);
    }
  };
};

export const createTaskPollUri = function(taskId) {
  return `/api/task-processing/status/${taskId}`;
}