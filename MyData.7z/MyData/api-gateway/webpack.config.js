const path = require('path');
const nodeExternals = require('webpack-node-externals');
const webpack = require('webpack');
const CompressionPlugin = require('compression-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');

let mode;
if(process.env.NODE_ENV === 'production') {
    mode = 'production';
}else {
    mode = 'development';
}

var pollyFillConfig = {
  entry: './log-analytics-gui/src/pollyfills/pollyfill.js',
  mode: mode,
  output: {
    filename: 'pollyfill.js',
    path: path.resolve(__dirname, 'lib')
  },
  module: {
    rules: [
      { test: /\.js$/, exclude: /node_modules/, loader: "babel-loader" }
    ]
  }
};

var browserConfig = {
  entry: './log-analytics-gui/src/js/index.js',
  mode: mode,
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'lib')
  },
  module: {
    rules: [
      { test: /\.js$/, exclude: /node_modules/, loader: "babel-loader" }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env': {
        'NODE_ENV': JSON.stringify(mode)
      }
    }),
    new CompressionPlugin({
      asset: "[path].gz[query]",
      algorithm: "gzip",
      test: /\.js$|\.css$|\.html$/,
      threshold: 10240,
      minRatio: 0.8
    })
  ]
};

var serverConfig = {
  entry: './log-analytics-server/src/server.js',
  mode: mode,
  target: 'node',
  externals: [nodeExternals()],
  output: {
    filename: 'server.js',
    path: path.resolve(__dirname, 'lib')
  },
  module: {
    rules: [
      { test: /\.js$/, exclude: /node_modules/, loader: "babel-loader" }
    ]
  }
};

var cssConfig = {
  entry: './log-analytics-gui/style/CssBuild.js',
  mode: mode,
  output: {
    filename: 'cssBuild.js',
    path: path.resolve(__dirname, 'lib')
  },
  optimization: {
    minimizer: [
      new OptimizeCSSAssetsPlugin({})
    ]
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: 'css/CustomStyleForWebsite.css'
    }),
    new CompressionPlugin({
      asset: "[path].gz[query]",
      algorithm: "gzip",
      test: /\.css$/,
      threshold: 10240,
      minRatio: 0.8
    })
  ],
  module: {
    rules: [
      {
        test: /\.s[c|a]ss$/,
        use: [
          MiniCssExtractPlugin.loader,
          'css-loader?url=false',
          'sass-loader'
        ]
      }
    ]
  }
};

module.exports = [pollyFillConfig, browserConfig, serverConfig, cssConfig];
