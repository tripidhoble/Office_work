import 'whatwg-fetch';
import 'promise-polyfill/src/polyfill';

//For those browsers that do not support isNaN
Number.isNaN = Number.isNaN || function(value) {
    //The following works because NaN is the only value in javascript which is not equal to itself.
    return value !== value;
};