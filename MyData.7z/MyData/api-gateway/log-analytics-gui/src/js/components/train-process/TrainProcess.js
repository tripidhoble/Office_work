import React, {Component} from 'react';
import StepsLeft from '../../common/StepsLeft';
import CopyData from '../copy-data/CopyData';

export default class TrainProcess extends Component {
  constructor() {
    super()
    this.state = {
      activeStep: 0
    };

    this.stepDescriptions=[
      'Copy', 'Filter', 'Train'
    ];
  }

  render() {
    const {activeStep} = this.state;
    let currentStepComponent;
    if(activeStep === 0) {
      currentStepComponent = (
        <CopyData/>
      );
    }

    return (
      <div className={'container--center-align'} >
        <div>
          <h2>Train Component</h2>
        </div>
        <StepsLeft activeStep={activeStep} stepDescriptions={this.stepDescriptions}></StepsLeft>
        {currentStepComponent}
      </div>
    );
  }
}