import React, { Component } from 'react';
import Input from '../../common/Input';

export default class CopyData extends Component {
  constructor() {
    super()
    this.state = {
      copyProfile: {
        folderPath: ''
      }
    };
  };

  onInputChange = (event) => {
    const {copyProfile} = this.state;
    copyProfile[event.target.getAttribute('name')] = event.target.value;
    this.setState({copyProfile});
  };

  render() {
    return (
      <div className={'copy--container-center-align margin-top--large'}>
        <Input inputContainerProperties={{key: 'folder_path'}}
          inputProperties={{
            name: 'folderPath',
            title: 'Folder Path',
            value: this.state.copyProfile.folderPath,
            onChange: this.onInputChange
          }}/>
      </div>
    );
  }
}