import React, {Component, Fragment, createRef} from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import FixedHeader from '../common/FixedHeader';
import AboutUs from './AboutUs';
import Dashboard from './Dashboard';
import TrainProcess from './train-process/TrainProcess';
import Test from './Test';
import NoSuchUrl from '../common/NoSuchUrl';
import { ContainerHeight } from '../utils/context/ContainerHeight';
import { TOP_BAR_HEIGHT} from '../utils/constants/CommonForProduct';

export default class App extends Component {
  constructor() {
    super();
    this._processResizeEvent = this._processResizeEvent.bind(this);
    this._setMinHeightOfTheContainer = this._setMinHeightOfTheContainer.bind(this);
    this.state={
      containerStyle: {
        minHeight: 'unset'
      }
    };
    this.footerContainer = createRef();
    this.intervalIdForResize = null;
  }

  componentDidMount() {
    this._setMinHeightOfTheContainer();
    window.addEventListener('resize',this._processResizeEvent);
  }

  componentDidUpdate() {
    this._setMinHeightOfTheContainer();
  }

  componentWillUnmount() {
    clearTimeout(this.intervalIdForResize);
    window.removeEventListener('resize',this._processResizeEvent);
  }

  /*
    In case if new options are added, or if the donate link is moved,
    the donateIndex sent to the FixedHeader must also be changed to reflect the same.
  */
  _getHeaderOptions() {
    return [
      {label:'Train', url:'/train'},
      {label:'Test',url:'/test'}
    ];
  }

  _currentUrlBasedProperties() {
    //Index starts from 0.
    let activeIndexForHeader;
    if(this.props.location) {
      switch(this.props.location.pathname) {
        case '/train':
          activeIndexForHeader = 0;
          break;
        case '/test':
          activeIndexForHeader = 1;
          break;
        default:

          //In case if no route is matched prevent highlight of any link.
          activeIndexForHeader=null;
          break;
      }
    }
    return {activeIndexForHeader};
  }

  _processResizeEvent() {
    /*
        Wait for a short time for the DOM to stabilize
        Clear out whatever execution was pending and then wait again
    */
    clearTimeout(this.intervalIdForResize);
    this.intervalIdForResize=setTimeout(this._setMinHeightOfTheContainer,20);
  }

  /**
    Update the min height of the container so that the footer aligns exactly at the bottom of the page.
  **/
  _setMinHeightOfTheContainer() {
    const {containerStyle} = this.state;

    let minHeight = (window.innerHeight - (TOP_BAR_HEIGHT + 1));
    //don't let the min-height go below 150px;
    if(minHeight < 150) {
      minHeight = 150;
    }

    minHeight += 'px';

    //Set the state only if the min Height has changed.
    if(containerStyle.minHeight !== minHeight) {
      containerStyle.minHeight = minHeight;
      this.setState({containerStyle});
    }
  }

  render() {
    const {activeIndexForHeader} = this._currentUrlBasedProperties();
    return (
      <Fragment>
        <FixedHeader navMenu={this._getHeaderOptions()} currentActiveSection={activeIndexForHeader}/>
        <ContainerHeight.Provider value={this.state.containerStyle.minHeight}>
          <div className={'container--content'} style={{...this.state.containerStyle}}>
            <Switch>
              <Route
                exact
                path='/'
                render={() => {
                  return (
                    <Redirect
                      to={{
                        pathname: '/dashboard'
                      }}
                    />
                  );
                }}
              />
              <Route exact path='/dashboard' component={Dashboard}/>
              <Route exact path='/train' component={TrainProcess}/>
              <Route exact path='/test' component={Test}/>
              <Route exact path='/about-us' component={AboutUs}/>
              <Route component={NoSuchUrl}/>
            </Switch>
          </div>
        </ContainerHeight.Provider>
      </Fragment>
    );
  }
}
