import React, {Component} from 'react';

export default class AboutUs extends Component {
  constructor() {
    super();
    this.state={
    };
  }

  render() {
    return (
        <div>
            <h2>{'About Us'}</h2>
        </div>
    );
  }
}