import React, {Component} from 'react';

export default class Dashboard extends Component {
  render() {
    return (
      <div>
        <h1>Dashboard Component</h1>
      </div>
    );
  }
}
