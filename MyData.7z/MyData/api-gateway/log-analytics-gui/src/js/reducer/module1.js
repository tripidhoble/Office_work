import {
  GET_SAMPLE_DECLARATION_SUCCESS,
  GET_SAMPLE_DECLARATION_FAILURE,
  UNLOAD_SAMPLE_DECLARATION_SUCCESS
} from '../actions/module1';

const initialState = {
  randomDataLoadSuccess : undefined,
  randomDataLoadFailure : undefined
};

const handlers = {
  [GET_SAMPLE_DECLARATION_SUCCESS]: (_,action) =>({
    randomDataLoadSuccess: action.response.members,
    randomDataLoadFailure: undefined
  }),
  // [GET_SAMPLE_DECLARATION_SUCCESS]: (state, action) => {
  //   state.randomDataLoadSuccess[action.id] = {
  //     prop1: action.prop1,
  //     prop2: action.prop2
  //   };
  //   return state;
  // },
  [GET_SAMPLE_DECLARATION_FAILURE]: (_,action) =>({
    randomDataLoadSuccess: undefined,
    randomDataLoadFailure: action.error
  }),
  [UNLOAD_SAMPLE_DECLARATION_SUCCESS]: () =>({
    randomDataLoadSuccess: undefined,
    randomDataLoadFailure: undefined
  })
};

export default function module1 (state = initialState, action) {
  const handler = handlers[action.type];
  if (!handler) return state;
  return { ...state, ...handler(state, action) };
};