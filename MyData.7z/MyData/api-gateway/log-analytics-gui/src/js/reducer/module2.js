import {
  ACTION_INPROGRESS,
  ACTION_SUCCESS,
  ACTION_FAILURE,
  UNLOAD_ACTION
} from '../actions/module2';

const initialState = {
  actionInProgress: undefined,
  actionSuccess : undefined,
  actionFailure : undefined
};

const handlers = {
  [ACTION_INPROGRESS]: () =>({
    actionInProgress: true,
  }),
  [ACTION_SUCCESS]: (_,action) =>({
    actionInProgress: undefined,
    actionSuccess: action.response,
    actionFailure: undefined
  }),
  [ACTION_FAILURE]: (_,action) =>({
    actionInProgress: undefined,
    actionSuccess: undefined,
    actionFailure: action.error
  }),
  [UNLOAD_ACTION]: () =>({
    actionSuccess: undefined,
    actionFailure: undefined
  })
};

export default function module2 (state = initialState, action) {
  const handler = handlers[action.type];
  if (!handler) return state;
  return { ...state, ...handler(state, action) };
};