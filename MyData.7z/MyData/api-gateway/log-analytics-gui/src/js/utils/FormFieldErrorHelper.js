import {TOP_BAR_HEIGHT} from './constants/CommonForProduct';

/**
  This method will return the vertical scroll by which the window must move to the first field
  which has a validation error.
  @param firstErrorNode:  The first DOM node which has the error.
  @return verticalScroll: the value in pixels which must be used to scroll to the error node.
**/
export const calculateVerticalScroll = function(firstErrorNode) {
	let verticalScroll = (TOP_BAR_HEIGHT + 5) - firstErrorNode.top;
	//If the vertical scroll turns out negative then the first error node is already in view hence do not scroll up
	if(verticalScroll < 0) {
		verticalScroll=0;
	}else {
		//If the vertical scroll is positive then the window must be scrolled by the vertical scroll. Set it to negative so that the window scrolls up.
		verticalScroll = -verticalScroll;
	}
	return verticalScroll;
};

/**
    This method will iterate on all the child nodes and in case
    if one of the child nodes is a div element then it will recursively proceed
    to check the children of the div element. Once an input element is found
    the method will break out of the recursive loop and return the input node.
    @param parentNode to check
    @return inputChildNode which is a node of type INPUT.
**/
const getInputNodeFromParent = function(parentNode) {
    let inputChildNode=null;
    if(parentNode.hasChildNodes()) {
        const childrenNodes = parentNode.childNodes;
        for(let index =0; index < childrenNodes.length; index++) {
            const childElement = childrenNodes[index];
            //If the current errored element matches the child element then proceed with focusing the node
            if('INPUT' === childElement.nodeName || 'SELECT' === childElement.nodeName || 'TEXTAREA' === childElement.nodeName) {
                inputChildNode = childElement;
                break;
            } else if('DIV' === childElement.nodeName) {
                inputChildNode = getInputNodeFromParent(childElement);
                if(inputChildNode !== null) {
                    break;
                }
            }
        }
    }
    return inputChildNode;
};

/**
    This method will iterate on all the error keys if present. The order of the error keys is assumed
    to match the order of the form fields. The input box matching the first error key that is encountered
    is then the first node that has the error in the form. This container's childs are checked to find the
    input box and its focus is set. This method expects the refsProfile to depict the order of the form fields.
    @param errorProfile has all the errors that a form may contain.
    @refsProfile has all the dom nodes that are present in the form.
    @return firstErrorNode which will contain the dimensions of the first input box to which the form must be scrolled to.
**/
export const getFirstErrorNodeAndFocusIt = function(errorProfile, refsProfile) {
    let firstErrorNode;
    for (const key in refsProfile) {
        //If any key is present in the object then an error exists hence set the valid flag to false.
        if(errorProfile[key]) {
            //Get the position of the first error that is encountered while validating. This will be used to scroll to that position.
            firstErrorNode=refsProfile[key].current.getBoundingClientRect();
            /*
                Focus the node if focus attribute is present. No need to check for any null value
                because once an error is encountered an INPUT element will be present
                and needs to be focused.
            */
            getInputNodeFromParent(refsProfile[key].current).focus({preventScroll: true});
            break;
        }
    }
    return firstErrorNode;
};

/**
    Common utility to simply focus on the input node.
    Only one field should be focused per form.
    @param inputNode which is the underlying input DOM node.
**/
export const autoFocusInputField = function(inputNode) {
    if(inputNode) {
        inputNode.focus();
    }
};
