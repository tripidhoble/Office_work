import React from 'react';
import Loader from '../common/Loader';

/**
  This method will always return the error message to the action and hence no obejcts will be returned to the clients.
  They can access the error like a normal string variable.
  @param errorFromRest:  The actual error response which will be returned to the requesting
  action if this error does not have the 440 code which signifies client side error.
  @param errorMsg: This is the custom error message to show in case there is a client side error which will
  occur only if the REST call is never made due to the working of fetch api.
  @return error: An error message that can be accessed by the client directly.
*/
export const getClientSideRestError = function(errorFromRest,errorMsg) {
	let error=errorFromRest;
	if(errorFromRest.errorCode === 440) {
		error=errorMsg;
	}
	return error;
};

/**
  If header is present only then the description must be shown. Hence display the description without any check.
  @param header:  The header of the section.
  @param description: Optional, the description will be shown only if a header is provided.
  @param classForHeader: Optional, the class that must be applied to the header.
  @return error: Dom node consisting of a div which contains the header and the description.
*/
export const getSectionHeaderIfPresent = function(header,description, classForHeader) {
    let headerSection;
    if(header) {
        let classToApply = 'header-color';
        if(classForHeader) {
            classToApply += ' ' + classForHeader;
        }
        headerSection=(
            <div>
                <h3 className={classToApply}>
                    {header}
                </h3>
                {description}
            </div>
        );
    }
    return headerSection;
};

/**
  For some browsers such as firefox and IE if an a tag is the child of a div that has been attached with an onClick handler
  then upon middle clicking the mouse button the onClick handler is called. This causes the default behavior to be prevented
  and instead of opening the link in a new tab the route is pushed. This function builds a wrapper which
  calls the onClick handler only if the middle button was not clicked.
  @param onClickHandler: the click handler that must be called. This must be bound with all the appropraite parameters that are needed.
    It will be called and passed the event parameter so that any activities that require an event can be performed.
  @return function: that will be provided to the DOM click handler; the DOM will call this function and pass in the event parameter.
    This function will then check whether the middle button was clicked or not using the event's button property and then call the
    click handler if appropriate.
*/
export const ignoreMiddleButtonClickForBrowsers = function(onClickHandler) {
	return function(event) {
		//A possible alternative is which
		const {button} = event.nativeEvent;
		//The number 1 indicates middle click. Do nothing let the default behavior open link in new tab.
		if(button !== 1) {
			onClickHandler(event);
		}
	}
};

/**
  Parse the query params by first splitting the search string on the '?' and then split the string that is after the question mark on
  the '&' charachter. This provides an array with each query param in the key=value format.
  Further parse the string to convert the query params into a json object with the original key as the property and its value as the propertie's value.
  @param {location} This contains the entire url information. Should not be null or undefined
  @return {queryParamsKeyValuePair} a json object whose properties match the keys in the query params and whose values correspond
    to the values of the keys in the query params respectively.
*/
export const returnQueryParamsAsKeyValuePairs = function(location) {
	let queryParamsKeyValuePair;
	if(location.search) {
		queryParamsKeyValuePair={};
		const allQueryParams=location.search.split('?')[1].split('&');
		for(let index=0; index < allQueryParams.length; index++) {
			const queryKeyValue=allQueryParams[index].split('=');
			queryParamsKeyValuePair[queryKeyValue[0]] = decodeURI(queryKeyValue[1]);
		}
	}
	return queryParamsKeyValuePair;
};

/**
	Common utitlity to return the focus class for form fields. This method will check whether the
	focusedField contains the desired field and return the class name for the focused field.
	@param {focusedField} is the object that holds the field for which a focus class must be applied.
	@param {fieldId} is the id which the field has been given and is the same id with which the focus class
		is mapped in the focusedField object.
	@return {focusedFieldClass} either the class name or an empty string.
*/
export const getFocusedFieldClass =function(focusedField, fieldId) {
	let focusedFieldClass = focusedField[fieldId];
	if(!focusedFieldClass) {
		focusedFieldClass = '';
	}
	return focusedFieldClass;
};

/**
  A utility that will display either the button or a loader for the contact and join forms.
  @param displayLoader if true indicates using loader otherwise defaults to button.
  @param onClick: the click handler that is called on button click. This must be bound with all the appropraite parameters that are needed.
  @return buttonComponent which will either contain the button or the loader.
*/
export const getButtonOrLoader = function(displayLoader, onClick) {
    let buttonComponent;
    if(displayLoader) {
        buttonComponent=(
            <Loader size='small' alignHorizontal={false} />
        );
    }else {
        buttonComponent=(
            <div>
                <input id='submit_button' className='buttonStyle border-box--size' type='submit' name='SendEmail' value='SEND ENQUIRY' onClick={onClick}/>
            </div>
        );
    }
    return buttonComponent;
};

export const checkIfErrorExists = function(errorParameter) {
	let errorToDisplay;
	if(errorParameter) {
		errorToDisplay = errorParameter.label;
	}
	return errorToDisplay;
};
