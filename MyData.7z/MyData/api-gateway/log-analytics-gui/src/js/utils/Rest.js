// (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

const headersForAll={
  'Accept': 'application/json',
  'Content-Type': 'application/json'
};

const _getHeaders= function(directives) {
  return  (directives && directives.customHeaders) ? directives.customeHeaders : headersForAll; // default true
}

const _getReturnJson = function (directives) {
  return  (directives && directives.jsonResponse === false) ? false : true; // default true
};

const _errorToJson = function (error,directives) {
  if(error.ok === false) {
    return (_getReturnJson(directives) ? toJSON(error) : Promise.resolve(error)).then(json => Promise.reject(json));
  }else {
    //For a client error error.ok is not received at all. This is a connection failure
    const errorToReturn ={
      errorCode:440
    };
    return Promise.reject(errorToReturn);
  }
};

const toJSON = function (response) {
  if (response) {
    if (response.json) {
      response = response.json();
    }
  } else {
    response = {};
  }
  return response;
};

const _processStatus = function (response) {
  if (response.ok) {
    return Promise.resolve(response);
  } else {
    return Promise.reject(response);
  }
};

const _fetch = function (url, options, directives) {
  return window.fetch(url, options)
    .then(_processStatus)
    .catch((error) => _errorToJson(error,directives))
    .then(response => _getReturnJson(directives) ? toJSON(response) : response);
}

// Developer note:
//
// Custom directives can be passed in that determine various settings, documented below
//
//  directives : {
//    customHeaders: { object of headers }, // use the passed in headers instead of the local _headers
//    jsonResponse: false // do this to override the default behavior to serialize the json response and return it
//  }
//

export default {
  get(uri, directives = {}) {
    const options = { method: 'GET', headers: _getHeaders(directives) };
    return _fetch(`${uri}`, options, directives);
  },

  patch(uri, dataArg, directives = {}) {
    const data = (typeof dataArg === 'object') ? JSON.stringify(dataArg) : dataArg;
    const options = { method: 'PATCH', body: data, headers: _getHeaders(directives) };
    return _fetch(`${uri}`, options, directives);
  },

  post(uri, dataArg, directives = {}) {
    const data = (typeof dataArg === 'object') ? JSON.stringify(dataArg) : dataArg;
    const options = { method: 'POST', body: data, headers: _getHeaders(directives) };
    return _fetch(`${uri}`, options, directives);
  },

  put(uri, dataArg, directives = {}) {
    const data = (typeof dataArg === 'object') ? JSON.stringify(dataArg) : dataArg;
    const options = { method: 'PUT', body: data, headers: _getHeaders(directives) };
    return _fetch(`${uri}`, options, directives);
  },

  del(uri, directives = {}) {
    const options = { method: 'DELETE', headers: _getHeaders(directives) };
    return _fetch(`${uri}`, options, directives);
  },

  head(url, directives = {}) {
    const options = { method: 'HEAD', headers: _getHeaders(directives) };
    return _fetch(`${url}`, options, directives);
  }
};
