import {createContext} from 'react';

export const ContainerHeight = createContext();
