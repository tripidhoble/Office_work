import { createBrowserHistory } from 'history';

const routeHistory = createBrowserHistory({basename: '/'});
const originalPushHandler = routeHistory.push;

const handleSameUrlClick = function(path, state) {
    const currentPath = window.location.pathname;
    const currentSearch = window.location.search;
    const pathSearchIndex = path.indexOf('?');
    const windowSearchIndex = currentSearch.indexOf('?');
    /*
        Current search will mimic the browser default value.
        Hence if search is blank then it will always be equivalent to the browser's blank string
        and the below condition to check same path will work as expected.
    */
    let pathToPush = path, searchToPush=currentSearch;
    if (pathSearchIndex !== -1) {
        searchToPush = path.substr(pathSearchIndex);
        pathToPush = path.substr(0, pathSearchIndex);
    } else if(windowSearchIndex !== -1) {
        /*
            If the browser's search string contains a question mark then it has a value.
            And from the failure of the above condition the path to push to does not have any
            search value so set the path's search value to null so taht the below condition is not satisified.
        */
        searchToPush = null;
    }

    /*
        Same URL clicked again so do not push because it will interfere with back navigation
        by adding the same URL again. Instead replace so that the browser history remains correct.
    */
    if(currentPath === pathToPush && currentSearch === searchToPush) {
        routeHistory.replace(path, state);
    }else {
        originalPushHandler(path, state);
    }
}

routeHistory.push = handleSameUrlClick;

export default routeHistory;