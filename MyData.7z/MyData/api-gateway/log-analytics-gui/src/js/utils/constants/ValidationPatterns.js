export const EMAIL_PATTERN = /[^\s@]+?@[A-Za-z0-9]{1}[^\s@]+?\.[^\s@]+?/;

export const PHONE_PATTERN = /^\+?[0-9]{1,15}$/;

export const INT_NUMBER_PATTERN = /^[0-9]+$/;

export const NAME_PATTERN = /^[A-Za-z]+?\.{0,1}[\s]*?[A-Za-z]{1}[A-Za-z\s]*?[-']{0,1}[A-Za-z]+?$/;

export const MESSAGE_PATTERN = /[^<>]+?$/;

export const LETTERS_PATTERN = /^[A-Za-z]+?$/;

export const LETTERS_WITH_SPACES_PATTERN = /^[A-Za-z]+?[A-Za-z\s]*?$/;