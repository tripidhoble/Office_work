//Mimics the $topBarHeight from the scss file; add 5px to this value so that the field does not touch the top bar.
export const TOP_BAR_HEIGHT = 75;