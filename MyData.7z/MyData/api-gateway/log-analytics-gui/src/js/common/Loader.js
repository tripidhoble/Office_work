import React, {Component} from 'react';
import { ContainerHeight } from '../utils/context/ContainerHeight';

export default class Loader extends Component {
  constructor() {
    super();
    this.state={
    };
    this.sizes={
        large:'Loader__size-large',
        medium:'Loader__size-medium',
        small:'Loader__size-small'
    };
  }

  _getLoaderMessageIfPresent() {
    const {loaderMessage} = this.props;
    let messageContainer;
    if(loaderMessage) {
        messageContainer=(
            <p>{this.props.loaderMessage}</p>
        );
    }

    return messageContainer;
  }

  render() {
    let classToApply='', centerLoaderClass='';
    const heightStyle={};
    if(this.props.alignHorizontal) {
        classToApply='Loader__full-width';
        centerLoaderClass = ' Loader__align-horizontal-center';
    }
    if(this.props.verticalAlign) {
        classToApply +=' ' + 'align-vertical-center';
        heightStyle.height = this.context;
    }
    if(this.props.additionalClass) {
        classToApply += ' ' + this.props.additionalClass;
    }
    let classWithSizeForLoader='Loader';
    const sizeOfLoader=this.sizes[this.props.size];
    if(sizeOfLoader) {
        classWithSizeForLoader = sizeOfLoader + ' ' + classWithSizeForLoader;
    }else {
        classWithSizeForLoader = this.sizes.medium + ' ' + classWithSizeForLoader;
    }
    return (
        <div className={classToApply} style={heightStyle}>
            <div className={classWithSizeForLoader + centerLoaderClass} />
            {this._getLoaderMessageIfPresent()}
        </div>
    );
  }
}

Loader.contextType = ContainerHeight;

Loader.defaultProps = {
    alignHorizontal: true
};