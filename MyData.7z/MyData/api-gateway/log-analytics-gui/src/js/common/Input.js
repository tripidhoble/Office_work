import React, {Component} from 'react';

export default class Input extends Component {

  constructor() {
    super()
    this.state = {
      focus: false
    };
  }

  inputFocus = () => {
    this.setState({focus: true});
  };

  inputBlur = () => {
    this.setState({focus: false});
    if(this.props.inputProperties.onBlur) {

      //Can be used to reset the focus props if sent
      onBlur();
    }
  };

  getErrorClassIfExists(error, errorClass) {
    let classForError = '';
    if(error) {
      classForError = 'input--container__error';
      if(errorClass) {
        classForError = errorClass;
      }
    }
    return classForError;
  }

  render() {
    const {focus} = this.state;
    const {focusField} = this.props;
    const {error, errorClass, ...rest} = this.props.inputContainerProperties;
    const {name, title, onChange, ...inputProps} = this.props.inputProperties;
    return (
      <div {...rest}
        className={'input--container border-box--size ' +
          this.getErrorClassIfExists(error, errorClass) +
          (focus || focusField ? 'input-field--focus' : '')
        }
      >
        <label htmlFor={name}>{title}</label><br/>
        <input {...inputProps} className='input--field border-box--size' name={name}
          onFocus={this.inputFocus} onChange={onChange} onBlur={this.inputBlur}
        />
      </div>
    );
  }
}