import React, {Component} from 'react';
import { ignoreMiddleButtonClickForBrowsers } from '../utils/HelperFunctions';
import { ContainerHeight } from '../utils/context/ContainerHeight';

export default class NoSuchUrl extends Component {
  constructor() {
    super();
    this._goToHomePage = this._goToHomePage.bind(this);
    this.state={
    };
    this.routeHistory = null;
  }

  componentDidMount() {
    this.routeHistory= require('../utils/RouteHistory').default;
  }

  _goToHomePage(event) {
    if(this.routeHistory) {
      event.preventDefault();
      this.routeHistory.push('/');
    }
  }

  render() {
	  return (
        <div className={'container--center-align padding-bottom--none'}>
            <div className={'align-vertical-center align-center'} style={{height: this.context}}>
                <h2>
                    {'The requested Location was not found. Go to our '} <a href='/'
                      onClick={ignoreMiddleButtonClickForBrowsers(this._goToHomePage)}> {'home page'} </a>
                </h2>
            </div>
        </div>
    );
  }
}

NoSuchUrl.contextType = ContainerHeight;
