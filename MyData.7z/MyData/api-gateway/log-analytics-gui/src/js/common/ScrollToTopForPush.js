import React, {Component} from 'react';
import { withRouter } from "react-router";

/**
    This component will be called whenever a route changes and once update is done and the child has been
    rendered, it will check whether the current history action is a push. If yes then it will take the
    component back to the top.
**/
class ScrollToTopForPush extends Component {
  componentDidUpdate() {
    if (this.props.history.action === 'PUSH') {
      window.scrollTo(0, 0);
    }
  }

  render() {
    return this.props.children;
  }
}

export default withRouter(ScrollToTopForPush);
