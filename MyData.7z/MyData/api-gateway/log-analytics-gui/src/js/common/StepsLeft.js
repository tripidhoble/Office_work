import React, {Component} from 'react';

export default class StepsLeft extends Component {

  render() {
    const {stepDescriptions, activeStep} = this.props;
    const width = `${Math.floor(100/stepDescriptions.length)}%`;
    const stepWithNumAndDesc = stepDescriptions.map( (stepDescription, index) => {
      let stepNumStatusClass = '', stepStatus = 'inactive';
      if(activeStep === index) {
        stepNumStatusClass = ' steps-left--step-num-container--active';
        stepStatus = 'active';
      } else if(activeStep > index) {
        stepStatus = 'complete';
        stepNumStatusClass = ' steps-left--step-num-container--complete';
      }

      return (
        <div key={stepDescription} style={{width}} id={'steps-left--step-container'}
          data-step-status={stepStatus}
          className={'align-items--center flex-direction--column' +
            ' display--flex position--relative'}>
          <div className={'steps-left--step-num-container display--flex' + stepNumStatusClass}>
            {index + 1}
          </div>
          <div className={'margin-top--large'}>
            {stepDescription}
          </div>
        </div>
      );
    });

    return (
      <div className={'display--flex flex-direction--row steps-left--container align-items--center'}>
        {stepWithNumAndDesc}
      </div>
    );
  }
}