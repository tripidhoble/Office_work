import React, {Component} from 'react';

export default class SVGRupeeIcon extends Component {
  constructor() {
    super();
    this.state={
    };
  }

  render() {
    return (
        <svg className={this.props.classToApply} version='1.1' id='rupee_icon' viewBox='0 0 496.158 496.158'>
            <path style={{fill: '#2d7262'}} d='M277.965,90h-50.8c-2.9-28-18-54-40.1-70h90.9c5.5,0,10-4.5,10-10s-4.5-10-10-10h-211.6c-5.5,0-10,4.5-10,10s4.5,10,10,10h60.6c41.2,0,75.2,31,80.1,70h-140.7c-5.5,0-10,4.5-10,10s4.5,10,10,10h140.7c-5,40.5-39.4,70.9-80.1,71h-60.5c-5.6,0.1-10.1,4.7-10,10.3c0,2.7,1.2,5.3,3.1,7.2l151.3,143.1c4,3.8,10.3,3.6,14.1-0.4c3.8-4.1,3.6-10.4-0.4-14.3L91.465,201h35.4c52.2,0,95.3-40,100.3-91h50.8c5.5,0,10-4.5,10-10S283.465,90,277.965,90z'/>
        </svg>
    );
  }
}