import React, {Component} from 'react';
import { ignoreMiddleButtonClickForBrowsers } from '../utils/HelperFunctions';

export default class FixedHeader extends Component {
  constructor() {
    super();
    this._goToHomePage=this._goToHomePage.bind(this);
    this._desktopLinkFocused=this._desktopLinkFocused.bind(this);
    this._desktopLinkFocusedOut=this._desktopLinkFocusedOut.bind(this);
    this._handleBlurOfLinks=this._handleBlurOfLinks.bind(this);
    this.state={
      linkFocused: false
    };
    this.routeHistory=null;
    this.blurTimeout=null;
  }

  componentDidMount() {
    this.routeHistory= require('../utils/RouteHistory').default;
  }

  _navigateToOtherNavLink(urlObject,event) {
    event.stopPropagation()
    event.preventDefault();
    const {currentActiveSection}=this.props;

    //Prevent a push or replace to a location for which there is no need.
    if(currentActiveSection !== urlObject.avoidClickOnIndex) {
        this.routeHistory.push(urlObject.url);
    }

    /*
      Once a link is clicked, the mouse out event handler will be removed and hence it will not be able to
      reset the link focused flag; hence on click, reset it as hover handling is not needed.
      As this link will be clicked multiple times, reset it only if linkFocused is already true;
      this will prevent unnecessary renders.
    */
    if(this.state.linkFocused) {
      this.setState({linkFocused: false});
    }
  }

  _desktopLinkFocused() {
    clearTimeout(this.blurTimeout);
    this.setState({linkFocused: true});
  }

  _desktopLinkFocusedOut() {
    //behavior documented in conatct us page.
    clearTimeout(this.blurTimeout);
    this.blurTimeout = setTimeout(this._handleBlurOfLinks, 1);
  }

  _handleBlurOfLinks() {
  	this.setState({linkFocused: false});
  }

  _getListOptionsForDesktop() {
    const listOptions=[];
    const {navMenu, currentActiveSection}=this.props;
    const {linkFocused} = this.state;
    let defaultHighlight='',  mouseOver, mouseOut;
    /*
      Until a link has not been selected, keep the default color to that of
      the highlighted ones. Once a link is selected let css do everything
      without using any sort of javascript.
      Attach hover events only if no link has been visited; if any have been visited then
      css will take care of the hover handling.
    */
    if(typeof currentActiveSection !== 'number') {
      mouseOver = this._desktopLinkFocused;
      mouseOut = this._desktopLinkFocusedOut;
      if(!linkFocused) {
        /*
          If the links have not been focused then add the highlight color.
          Once the links have been focused then let the links take the lighter
          color so that the current link takes the hover class defined in css
          and the other links become lighter allowing for more focus onClick
          the hovered link.
        */
        defaultHighlight=' selected-link-desktop';
      }
    }
    for(let index=0; index< navMenu.length; index++) {

      /*
        The default highlight will only be set if none of the links are clicked.
        So if none of the links are clicked the currentActiveSection check will never pass and hence
        the class names will never be duplicated. If a link is visited then
        defaultHighlight will be an empty string
      */
      let underlineDiv,activeLinkClass='nav-fixed-top-bar--link-text' + defaultHighlight;
      if(index === currentActiveSection) {

        /*
          Once a link has been selected, show it in the highlight color
          irrespective of focusing on other links.
        */
        activeLinkClass += ' selected-link-desktop';
        underlineDiv=(
          <div className={'selected-link-desktop--underline margin-vertical'}/>
        );
      }

      listOptions.push(
        <div key={navMenu[index].url} className={'nav-fixed-top-bar--link-container'}
          onClick={ ignoreMiddleButtonClickForBrowsers(
            this._navigateToOtherNavLink.bind(this,navMenu[index])
          )}>
          <a className={activeLinkClass} href={navMenu[index].url}
            onMouseOver={mouseOver} onMouseOut={mouseOut}>
            {navMenu[index].label}
          </a>
          {underlineDiv}
        </div>
      );
    }
    return listOptions;
  }

  _goToHomePage(event) {
    if(this.routeHistory) {
      event.preventDefault();
      this.routeHistory.push('/');
    }
  }

  render() {
    return (
      <header className='nav-fixed-top-bar'>
          <a href='/' className={'logo-image--container'} onClick={ignoreMiddleButtonClickForBrowsers(this._goToHomePage)}>
            <img alt={'home'} src={'/img/logo.jpg'} className={'logo-image'} />
          </a>
          <nav className='nav-fixed-top-bar--container'>
              {this._getListOptionsForDesktop().reverse()}
          </nav>
      </header>
    );
  }
}