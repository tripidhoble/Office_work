import Rest from '../utils/Rest.js';

export const getRandomDataUrl = function () {
	return '/api/route';
};

export const getAllCampaignsUrl = function () {
	return Rest.get(randomDataUrl());
};