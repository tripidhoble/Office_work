import Rest from '../utils/Rest.js';

export const randomPostUrl = function () {
    return '/api/post';
};

export const getRandomPostUrl = function (dummyRequest) {
    return Rest.post(randomPostUrl(), dummyRequest);
};
