import {
    getRandomPostUrl,
} from '../api/module2';

import {getClientSideRestError} from '../utils/HelperFunctions';

export const ACTION_INPROGRESS='ACTION_INPROGRESS';
export const ACTION_SUCCESS='ACTION_SUCCESS';
export const ACTION_FAILURE='UNLOAD_ACTION';
export const UNLOAD_ACTION='UNLOAD_ACTION';

export const capturePayment = function(dummyRequest) {
    return dispatch => {
        dispatch({type: ACTION_INPROGRESS})
        getRandomPostUrl(dummyRequest)
            .then(response => dispatch({type: ACTION_SUCCESS, response}))
            .catch(errorFromRest => {
                const error=getClientSideRestError(errorFromRest, {
                    description: 'Please try again once you have determined ' +
                        'that you can connect to the network.'
                });
                dispatch({type: ACTION_FAILURE, error});
            });
    };
};

export const unloadPaymentStatus = function() {
    return dispatch => {
        dispatch({type: UNLOAD_ACTION});
    };
};