import {
	getRandomDataUrl
} from '../api/module1';

import {getClientSideRestError} from '../utils/HelperFunctions';

export const GET_SAMPLE_DECLARATION_SUCCESS='GET_SAMPLE_DECLARATION_SUCCESS';
export const GET_SAMPLE_DECLARATION_FAILURE='GET_SAMPLE_DECLARATION_FAILURE';
export const UNLOAD_SAMPLE_DECLARATION_SUCCESS='UNLOAD_SAMPLE_DECLARATION_SUCCESS';

export const loadRandomData = function() {
    return dispatch => {
        getRandomDataUrl()
            .then(response => {
                dispatch({type: GET_SAMPLE_DECLARATION_SUCCESS, response});
            })
            .catch(errorFromRest => {
                const error=getClientSideRestError(errorFromRest, 'Please check your connection '+
                    'and try again.');
                dispatch({type: GET_SAMPLE_DECLARATION_FAILURE, error});
            });
    };
};

export const unloadRandomData = function() {
    return dispatch => {
        dispatch({type: UNLOAD_SAMPLE_DECLARATION_SUCCESS});
    };
};
