import React from 'react';
import ReactDOM from 'react-dom';
import { createStore, combineReducers, applyMiddleware  } from 'redux';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import { Router,Route } from 'react-router-dom';
import routeHistory from './utils/RouteHistory';
import App from './components/App';
import module1 from './reducer/module1';
import module2 from './reducer/module2';
import ScrollToTopForPush from './common/ScrollToTopForPush';

const startApp= function() {
	const store = createStore(
	  combineReducers({
		module1,
		module2
	  }),window.__PRELOADED_STATE__, applyMiddleware(thunk)
	);
	delete window.__PRELOADED_STATE__;

	ReactDOM.hydrate(
	  <Provider store={store}>
		{ /* Tell the Router to use our enhanced history */ }
		<Router history={routeHistory}>
            <ScrollToTopForPush>
                <Route path='/' component={App} />
            </ScrollToTopForPush>
		</Router>
	  </Provider>,
	  document.getElementById('container')
	);
}

const isPollyFillNeeded = function() {
    return !(window.Promise && window.fetch && Number.isNaN);
}

if(isPollyFillNeeded()) {
	const js = document.createElement('script');
	js.src = '/pollyfill.js';
	js.onload = function() {
		startApp();
	};
	js.onerror = function() {
		startApp();
	};
	document.head.appendChild(js);
}else {
	startApp();
}