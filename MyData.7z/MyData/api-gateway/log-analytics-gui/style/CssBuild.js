//Dummy file only to build css. Avoidede repetitive code to resolve config in both src and server config in webpack.
import css from './CustomStyleForWebsite.scss';