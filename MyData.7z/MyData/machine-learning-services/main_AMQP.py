#======================================================================================
#title           :main_AMQP.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import os
import json
import threading
import utilities.utils as utils
from utilities.logger import LogHandler
from microservice_connect.CreateConnection import create_connection

import sys
# sys.path.append(os.path.realpath("machine-learning-services"))
import warnings
warnings.filterwarnings("ignore")

utl = utils.Utils()
def main():
    log = LogHandler()
    utl = utils.Utils()
    config_data = utl._load_json(file=os.path.join(os.path.realpath("machine-learning-services"), 'config', 'mlconfig.json'))
    log.create_obj(config_data["LOG_FILENAME"])

    # AMQP connection
    connection_config_file = os.path.join(os.path.realpath("machine-learning-services"), 'config', 'AMQP_Config.json')
    with open(connection_config_file) as connection_config_json:
        connection_config_props = json.load(connection_config_json)

    connections_config = connection_config_props['connection']
    # TODO wait for connections to be started before starting execution and handle errors
    for connection_config in connections_config:
        t = threading.Thread(target=create_connection, args=(connection_config,))
        t.start()
    return None

if __name__ == "__main__":
    main()
