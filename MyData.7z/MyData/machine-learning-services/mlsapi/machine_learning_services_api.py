#======================================================================================
#title           :machine_learning_services_api.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

from abc import ABC, abstractmethod

class machine_learning_services_api(ABC):

    @abstractmethod
    def train_test_model(self, product_id = None, packages_name = None, is_train = None, ml_preprocessing_methods = None,
                         word_embedding_method = None, word_embedding_params = None, algo_name = None,
                         algo_params = None, model_validation_methods = None, action_flag_dict = None):
        pass

    @abstractmethod
    def get_ml_preprocessing_methods(self):
        pass

    @abstractmethod
    def get_all_word_embedding(self):
        pass

    @abstractmethod
    def get_all_packages(self):
        pass

    @abstractmethod
    def get_all_performance_mertrics(self):
        pass

    @abstractmethod
    def commit_model(self, product_id, train_model_id):
        pass

    @abstractmethod
    def get_model_config(self, product_id):
        pass

    @abstractmethod
    def get_all_train_models_config(self, product_id):
        pass

    @abstractmethod
    def compare_model(self, model_names = None):
        pass

    @abstractmethod
    def get_compare_model_results(self):
        pass