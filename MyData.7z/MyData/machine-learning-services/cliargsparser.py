# ======================================================================================
# title           :cliargsparser.py
# description     :
# author          :Trupti Dhoble
# date            :
# version         :0.1
# notes           :
# python_version  :3.7
# ======================================================================================

import argparse

class CLI_ArgumentParser():

    def __init__(self):
        return None

    @property
    def get_parse_args(self):
        # construct the argument parser and parse the arguments
        ap = argparse.ArgumentParser()

        # different information ids & methods
        ap.add_argument("-pr_id",
                        "--productID",
                        type=str,
                        default="productID",
                        help="product ID")

        ap.add_argument("-tr_id",
                        "--trainModelID",
                        type=str,
                        default="trainModelID",
                        help="Train Model ID to commit the model")

        ap.add_argument("-train_path",
                        "--train_csv_path",
                        type=str,
                        default=None,
                        help="folder path for train csv")

        ap.add_argument("-test_path",
                        "--test_csv_path",
                        type=str,
                        default=None,
                        help="folder path for test csv")

        ap.add_argument("-pk_name",
                        "--packagesName",
                        type=str,
                        default="packagesName",
                        choices=["scikit-learn"],
                        help="Package Name")

        ap.add_argument('-pr_methods',
                        '--mlPreprocessingMethods',
                        nargs='+',
                        default=["toLowercase", "removeExtendedSpaces",
                                 "removePunctuation", "removeStopwords",
                                 "removeSpecialCharacters", "strip"],
                        choices=["toLowercase", "removeExtendedSpaces",
                                 "removePunctuation", "removeStopwords",
                                 "removeSpecialCharacters", "strip"],
                        help="Preprocessing Methods to be applied on dataset")

        ap.add_argument("-we_type",
                        "--wordEmbeddingType",
                        type=str,
                        default="CountVectorizer_",
                        choices=["CountVectorizer_", "TfidfVectorizer_", "AVGWord2Vec_", "TFIDFWord2Vec_"],
                        help="word embedding method Type")

        ap.add_argument('-we_params',
                        '--wordEmbeddingParameters',
                        metavar="KEY=VALUE",
                        nargs='+',
                        default={},
                        help="Parameters for word embedding method")

        ap.add_argument("-algo_Name",
                        "--algorithmName",
                        type=str,
                        default="LogisticRegression_",
                        choices=["LogisticRegression_", "RandomForestClassifier_", "MultinomialNB_",
                                 "VotingClassifier_", "KNN_"],
                        help="Algorithm Name")

        ap.add_argument('-algo_params',
                        '--alogrithmParameters',
                        metavar="KEY=VALUE",
                        nargs='+',
                        default={},
                        help="Parameters for algorithm ")

        ap.add_argument('-val_methods',
                        '--modelValidationMethods',
                        nargs='+',
                        default=["accuracy", "precision", "recall", "f1_score", "classification_report"],
                        choices=["accuracy", "precision", "recall", "f1_score", "classification_report"],
                        help="Model Validation Methods")

        # action Flags
        ap.add_argument("-param_tunning_Flag",
                        "--isHyperParameterTuning",
                        type=int,
                        default=0,
                        choices=[0, 1],
                        help="hyper Parameter tuning flag")

        ap.add_argument("-act_Flag",
                        "--actionFlag",
                        metavar="KEY=VALUE",
                        nargs='+',
                        default={"preprocessing_Flag": 1,"word_embedding_Flag":1, "buildModel_Flag":1 },
                        help="action flag")

        ap.add_argument("-tr_Flag",
                        "--isTrain",
                        type=int,
                        default=1,
                        choices=[0, 1],
                        help="test flag (to skip the test file prediction)")

        ap.add_argument("-mls",
                        "--machine_learning_service",
                        type=str,
                        default=None,
                        choices=[ "train_test_model", "get_packages", "get_word_embedding_methods" , "get_preprocessing_methods",
                                  "get_performance_metircs", "get_comparison_results", "commit_model", "get_model_config",
                                  "get_all_train_models_config"])

        args = vars(ap.parse_args())
        return args

