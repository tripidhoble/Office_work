from microservice_connect.AmqpConnection import AmqpConnection
from microservice_connect.AmqpConnectionFactory import AmqpConnectionFactory
from utilities.constants import AMQP_PROTOCOL
import logging

def connection_stopped(stop_info):
  logging.warning("Connection stopped because: %s" % stop_info)

def connection_error(error_info):
  logging.error("Connection brokedn because of an error, reason: %s" % error_info)

def establish_amqp_connection(connection_prop):
  amqp_connection_lib = AmqpConnectionFactory(connection_prop).protocol_factory()
  amqp_connection = AmqpConnection(connection_prop, amqp_connection_lib)
  amqp_connection.establish_connection(connection_stopped, connection_error)

def create_connection(connection_config):
  if connection_config['protocol'] == AMQP_PROTOCOL:
    establish_amqp_connection(connection_config['properties'])