from pythonamqplibrary import RabbitMqConnectionImpl
from utilities.constants import RABBIT_MQ_CLIENT
import logging
import sys

class AmqpConnectionFactory:
    def __init__(self, connection_prop):
        self.connection_prop = connection_prop

    def protocol_factory(self):
        client_lib = None
        if self.connection_prop['client'] == RABBIT_MQ_CLIENT:
            client_lib = RabbitMqConnectionImpl()
        return client_lib