import sys
import logging
import threading
import executionfunctions.processMessage as processMessage
from utilities.constants import EXCHANGE_TYPE_DIRECT
from pythonamqplibrary import ConnectionDetails, ExchangeDetails, StatusValues
from pythonamqplibrary.ConnectionExceptions.InputExceptionClass import ChannelWrongNameError, NoQueueError

class AmqpConnection:
    def __init__(self, connection_properties, client_lib):
        self.connection_properties = connection_properties
        self.client_lib = client_lib

        # The args_param and kwargs_param represents the *args and **kwargs
        # Since this method is called as a callback, the original *args and **kwargs is
        # passed as regular parameters to it. Hence kwargs_param will be a dictionary
        # and args_param will be a tuple similar to *args and **kwargs
    def process_message_callback(self, client_lib_from_cb, channel_name, delivery_tag, args_param, kwargs_param):
        # Acknowledge the message when convenient
        try:
            publish_queue_name = kwargs_param.get('publish_queue_name')
            message_to_publish = kwargs_param.get('message_to_publish')

            if publish_queue_name and message_to_publish:
                self.client_lib.publish_message(channel_name, publish_queue_name, message_to_publish)

            self.client_lib.basic_ack(delivery_tag, channel_name)
        except ChannelWrongNameError as channel_name_error:
            print(str(channel_name_error))

    def process_message(self, channel_name, queue_name, delivery_tag, message):
        print(message)
        processMsg_obj = processMessage.processMessage()
        channels_to_save = self.connection_properties['channelProperties']

        publish_queue_name = None
        messageToPublish = processMsg_obj.processAmqpMessage(message)
        for channel_attributes in channels_to_save:
            if channel_name == channel_attributes['channelName']:
                publish_queue_name = channel_attributes['queuesToBind'][0]
                break
        self.client_lib.invoke_threadsafe_callback(self.process_message_callback, channel_name,
                delivery_tag, publish_queue_name=publish_queue_name,
                message_to_publish=messageToPublish)

    def message_callback(self, client_lib_from_cb, channel_name, queue_name, delivery_tag, message):
        thread = threading.Thread(target=self.process_message, args=(channel_name,
            queue_name, delivery_tag, message))
        thread.start()

    '''
        Track the channel status for the particular channel name
    '''
    def _channel_status_callback_closure(self, channel_name, queue_name):

        def channel_status_callback(client_lib_from_cb, status, exception=None):
            if status == StatusValues.ChannelStatus.OPENED.value:

                try:
                    self.client_lib.consume_message(channel_name, queue_name, self.message_callback)
                except ChannelWrongNameError as channel_name_error:
                    print(str(channel_name_error))
                except NoQueueError as no_queue_error:
                    print(str(no_queue_error))
            else:
                #TODO handle channel closure and error scenario
                pass

        return channel_status_callback

    '''
        Track whether or not the message was published on the channel name
    '''
    def _publish_confirmation_closure(self, channel_name):
        #TODO handle message publishing
        def publish_confirmation(client_lib_from_cb, publish_status):
            pass

        return publish_confirmation

    def _connection_status_callback_closure(self, stop_handler, error_handler):
        def connection_status_callback(client_lib_from_cb, type, exception=None):

            # Connection started, setup all channel conections
            if type == StatusValues.ConnectionSetupStatus.STARTED.value:
                logging.info("Connection setup to '{0}' on port '{1}'".format(self.connection_properties['host'], self.connection_properties['port']))
                channels_to_save = self.connection_properties['channelProperties']
                for channel_attributes in channels_to_save:
                    channel_name = channel_attributes['channelName']

                    #TODO pick the one that is to be used for consumption
                    queue_name = channel_attributes['queuesToBind'][1]
                    try:
                        self.client_lib.create_channel(channel_name,
                            self._channel_status_callback_closure(channel_name, queue_name),
                            self._publish_confirmation_closure(channel_name))
                    except ChannelWrongNameError as channel_name_error:
                        print(str(channel_name_error))
            elif type == StatusValues.ConnectionSetupStatus.STOPPED:
                stop_handler(exception)
            else:
                error_handler(exception)

        return connection_status_callback

    def establish_connection(self, stop_handler, error_handler):
        try:
            connection_details = ConnectionDetails(self.connection_properties['host'],
                                                    self.connection_properties['port'],
                                                    self.connection_properties['virtualHost'],
                                                    self.connection_properties['username'],
                                                    self.connection_properties['password'])
            self.client_lib.set_connection_details(connection_details)

            channels_to_save = self.connection_properties['channelProperties']
            for channel_attributes in channels_to_save:
                if channel_attributes['exchangeType'] == EXCHANGE_TYPE_DIRECT:
                    exchange_type = self.client_lib.ExchangeTypes.DIRECT.value
                else:
                    exchange_type = self.client_lib.ExchangeTypes.FANOUT.value

                channel_details = ExchangeDetails(channel_attributes['channelName'],
                    exchange_type, channel_attributes['exchangeName'],
                    channel_attributes['queuesToBind'])
                self.client_lib.set_channel_exchange_properties(channel_details)

            self.client_lib.create_connection(self._connection_status_callback_closure(stop_handler,
                error_handler))

        except Exception as err:
            logging.error("AMQP: Failed to establish Connection: %s" % err)
            sys.exit(err)