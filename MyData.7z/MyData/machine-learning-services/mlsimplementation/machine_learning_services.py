# ======================================================================================
# title           :machine_learning_services.py
# description     :
# author          :Vishal Chauhan
# date            :
# version         :0.1
# notes           :
# python_version  :3.7
# ======================================================================================
import os
import sys
import logging
import utilities.utils as utils
from mltraintest.test import Test
from mltraintest.train import Train
import mlbuildmodel.build_model as bmodel
import mlwordembedding.word_embedding as wemb
import mlmodelvalidation.model.metrics as metrics
import mlsapi.machine_learning_services_api as API
import mlprepocessing.ml_preprocessing_utils as mlp

class machine_learning_services(API.machine_learning_services_api):

    def __init__(self):
        '''
        Initializing ml services
        :param train_csv_path: training dataset path
        :param test_folder_path: test dataset path
        :param temp_path: temporary location for storing model and files before commiting
        :param output_path: Permanent location for string model and its related files
        :return: None
        '''
        try:
            logging.info("Initialising ml services .......")
            self.utl = utils.Utils()
            self.config_data = self.utl._load_json(file=os.path.join(os.path.realpath("machine-learning-services"),'config','mlconfig.json'))
            self.homedir = self.utl.get_homedir()
            self.cwd = os.path.realpath("machine-learning-services")
            return None

        except Exception as err:
            logging.error("Error while initialising ml service")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def train_test_model(self, product_id, is_train , ml_preprocessing_methods,
                         word_embedding_method, action_flag_dict=None, is_HyperParameterTuning = 0, word_embedding_params=None,
                         algo_name=None,algo_params=None, model_validation_methods=None, train_csv_path=None, test_csv_path=None):
        '''
        Method used for both training and testing
        :param product_id: Product ID
        :param is_train: 0/1  (0-test, 1-train)
        :param ml_preprocessing_methods: List  of methods of ml preprocessing
        :param word_embedding_method: Word embedding method
        :param word_embedding_params: Word embedding method parameters
        :param algo_name: Algorithm Name
        :param algo_params: Algorithm Parameters
        :param model_validation_methods: Model validation metrics
        :param action_flag_dict: Flags for performing actions
        :param train_csv_path: train csv path
        :param test_folder_path: test folder path
        :return: None
        '''
        try:
            output_dir = os.path.join(self.homedir, self.config_data['OUTPUT_DIRECTORY_NAME'], product_id)
            if is_train == 1 or int(is_train)==1 :
                logging.info("Performing Training on dataset....")

                # LOGIC for creating incremental folder name under same product
                temp_path_orig = os.path.join(self.homedir, self.config_data['TEMP_TRAINED_MODELS_FOLDER_NAME'], self.config_data['SERVICE_NAME'], product_id)
                i = 1
                temp_path = os.path.join(temp_path_orig, "Model_"+str(i))
                while os.path.exists(temp_path):
                    i += 1
                    temp_path = os.path.join(temp_path_orig, "Model_"+str(i))

                if (train_csv_path==None):
                    train_csv_path = os.path.join(self.cwd, self.config_data['TRAIN_DATA_FOLDER_NAME'], product_id, self.config_data["TRAIN_FILENAME"])
                    if not os.path.exists(train_csv_path):
                        train_csv_path = os.path.join(self.homedir, self.config_data['TRAIN_DATA_FOLDER_NAME'], product_id,
                                                  self.config_data["TRAIN_FILENAME"])
                        if not os.path.exists(train_csv_path):
                            raise Exception(" train data not found at location ", train_csv_path)
                tr_obj = Train(train_csv_path=train_csv_path, output_dir = temp_path)
                model_validation_report = tr_obj.train_model(
                                    isHyperParameterTuning = is_HyperParameterTuning,
                                    preprocessing_filters_list = ml_preprocessing_methods,
                                    word_embedding_method = word_embedding_method,
                                    ref_model = algo_name,
                                    params_dict = {word_embedding_method : word_embedding_params, algo_name : algo_params},
                                    model_validation_methods_list = model_validation_methods,
                                    action_flag_dict = action_flag_dict
                                    )
                model_configuration = {
                                        "isHyperParameterTuning" : is_HyperParameterTuning,
                                        "preprocessing_filters_list" : ml_preprocessing_methods,
                                        "word_embedding_method" : word_embedding_method,
                                        "word_embedding_params" : word_embedding_params,
                                        "ref_model" : algo_name,
                                        "algo_params":algo_params,
                                        "model_validation_methods_list" : model_validation_methods,
                                        "action_flag_dict" : action_flag_dict
                                      }
                self.utl._dump_json(file_name=self.config_data["MODEL_CONFIG_FILENAME"], data=model_configuration,
                                         path=temp_path)
                return model_validation_report
            else:
                logging.info("Performing predication on model")
                print("Performing predication on model")
                model_dir = os.path.join(output_dir, self.config_data["MODEL_DIRECTORY_NAME"])
                if (test_csv_path == None):
                    test_csv_path = os.path.join(self.cwd, self.config_data['TEST_DATA_FOLDER_NAME'], product_id, self.config_data["TEST_FILENAME"])
                    if not os.path.exists(test_csv_path):
                        test_csv_path = os.path.join(self.homedir, self.config_data['TEST_DATA_FOLDER_NAME'],
                                                      product_id,
                                                      self.config_data["TEST_FILENAME"])

                test_dataset = self.utl._loadCSVToDataframe(test_csv_path)
                test_obj = Test()

                print("Predicting Log Type for Test dataset saved at location {}".format(test_csv_path))
                pred_dataset,y_prob_labels = test_obj.test_data(dataset = test_dataset,
                                                                preprocessing_filters_list=ml_preprocessing_methods,
                                                                word_embedding_method=word_embedding_method,
                                                                model_dir=model_dir)

                self.utl._save_DataframeToCSV(dataset = pred_dataset,
                                              output_dir = output_dir ,
                                              file_name = self.config_data["PRED_TEST_FILENAME"])

                analysed_test_result = self.utl.test_result_analysis(dataset=pred_dataset,
                                                                          prob_threshold=float(self.config_data["PROBABILITY_THRESHOLD"]),
                                                                          labels=y_prob_labels)
                self.utl._dump_json(file_name=self.config_data["TEST_RESULT_FILENAME"],
                                    data=analysed_test_result,
                                    path=output_dir)
                print("Test Results for test data saved as '{}' at path {}".format(self.config_data["TEST_RESULT_FILENAME"],
                                os.path.join(output_dir, self.config_data["TEST_FILENAME"])))
                return analysed_test_result
        except Exception as err:
            logging.error("Error while performing train or test operation")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def get_ml_preprocessing_methods(self):
        '''
        :input: None
        :return: Return all preprocessing method names
        '''
        try:
            logging.info("Retreiving ml preprocessing methods name")
            obj = mlp.mlpreprocessing_util()
            return obj.all_methods_names()
        except Exception as err:
            logging.error("Error while retrieving ml preprocessing methods")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def get_all_word_embedding(self):
        '''
        :input: None
        :return: Return all word embedding method names
        '''
        try:
            logging.info("Retrieving word embedding methods")
            obj = wemb.wordembedding()
            return obj.get_word_embedding_methods()
        except Exception as err:
            logging.error("Error while retrieving word embedding methods")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def get_all_packages(self):
        '''
        :input: None
        :return: Return all packages that are supported in product
        '''
        try:
            logging.info("Retrieving package names")
            bm_obj = bmodel.BuildModel()
            return bm_obj.get_algorithm_names()
        except Exception as err:
            logging.error("Error while retrieving packages name")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def get_all_performance_mertrics(self):
        '''
        :input: None
        :return: Return all performance metrics method names
        '''
        try:
            logging.info("Retrieving performance metircs")
            obj = metrics.Metrics()
            return obj.get_performance_metircs_name()
        except Exception as err:
            logging.error("Error while retrieving performance metrics name")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def commit_model(self, product_id, train_model_id):
        '''
        :param product_id: Product ID
        :param train_model_id: train model ID
        :return: None
        '''
        try:
            logging.info("Commiting the model")
            output_path = os.path.join(self.homedir, self.config_data["OUTPUT_DIRECTORY_NAME"], product_id)
            train_path = os.path.join(self.homedir, self.config_data['TEMP_TRAINED_MODELS_FOLDER_NAME'], self.config_data['SERVICE_NAME'], product_id, train_model_id)
            if not os.path.exists(train_path):
                raise Exception("Train model path is invalid for trainModelId:'{}'!".format(train_model_id))
            if os.path.exists(output_path):
                self.utl.remove_directory(output_path)
            logging.info("Creating directory" + output_path)
            os.makedirs(output_path)
            self.utl.move_all_files_in_dir(src_dir=train_path, dst_dir=output_path)
            self.utl.remove_directory(train_path)
            return None
        except Exception as err:
            logging.error("Error while commiting the model")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def get_model_config(self,product_id):
        '''
        :param product_id: Product ID
        :return: None
        '''
        try:
            logging.info("getting model config for commited model")
            config_path = os.path.join(self.homedir, self.config_data["OUTPUT_DIRECTORY_NAME"], product_id, self.config_data['MODEL_CONFIG_FILENAME'])
            modelConfig = self.utl._load_json(config_path)
            return modelConfig
        except Exception as err:
            logging.error("Error while getting model config for commited model")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def get_all_train_models_config(self,product_id):
        '''
        :param product_id: Product ID
        :return: None
        '''
        try:
            logging.info("getting model config for all train models")
            config_path = os.path.join(self.homedir, self.config_data["TEMP_TRAINED_MODELS_FOLDER_NAME"], self.config_data['SERVICE_NAME'], product_id)
            filename =  self.config_data['MODEL_CONFIG_FILENAME']
            modelConfigs = []
            for r, d, f in os.walk(config_path):
                for file in f:
                    if filename in file:
                        model_config = {}
                        config_path = os.path.join(r, file)
                        model_id = os.path.split(r)[-1]
                        model_config['name'] = model_id
                        model_config.update(self.utl._load_json(config_path))
                        modelConfigs.append(model_config)
            return modelConfigs
        except Exception as err:
            logging.error("Error while getting model config for all train models")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def compare_model(self, model_names=None):
        pass

    def get_compare_model_results(self):
        pass