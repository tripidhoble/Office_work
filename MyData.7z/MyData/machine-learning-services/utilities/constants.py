AMQP_PROTOCOL = 'amqp'

RABBIT_MQ_CLIENT = 'rabbitMQ'

EXCHANGE_TYPE_DIRECT = 'direct'
