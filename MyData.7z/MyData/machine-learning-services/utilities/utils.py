#======================================================================================
#title           :utils.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import re
import os
import sys
import json
import shutil
import pickle
import gensim
import logging
import errno, stat
import numpy as np
import pprint as pp
import pandas as pd
from glob2 import glob
from numpy import genfromtxt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

class Utils():

    def __init__(self):
        self.config_data = self._load_json(file=os.path.join(os.path.realpath("machine-learning-services"), 'config', 'mlconfig.json'))
        self.homedir = os.path.join(os.path.expanduser("~"), self.config_data["HOME_DIRECTORY_FOLDER_NAME"])
        if not os.path.exists(self.homedir):
            os.makedirs(self.homedir)
        return None

    def _label_separator(self, df):
        '''
        Seprating df into X and y
        '''
        try:
            X = df['Log_Data']
            y = df['Label']
            logging.info("Separated 'Log_Data' and 'label'.")
            return X,y
        except Exception as err:
            logging.error("Error occuring while Seprating Dataframe")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _label_encoding(self, series):
        '''
        Lable Encoding
        :param series: Data in series format
        :return: Encoder and Encoded Data
        '''
        try:
            le = LabelEncoder()
            series = le.fit_transform(series)
            logging.info("Label Encoding done.")
            return le,series
        except Exception as err:
            logging.error("Error occuring while Encoding Data")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _train_test_split(self, X, y):
        '''
        Spliting data into train and test
        :param X: Data
        :param y: Label
        :return: splited data for train and test
        '''
        try:
            X_train, X_valid, y_train, y_valid = train_test_split(X, y, random_state=0, test_size=0.3)
            logging.info("Separated training and validation data using train_test_split.")
            return X_train, X_valid, y_train, y_valid
        except Exception as err:
            logging.error("Error occuring while spliting train and test data")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _save_model(self, model, filename, output_dir):
        '''
        Saving the model in a particular directory
        :param model: model
        :param filename: name of model
        :param output_dir: path where model to be saved
        :return: None
        '''
        try:
            pickle.dump(model, open(os.path.join(output_dir, filename), 'wb'))
            logging.info("{} Model saved successfully .".format(filename))
            return None
        except Exception as err:
            logging.error("Error occuring saving model")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _save_DataframeToCSV(self, dataset, output_dir, file_name):
        '''
        Saving DataFrame to csv
        :param dataset: DataFrame
        :param output_dir: Path
        :param file_name: Name of file to be saved
        :return: path
        '''
        try:
            preprocessed_csv_path = os.path.join(output_dir, file_name)
            dataset.to_csv(preprocessed_csv_path)
            logging.info("Dataframe saved at : {}".format(preprocessed_csv_path))
            return preprocessed_csv_path
        except Exception as err :
            logging.error("Error occuring while saving dataframe to csv")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _loadW2VModel(self, w2v_path):
        '''
        Load Word2vec model
        :param w2v_path: Path of Word2Vec model
        :return: return W2V model
        '''
        try:
            logging.info("Loading Word2Vec Model from path {}".format(w2v_path))
            w2v_model = gensim.models.Word2Vec.load(w2v_path)
            return w2v_model
        except Exception as err :
            logging.error("Error while loading Word2Vec Model")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _loadCSVToDataframe(self, csv_path, **kwargs):
        '''
        Load csv file into data frame
        :param file: Path of csv file
        :return: Return DataFrame
        '''
        try:
            logging.info("Loading {} CSV into DataFrame".format(csv_path))
            df = pd.read_csv(csv_path, encoding = "ISO-8859-1",**kwargs)
            return df
        except Exception as err :
            logging.error("Error while loading csv to DataFrame")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def readFromPickle(self, path):
        '''
        Read data from the pickle file
        :param path: Path of the pickle file
        :return: dictionary of pickle's data
        '''
        try:
            logging.info("Loading pickle file from path {}".format(path))
            pickle_in = open(path, "rb")
            return dict(pickle.load(pickle_in))
        except Exception as err:
            logging.error("Error while loading Pickle file")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def dumpPickle(self, path, file_name, data):
        '''
        Save pickle file to particular path
        :param path: Path where file being saved
        :param file_name: Name of the pickle file
        :param data: Data to be saved in pickle file
        :return: Path of pickle file
        '''
        try:
            logging.info("Dumping pickle file on location :{0} with name :{1}".format(path, file_name))
            pickle_file_path = os.path.join(path, file_name)
            pickle.dump(data, open(pickle_file_path, 'wb'))
            return pickle_file_path
        except Exception as err :
            logging.error("Error while dumping/saving Pickle file")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def convertDocIntoListofSent(self, data):
        '''
        Convert the document text into sentences
        :param data: Document's data
        :return: Return data in sentence form
        '''
        try:
            logging.info("Converting Document into sentence")
            list_of_sentance = []
            for sentance in data:
                list_of_sentance.append(sentance.split())
            return list_of_sentance
        except Exception as err :
            logging.error("Error occuring while convering Document to sentences")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _save_CSRMatrixArrayAsCSV(self,csrMatrix,path,filename):

        try:
            csrMatrix_array= csrMatrix.toarray()
            filename = filename + ".csv"
            csv_path = os.path.join(path, filename)
            np.savetxt(csv_path, csrMatrix_array, delimiter=",")
            logging.info("Vectorization data saved at '{}' as '{}'".format(path,filename))
            return csv_path
        except Exception as err:
            logging.error("Error occurring while saving to csv")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _convert_CSVToArray(self, csv_path):
        try:
            logging.info("Converting CSV to Array")
            array = genfromtxt(csv_path, delimiter=',')
            return array
        except Exception as err:
            logging.error("Error occurring while converting csv to array")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _convert_DfToArray(self, dataset):
        '''
        Converting DataFrame to Array
        :param dataset: DataFrame
        :return: Array
        '''
        try:
            logging.info("Converting DataFrame to Array")
            array = dataset.to_numpy()
            return array
        except Exception as err:
            logging.error("Error occuring while converting DataFrame to Array")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _dump_json(self, file_name, data, path):
        '''
        Dumps data in the json file at particular location
        :param data: Data in dict format
        :param path: Path where data to be saved
        :return: None
        '''
        try:
            file_with_path = os.path.join(path, file_name)
            logging.info("Saving json file : {}".format(file_with_path))
            with open(file_with_path, 'w') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
        except Exception as err:
            logging.error("Error occurring while saving JSON file")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _load_json(self,file):
        '''
        Return json file data in dict format
        :param file: file name
        :return: Data in dict format
        '''
        try:
            logging.info("Reading json file at :" + file)
            with open(file) as json_data_file:
                data = json.load(json_data_file)
            return data
        except Exception as err:
            logging.error("Error occurring while loading the JSON file")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def move_all_files_in_dir(self,src_dir, dst_dir):
        '''
        Move file from one directiry to another
        :param src_dir: Source Directory
        :param dst_dir: Destination Directory
        :return: None
        '''
        try:
            logging.info("Moving files from {} to {}".format(src_dir,dst_dir))
            # Check if both the are directories
            if os.path.isdir(src_dir) and os.path.isdir(dst_dir):
                # Iterate over all the files in source directory
                for filePath in glob(src_dir + '\*'):
                    # Move each file to destination Directory
                    shutil.move(filePath, dst_dir)
            else:
                logging.error("Source or Destination are not correct")
                sys.exit()
        except Exception as err:
            logging.error("Error occurring while moving files")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def handle_remove_readonly(self, func ,path, exc):
        '''
        Handle files while removing directory
        :param func: Function name
        :param path: Path
        :param exc: Handler
        :return: None
        '''
        excvalue = exc[1]
        if func in (os.rmdir, os.remove) and excvalue.errno == errno.EACCES:
            os.chmod(path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 0777
            func(path)
        else:
            logging.error("Error")

    def remove_directory(self, path):
        try:
            logging.info("Removing directory"+path)
            shutil.rmtree(path, ignore_errors=False, onerror=self.handle_remove_readonly)
            return None
        except Exception as err:
            logging.error("Error occurring while removing directory")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def test_result_analysis(self, dataset, prob_threshold, labels):
        try:
            logging.info("analysing the test result")
            if "Ticket_Name" not in dataset.columns:
                logging.info("Extracting the Ticket No. from File Name")
                ticket = []

                for i in dataset['File Name']:
                    temp = re.findall(r'\d+', i)
                    if not temp:
                        logging.info("List is empty")
                        temp = ["Unknown"]
                    ticket.append(temp[0])
                dataset['Ticket_Name'] = ticket

            Tickets = list(set(dataset["Ticket_Name"]))
            result_dict = {}
            for ticket in Tickets:
                result_ticket = dataset.loc[dataset["Ticket_Name"] == ticket]
                prob_columns = result_ticket.loc[:, labels]
                columns_with_max_prob = list(prob_columns.idxmax(axis=1))
                dict = {}
                for row, column in zip(prob_columns.itertuples(), columns_with_max_prob):
                    row_value = getattr(row, column)
                    if column not in dict.keys():
                        if row_value > prob_threshold:
                            dict[column] = row_value
                    else:
                        dict[column] = max(dict[column], row_value)
                new_dict = sorted(dict.items(), key=lambda kv: kv[1], reverse=True)
                result_dict[ticket] = new_dict
            print("\n Prediction of Log Type as per Ticket No. : \n")
            pp.pprint(result_dict)
            return result_dict
        except Exception as err:
            logging.error("Error while processing test dataset")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def save_text_file(self, file_name, file_path, data):
        file = open(os.path.join(file_path,file_name), "w")  # write mode
        file.write(data)
        file.close()

    def get_homedir(self):
        return self.homedir

    def convert_dict_params(self,param_dict):
        try:
            for key,value in param_dict.items():
                try:
                    if ((value[0] == '(') and (value[-1] == ')')):
                        param_dict[key] = tuple([int(x) for x in value[1:-1].split(",")])
                    elif ((value[0] == '[') and (value[-1] == ']')):
                        param_dict[key] = [int(x) for x in value[1:-1].split(",")]
                    else:
                        param_dict[key] = int(value)
                except:
                    pass
            return param_dict
        except Exception as err:
            logging.error("Error while converting params {}".format(param_dict[key]))
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def parse_vars(self, items):
        """
        Parse a series of key-value pairs and return a dictionary
        """
        try:
            dict = {}
            if items:
                for item in items:
                    param = item.split('=')
                    key = param[0].strip()  # we remove blanks around keys, as is logical
                    if len(param) > 0:
                        value = param[1:][0]
                        if ((value[0] == '(') and (value[-1] == ')')):
                            value = tuple([int(x) for x in value[1:-1].split(",")])
                        elif ((value[0] == '[') and (value[-1] == ']')):
                            value = [int(x) for x in value[1:-1].split(",")]
                        else:
                            try:
                                value = int(value)
                            except:
                                pass
                    dict[key] = value
        except Exception as err:
            logging.error("Error while parsing cli arguments {}".format(items))
            logging.error("Error: {}".format(err))
            sys.exit(err)
        return dict


