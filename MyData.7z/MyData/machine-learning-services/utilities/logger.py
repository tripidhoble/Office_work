#======================================================================================
#title           :logger.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================
import utilities.utils as utils
import logging
import os

class LogHandler():
    def __init__(self):
        pass

    def create_obj(self, logfilename):
        try:
            # This is to configure logger which will reflect for all import in project
            utl = utils.Utils()
            homedir = utl.get_homedir()
            config_data = utl._load_json(file=os.path.join(os.path.realpath("machine-learning-services"),'config', 'mlconfig.json'))
            logdir_name = config_data['LOG_DIRECTORY_NAME']
            logdir_path = os.path.join(homedir, logdir_name)
            if not os.path.exists(logdir_path):
                os.makedirs(logdir_path)
            logpath = os.path.join(homedir, logdir_name, logfilename)

            #remove other instances of log handler
            for handler in logging.root.handlers[:]:
                logging.root.removeHandler(handler)

            #configure format for logs
            FORMAT = "[%(asctime)s:  %(filename)s  :%(lineno)s  :%(funcName)20s()] -> %(message)s"
            logging.basicConfig(format=FORMAT, filename=logpath, level=logging.DEBUG)
            logging.info("Logging initialized!")
            return logging

        except AttributeError:
            print("Attribute Error occured")
        except Exception as err:
            print("Exception in logging", err)