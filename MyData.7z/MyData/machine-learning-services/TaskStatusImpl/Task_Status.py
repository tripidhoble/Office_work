import pymongo
import pprint
import logging
import sys

class TaskStatusOperations:

    def __init__(self):
        self.j_db = ''
        self.task_status = ''

    def connect_db(self, db_name):
        """
        Purpose:
            Connect to a specific database in MongoDB
            Initialize all collections - Filter Collection, Product Collection

        Args:
            - db_name : Database (jarvis_db) to be connected
        """
        try:
            self.jarvis_client = pymongo.MongoClient()  # Connect to MongoClient
            self.j_db = self.jarvis_client[db_name]  # Create a Database (jarvis_db)
            # Status Initialization
            self.task_status = self.j_db['task_status']
            logging.info("Connection Initialized")

        except Exception as err:
            print("connect_db_Error: Failed to connect to DB and initialize Tables -", err)
            logging.error("connect_db_Error: Failed to connect to DB and initialize Tables - %s" % err)
            sys.exit(err)

    def add_status_rule(self, task_id, command):
        """
        Purpose:
            Add status of taskID in MongoDB

        Args:
            - task_id        : Unique task ID
            - command       : Command
        """
        try:
            self.connect_db("jarvis_db")
            status_list = {'_id': task_id, 'command': command, 'taskStatus': 'INPROGRESS'}
            self.task_status.insert(status_list)
            # Informs user about successful addition of product rule to MongoDB
            print('add_status_rule: Successfully added for taskID - ', task_id)
            print('*' * 80)
            logging.info('add_status_rule: Successfully added for taskID- %s', task_id)

        except Exception as err:
            print("add_status_rule: -", err)
            logging.error("add_status_rule: - %s", err)
            sys.exit(err)

    def update_status_rule(self, task_id, status):
        """
        Purpose:
            Update status of taskID

        Arguments:
            task_id : Task_ID
            status:  Status of taskID

        Return:
            Return all predefined filters from config file
        """
        try:
            self.connect_db("jarvis_db")
            logging.info('Initiated update status')
            self.task_status.update(
                {'_id': task_id}, {"$set": {"taskStatus": status}})
            logging.info("Updated status on Task ID: %s" % task_id)
            return 1

        except Exception as err:
            print("update_status_rule:  -", err)
            logging.error("update_status_rule: - %s" % err)
            sys.exit(err)

    def get_status_rule(self, task_id, command):
        """
        Purpose:
            Get status of taskID

        Arguments:
            task_id : Task_ID

        Return:
            Return status
        """
        try:
            self.connect_db("jarvis_db")
            logging.info('Initiated get status')
            query = {'_id': task_id, 'command': command}
            queried_product = self.task_status.find(query)
            logging.info("Getting Status of TaskID: %s" % task_id)
            return queried_product[0]['taskStatus']

        except Exception as err:
            print("get_status_rule:  -", err)
            logging.error("get_status_rule: - %s" % err)
            sys.exit(err)

if __name__ == "__main__":
    f = TaskStatusOperations()
    f.connect_db("jarvis_db")
    print(f.add_status_rule(task_id = 1, command = "hello"))
    print(f.update_status_rule(task_id=1, status="Fail"))
    print(f.get_status_rule(task_id=1,command="hello"))