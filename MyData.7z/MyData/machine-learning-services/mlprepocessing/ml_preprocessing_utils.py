#======================================================================================
#title           :ml_preprocessing_utils.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import sys
import logging
import mlprepocessing.ml_preprocessing as mlp

class mlpreprocessing_util():

    def all_methods_names(self):
        '''
        :input: None
        :return: All Methods name that are implemented in this class
        '''
        try:
            return ['removeExtendedSpaces', 'toLowercase', 'removePunctuation', 'replaceNumbersWithText', 'removeStopwords',
                    'stemWords', 'lemmatizeVerbs', 'removeSpecialCharacters', 'strip']
        except Exception as err:
            logging.error("Error while fetching method names")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def applyPreprocessing(self, dataset, preprocessing_filter_methods_list):
        mlp_obj = mlp.MlPreprocessing()
        LOG_DATA_LABEL = 'Log_Data'
        try:
            if 'toLowercase' in preprocessing_filter_methods_list:
                dataset = mlp_obj._toLowercase(dataset, LOG_DATA_LABEL)
            
            if 'removeStopwords' in preprocessing_filter_methods_list:
                dataset = mlp_obj._removeStopwords(dataset, LOG_DATA_LABEL)
                
            if 'removePunctuation' in preprocessing_filter_methods_list:
                dataset = mlp_obj._removePunctuation(dataset, LOG_DATA_LABEL)
            
            if 'removeExtendedSpaces' in preprocessing_filter_methods_list:
                dataset = mlp_obj._removeExtendedSpaces(dataset, LOG_DATA_LABEL)
            
            if "strip" in preprocessing_filter_methods_list:
                dataset.Log_Data = dataset.Log_Data.str.strip('\n\t')
            
            if 'replaceNumbersWithText' in preprocessing_filter_methods_list:
                dataset = mlp_obj._replaceNumbersWithText(dataset, LOG_DATA_LABEL)
                
            if 'stemWords' in preprocessing_filter_methods_list:
                dataset = mlp_obj._stemWords(dataset, LOG_DATA_LABEL)
                
            if 'lemmatizeVerbs' in preprocessing_filter_methods_list:
                dataset = mlp_obj._lemmatizeVerbs(dataset, LOG_DATA_LABEL)
                
            if 'removeSpecialCharacters' in preprocessing_filter_methods_list:
                dataset = mlp_obj._removeSpecialCharacters(dataset, LOG_DATA_LABEL)
                
            return dataset

        except Exception as err:
            logging.error("Error while performing ml preprocessing service")
            logging.error("Error: {}".format(err))
            sys.exit(err)