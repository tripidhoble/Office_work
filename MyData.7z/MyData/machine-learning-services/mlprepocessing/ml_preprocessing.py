#======================================================================================
#title           :ml_preprocessing.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import sys
import logging
import inflect
import pandas as pd
from string import punctuation
from nltk.stem import WordNetLemmatizer
from nltk.stem.lancaster import LancasterStemmer

class MlPreprocessing:
    def __init__(self):
        return None
    
    def _toLowercase(self, dataset, col):
        """
        Convert all characters to lowercase
        """
        try:
            dataset[col] = dataset[col].str.lower()
            return dataset
        except Exception as err:
            logging.error("Error while converting dataframe to lowercase")
            logging.error("Error: {}".format(err))
            sys.exit(err)


    def _removePunctuation(self, dataset, col):
        """
        Remove punctuation from list of tokenized words
        """
        try:
            dataset[col] = dataset[col].str.strip(punctuation)
            return dataset
        except Exception as err:
            logging.error("Error while removing punctuation from dataframe")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _replaceNumbersWithText(self, dataset, col):
        """
        Replace all interger occurrences in list of tokenized words with textual representation
        """
        try:
            p = inflect.engine()
            dataset[col] = dataset[col].apply(lambda row: ' '.join([p.numbers_to_words(word) if word.isdigit() else word for word in row.split()]))
            return dataset
        except Exception as err:
            logging.error("Error while replacing numbers with text")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _removeStopwords(self, dataset, col):
        """
        Remove stop words from list of tokenized words
        """
        try:
            stopwords = set(
                ['br', 'the', 'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", "you've",
                 "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself',
                 'she', "she's", 'her', 'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them', 'their',
                 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', "that'll", 'these', 'those',
                 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does',
                 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of',
                 'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 'during', 'before', 'after',
                 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again',
                 'further','then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few',
                 'more','most', 'other', 'some', 'such', 'only', 'own', 'same', 'so', 'than', 'too', 'very',
                 'can', 'will', 'just', 'don', "don't", 'should', "should've", 'now','ve', 'y', 'ain', 'aren', "aren't",
                 'couldn', "couldn't", 'didn', "didn't", 'doesn', "doesn't", 'hadn', "hadn't", 'hasn', "hasn't", 'haven',
                 "haven't", 'isn', "isn't", 'ma', 'mightn', "mightn't", 'mustn',"mustn't", 'needn', "needn't", 'shan',
                 "shan't", 'shouldn', "shouldn't", 'wasn', "wasn't", 'weren', "weren't", 'won', "won't", 'wouldn', "wouldn't",
                 
                 #added stopwords
                 'std','mlu'
                 ])
    
            dataset[col] = dataset[col].apply(lambda row: ' '.join([word for word in row.split() if word not in stopwords]))
            return dataset
        
        except Exception as err:
            logging.error("Error while removing stopwords")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _stemWords(self, dataset, col):
        """
        Stem words in list of tokenized words
        """
        try:
            stemmer = LancasterStemmer()
            dataset[col] = dataset[col].apply(lambda row: ' '.join([stemmer.stem(word) for word in row.split()]))
            return dataset
        except Exception as err:
            logging.error("Error while performing stemming")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _lemmatizeVerbs(self, dataset, col):
        """
        Lemmatize verbs in list of tokenized words
        """
        try:
            lemmatizer = WordNetLemmatizer()
            dataset[col] = dataset[col].apply(lambda row: ' '.join([lemmatizer.lemmatize(word, pos='v') for word in row.split()]))
            return dataset
        except Exception as err:
            logging.error("Error while performing lemmatization")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _removeExtendedSpaces(self, dataset, col):
        '''
        Remove extra spaces
        '''
        try:
            dataset[col] = dataset[col].replace(to_replace=r'\s+', value=' ', regex=True)
            return dataset
        except Exception as err:
            logging.error("Error while removing extra spaces")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _removeSpecialCharacters(self, dataset, col):
        '''
        Replace Special characters with space
        '''
        try:
            dataset[col] = dataset[col].replace(to_replace=r'\W+', value=' ', regex=True)
            return dataset
        except Exception as err:
            logging.error("Error while removing special characters")
            logging.error("Error: {}".format(err))
            sys.exit(err)