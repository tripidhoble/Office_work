# ======================================================================================
# title           :classify.py
# description     :
# author          :Trupti Dhoble
# date            :
# version         :0.1
# notes           :
# python_version  :3.7
# ======================================================================================

import os
import sys
import logging
import pandas as pd
import utilities.utils as utils
import mltraintest.test as test
import mlbuildmodel.build_model as model
import mlwordembedding.word_embedding as wordemb
import mlprepocessing.ml_preprocessing_utils as mlp
import mlmodelvalidation.validation_report as report

class Train():

    def __init__(self, train_csv_path, output_dir):
        '''
        Initialises the class, reads in the data, seperates targets and features
        '''
        logging.info("Initialising object for Train class....")
        self.utl = utils.Utils()
        self.config_data = self.utl._load_json(file=os.path.join(os.path.realpath("machine-learning-services"),'config','mlconfig.json'))
        self.dataset = self.utl._loadCSVToDataframe(train_csv_path)
        self.output_dir = output_dir
        self.word_embedding_dir = os.path.join(self.output_dir, self.config_data["WORDEMBEDDING_DIRECTORY_NAME"])
        if not os.path.exists(self.word_embedding_dir):
            os.makedirs(self.word_embedding_dir)

        self.model_dir = os.path.join(self.output_dir, self.config_data["MODEL_DIRECTORY_NAME"])
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)

        self.preprocessing_dir = os.path.join(self.output_dir, self.config_data["PREPROCESSED_DIRECTORY_NAME"])
        if not os.path.exists(self.preprocessing_dir):
            os.makedirs(self.preprocessing_dir)

        return None

    def train_model(self,
                    isHyperParameterTuning,
                    preprocessing_filters_list,
                    word_embedding_method,
                    ref_model,
                    params_dict,
                    model_validation_methods_list,
                    action_flag_dict
                    ):
        try:
            mlp_obj = mlp.mlpreprocessing_util()
            wordemb_obj = wordemb.wordembedding()
            model_obj = model.BuildModel()
            print("Training model....")
            # split the dataset in train and valid
            X_train, X_valid, y_train, y_valid = self.utl._train_test_split(self.dataset.drop('Label', axis=1),
                                                                                 self.dataset['Label'])
            train_dataset = pd.concat([X_train, y_train], axis=1)
            valid_dataset = pd.concat([X_valid, y_valid], axis=1)

            # Preprocessing
            if (action_flag_dict.get('preprocessing_Flag',1)):
                print("Applying machine learning preprocessing.")
                preprocessed_train_dataset = mlp_obj.applyPreprocessing(train_dataset, preprocessing_filters_list)
                self.utl._save_DataframeToCSV(preprocessed_train_dataset, self.preprocessing_dir,
                                                   self.config_data["PREPROCESSED_FILENAME"])
            else:
                print("Reading preprocess data from location {}".format(self.preprocessing_dir))
                preprocessed_csv_path = os.path.join(self.preprocessing_dir, self.config_data["PREPROCESSED_FILENAME"])
                preprocessed_train_dataset = self.utl._loadCSVToDataframe(preprocessed_csv_path)

            # Word Embedding
            if (action_flag_dict.get('word_embedding_Flag',1)):
                print("Applying word embedding.")
                vector_train_dataset = wordemb_obj.applywordembedding(preprocessed_train_dataset, self.model_dir,
                                                                      word_embedding_method, params_dict)
                self.utl._save_DataframeToCSV(vector_train_dataset, self.word_embedding_dir,
                                                   self.config_data["TRAIN_DATASET_VECTOR_FILENAME"])
            else:
                print("Reading vector dataset {}".format(self.word_embedding_dir))
                vector_train_csv_path = os.path.join(self.word_embedding_dir,
                                                     self.config_data["TRAIN_DATASET_VECTOR_FILENAME"])
                vector_train_dataset = self.utl._loadCSVToDataframe(vector_train_csv_path)

            # Model Building
            print("Model building started...")
            if (action_flag_dict.get('buildModel_Flag',1)):
                self.model_dir_path = model_obj.applyModelBuilding(vector_train_dataset, self.model_dir,
                                                                   isHyperParameterTuning,
                                                                   ref_model, params_dict)

            # prediction for valid dataset
            test_obj = test.Test()
            dataset_pred,_ = test_obj.test_data(valid_dataset, preprocessing_filters_list, word_embedding_method,
                                              self.model_dir)
            self.utl._save_DataframeToCSV(dataset_pred, self.output_dir, self.config_data["PRED_VALID_FILENAME"])

            # validation report
            model_validation_report = report.ValidationReport()._get_model_validation_report(dataset_pred.Label,
                                                                                             dataset_pred.Label_Pred,
                                                                                             model_validation_methods_list)
            logging.info("Model validation: \n {}".format(model_validation_report))
            report.ValidationReport()._save_model_validation_report(self.output_dir,
                                                                    self.config_data["VALIDATION_REPORT_FILENAME"],
                                                                    model_validation_report)
            return model_validation_report

        except Exception as err:
            logging.error("Error occured while training")
            logging.error("Error: {}".format(err))
            sys.exit(err)