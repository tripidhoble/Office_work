# ======================================================================================
# title           :test.py
# description     :
# author          :Trupti Dhoble
# date            :
# version         :0.1
# notes           :
# python_version  :3.7
# ======================================================================================

import os
import sys
import logging
import pickle
import numpy as np
import pandas as pd
import utilities.utils as utils
import mlwordembedding.model.word2vec as w2ve
import mlprepocessing.ml_preprocessing_utils as mlp


class Test():

    def __init__(self):
        self.utl = utils.Utils()
        return None

    def _vector_transformation(self, model_dir, X_valid):
        try:
            logging.info("Loading 'Vector.pickle' model from model_dir - '{}'".format(model_dir))
            vect = pickle.load(open(os.path.join(model_dir, "Vector.pickle"), 'rb'))
            X_valid_vect = vect.transform(X_valid)
            return X_valid_vect
        except Exception as err:
            logging.error("Error while loading 'Vector.pickle' model from model_dir - '{}'".format(model_dir))
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def _predict_labels(self, model_dir, X_test_vect):
        try:
            logging.info("Loading 'Final_model.pickle' model from model_dir - '{}'".format(model_dir))
            model = pickle.load(open(os.path.join(model_dir, "Final_Model.pickle"), 'rb'))
            y_pred = model.predict(X_test_vect)
            y_prob = np.around(model.predict_proba(X_test_vect), decimals=3)
            y_prob_labels = model.classes_
            return y_pred, y_prob, y_prob_labels
        except Exception as err:
            logging.error("Error while loading 'Final_model.pickle' model from model_dir - '{}'".format(model_dir))
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def convert_to_dataframe(self, dataset, y_pred, y_prob, y_prob_labels):
        try:
            logging.info("Converting prediction to dataframe")
            predict_df = dataset.iloc[:, dataset.columns != 'Log_Data']
            predict_df['Label_Pred'] = y_pred
            for i in range(len(y_prob_labels)):
                predict_df[y_prob_labels[i]] = y_prob[:, i]
            return predict_df
        except Exception as err:
            logging.error("Error while Converting prediction to dataframe")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def test_data(self, dataset, preprocessing_filters_list, word_embedding_method, model_dir):
        try:
            # preprocessig
            logging.info("Applying preprocessing on test dataset")
            mlp_obj = mlp.mlpreprocessing_util()
            preprocessed_dataset = mlp_obj.applyPreprocessing(dataset, preprocessing_filters_list)

            # Word Embedding
            logging.info("Applying Word embedding on preprocessed test dataset using word embedding method-'{}'".format(word_embedding_method))

            if word_embedding_method in ['AVGWord2Vec_', 'TFIDFWord2Vec_']:

                w2v_obj = w2ve.Word2Vec_()
                list_of_sentance = self.utl.convertDocIntoListofSent(preprocessed_dataset.Log_Data)
                logging.info("Loading 'word2vec.model' from model_dir - '{}'".format(model_dir))
                w2v_model = self.utl._loadW2VModel(os.path.join(model_dir, "word2vec.model"))

                # get size for word2vec
                word2vec_vector_size = w2v_model.vector_size

                w2v_embedding = []
                if word_embedding_method == 'AVGWord2Vec_':
                    w2v_embedding = w2v_obj.avgWord2Vec(w2v_model, list_of_sentance, word2vec_vector_size)
                if word_embedding_method == 'TFIDFWord2Vec_':
                    logging.info("Loading 'tfidf_dict.pickle' from model_dir - '{}'".format(model_dir))
                    tfidf_path = os.path.join(model_dir, "tfidf_dict.pickle")
                    w2v_embedding = w2v_obj.tfIdfWord2Vec(list_of_sentance, w2v_model, word2vec_vector_size, tfidf_path)

                df = pd.DataFrame()
                df['word2vec'] = list(w2v_embedding)
                dataset_vector = pd.DataFrame(df.word2vec.values.tolist(), index=preprocessed_dataset.index)
                dataset_vector.columns = ['X_' + str(col) for col in dataset_vector.columns]

            else:
                X_valid_vector = self._vector_transformation(model_dir, preprocessed_dataset.Log_Data)
                dataset_vector = pd.DataFrame(X_valid_vector.toarray(), index=preprocessed_dataset.index)

            # Prediction using model
            y_pred, y_prob, y_prob_labels = self._predict_labels(model_dir, dataset_vector)
            pred_dataset = self.convert_to_dataframe(preprocessed_dataset, y_pred, y_prob, y_prob_labels)

            try:
                pred_dataset['Label'] = preprocessed_dataset['Label']
            except:
                pass

            return pred_dataset,y_prob_labels

        except Exception as err:
            logging.error("Error while processing test dataset")
            logging.error("Error: {}".format(err))
            sys.exit(err)
