#======================================================================================
#title           :validation_report.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import sys
import logging
import utilities.utils  as utils
import mlmodelvalidation.model.metrics as metrics
from pprint import pprint
class ValidationReport():
    
    def __init__(self):
        self.utl = utils.Utils()
        return None
    
    def _get_model_validation_report(self,y_valid,y_pred,val_methods):
        val_metric = metrics.Metrics()
        model_val_report = {}
        if len(val_methods)== 0:
            logging.error("Kindly provide valid validation metrics!")
            sys.exit()
        for method in val_methods:
            if(method == 'accuracy'):
                report = val_metric._accuracy_score(y_valid,y_pred)
            if(method == 'precision'):
                report = val_metric._precision_score(y_valid,y_pred)
            if(method == 'recall'):
                report = val_metric._recall_score(y_valid,y_pred)
            if(method == 'f1_score'):
                report = val_metric._f1_score(y_valid,y_pred)
            if (method == 'classification_report'):
                report = val_metric._classification_report(y_valid, y_pred)

            # capture the report
            model_val_report[method]= report
        print(model_val_report)
        return model_val_report
        
    def _save_model_validation_report(self, output_dir, filename, model_validation_report):
        self.utl._dump_json(file_name = filename, data = model_validation_report, path = output_dir)
