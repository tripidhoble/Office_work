#======================================================================================
#title           :Metrics.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

from sklearn import metrics

class Metrics():
    
    def __init__(self):
        return None

    def _classification_report(self, y_true, y_pred, labels=None):
        cm = metrics.classification_report(y_true, y_pred, labels=labels, sample_weight=None)
        return cm  
    
    def _accuracy_score(self, y_true, y_pred):
        accuracy = metrics.accuracy_score(y_true, y_pred, normalize=True, sample_weight=None)
        return accuracy  
    
    def _precision_score(self, y_true, y_pred, labels=None, average='weighted'):
        precision = metrics.precision_score(y_true, y_pred, labels=None, pos_label=1,
                    average=average, sample_weight=None)
        return precision  
    
    def _recall_score(self, y_true, y_pred, labels=None):
        recall = metrics.recall_score(y_true, y_pred, labels=labels, pos_label=1, average='weighted',
                 sample_weight=None)
        return recall  
   
    def _roc_auc_score(self, y_true, y_pred):
        roc_auc = metrics.roc_auc_score(y_true, y_pred, sample_weight=None)
        return roc_auc  
    
    def _f1_score(self, y_true, y_pred, labels=None):
        f1_score = metrics.f1_score(y_true, y_pred, labels=labels, pos_label=1, average='weighted',
             sample_weight=None)
        return f1_score

    def get_performance_metircs_name(self):
        return ['accuracy', 'precision', 'recall', 'f1_score', 'classification_report']
     