#======================================================================================
#title           :predict_label.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import os
import pickle
import numpy as np
import pandas as pd
import utilities.utils as utils
import mlwordembedding.model.word2vec as w2ve


class PredictLabel():

    def __init__(self):
        self.utl = utils.Utils()
        return None

    def _label_separator(self, df, Log_Data):
        X = df[Log_Data]
        return X
    
    def _vector_transformation(self, model_dir, X_valid):
        vect = pickle.load(open(os.path.join(model_dir, "Vector.pickle"), 'rb'))
        X_valid_vect = vect.transform(X_valid)
        return X_valid_vect 
    
    def _predict_labels(self,model_dir, X_test_vect):
        model = pickle.load(open(os.path.join(model_dir, "Final_model.pickle"), 'rb'))
        y_pred = model.predict(X_test_vect)
        y_prob = np.around(model.predict_proba(X_test_vect), decimals=3)
        y_prob_labels = model.classes_
        return y_pred, y_prob, y_prob_labels
    
    def convert_to_dataframe(self,dataset,y_pred,y_prob,y_prob_labels ):
        predict_df = dataset.iloc[:,dataset.columns!='Log_Data']
        predict_df['y_pred'] = y_pred
        for i in range(len(y_prob_labels)):
            predict_df[y_prob_labels[i]] = y_prob[:,i]    
        return predict_df
        
    def _predict(self, preprocessed_valid_dataset, word_embedding_method, model_dir):
        # Word Embedding
        if word_embedding_method in ['AVGWord2Vec_', 'TFIDFWord2Vec_']:
            w2v_obj = w2ve.Word2Vec_()
            list_of_sentance = self.utl.convertDocIntoListofSent(preprocessed_valid_dataset.Log_Data)
            w2v_model = self.utl._loadW2VModel(os.path.join(model_dir, "word2vec.model"))

            # get size for word2vec
            word2vec_vector_size = w2v_model.vector_size

            tfidf_path = os.path.join(model_dir, "tfidf_dict.pickle")
            w2v_embedding = []
            if word_embedding_method == 'AVGWord2Vec_':
                w2v_embedding = w2v_obj.avgWord2Vec(w2v_model, list_of_sentance, word2vec_vector_size)
            if word_embedding_method == 'AVGWord2Vec_':
                w2v_embedding = w2v_obj.tfIdfWord2Vec(list_of_sentance, w2v_model, word2vec_vector_size, tfidf_path)
            df1 = pd.DataFrame()
            df1['word2vec'] = list(w2v_embedding)
            valid_dataset_vector = pd.DataFrame(df1.word2vec.values.tolist(), index=preprocessed_valid_dataset.index)
            valid_dataset_vector .columns = ['X_'+str(col) for col in valid_dataset_vector.columns]
            
        else:
            X_valid_vector = self._vector_transformation(model_dir, preprocessed_valid_dataset.Log_Data)
            valid_dataset_vector = pd.DataFrame(X_valid_vector.toarray(), index=preprocessed_valid_dataset.index)
            
        valid_dataset_vector ['Label'] = preprocessed_valid_dataset.iloc['Label']
        
        # Prediction using model
        self.y_pred, self.y_prob, self.y_prob_labels = self._predict_labels(model_dir, valid_dataset_vector.drop('Label', axis=1))
        valid_pred_dataset = self.convert_to_dataframe(preprocessed_valid_dataset,self.y_pred, self.y_prob, self.y_prob_labels)
       
        return valid_pred_dataset