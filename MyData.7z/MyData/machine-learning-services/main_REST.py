#======================================================================================
#title           :main_REST.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import os
from flask import abort
from flask import jsonify
from flask import Flask, request
import utilities.utils as utils
from utilities.logger import LogHandler
from mlsimplementation import machine_learning_services as ml_services

# logs settings
log = LogHandler()
logging = log.create_obj("Jarvis_Log.log")
logging.info("Execution started")
print("Execution started...")

app = Flask(__name__)
utl = utils.Utils()
# Default error page
@app.route('/')
def index():
    logging.warning('Invalid query URI')
    return "Invalid URI"

@app.route('/jarvis/mlsapi/v1.0/getMlPreprocessingMethods', methods=['GET'])
def get_preprocessing_methods():
    obj = ml_services.machine_learning_services()
    mlp_names = obj.get_ml_preprocessing_methods()
    return jsonify({"ml_preprocessing_methods_name": mlp_names}), 201

@app.route('/jarvis/mlsapi/v1.0/allWordEmbedding', methods=['GET'])
def get_word_embedding_methods():
    obj = ml_services.machine_learning_services()
    wordemb_names = obj.get_all_word_embedding()
    return jsonify({"word_embedding_names": wordemb_names}), 201

@app.route('/jarvis/mlsapi/v1.0/allPackages', methods=['GET'])
def get_packages():
    obj = ml_services.machine_learning_services()
    packages_names = obj.get_all_packages()
    return jsonify({"packages": packages_names}), 201

@app.route('/jarvis/mlsapi/v1.0/allPerformanceMetrics', methods=['GET'])
def get_performance_metircs():
    obj = ml_services.machine_learning_services()
    metrics_names = obj.get_all_performance_mertrics()
    return jsonify({"metrics": metrics_names}), 201

@app.route('/jarvis/mlsapi/v1.0/compareModelResults', methods=['GET'])
def get_comparison_results():
    obj = ml_services.machine_learning_services()
    comp_results = obj.get_compare_model_results()
    return jsonify({"comparison_results": comp_results}), 201

@app.route('/jarvis/mlsapi/v1.0/commitMlModel', methods=['POST'])
def commit_ml_model():
    if not request.json:
        logging.warning('Request param missing in the POST request')
        abort(400)
    trainModelID = request.json["trainModelID"]
    productID = request.json["productID"]
    mls_obj = ml_services.machine_learning_services()
    mls_obj.commit_model(product_id = productID, train_model_id = trainModelID)
    return jsonify({"model commit": request.json}), 201

@app.route('/jarvis/mlsapi/v1.0/getModelConfig', methods=['GET', 'POST'])
def get_model_config():
    if not request.json:
        logging.warning('Request param missing in the POST request')
        abort(400)
    product_id = request.json["productID"]
    obj = ml_services.machine_learning_services()
    modelConfig = obj.get_model_config(product_id=product_id)
    return jsonify({"model_config": modelConfig}), 201

@app.route('/jarvis/mlsapi/v1.0/getAllTrainModelsConfig', methods=['GET', 'POST'])
def get_all_train_models_config():
    if not request.json:
        logging.warning('Request param missing in the POST request')
        abort(400)
    product_id = request.json["productID"]
    obj = ml_services.machine_learning_services()
    modelConfig = obj.get_all_train_models_config(product_id=product_id)
    return jsonify({"model_config": modelConfig}), 201

@app.route('/jarvis/mlsapi/v1.0/trainTestModel', methods=['POST'])
def train_test_model():
    if not request.json:
        logging.warning('Request param missing in the POST request')
        abort(400)

    is_train                 = request.json["isTrain"]
    product_id               = request.json["productID"]
    algo_name                = request.json["algorithmName"]
    word_embedding_method    = request.json["wordEmbeddingType"]
    is_HyperParameterTuning  = request.json["isHyperParameterTuning"]
    ml_preprocessing_methods = request.json["mlPreprocessingMethods"]
    model_validation_methods = request.json["modelValidationMethods"]
    action_flag_dict         = utl.convert_dict_params(request.json["actionFlag"][0])
    algo_params              = utl.convert_dict_params(request.json["alogrithmParameters"][0])
    word_embedding_params    = utl.convert_dict_params(request.json["wordEmbeddingParameters"][0])

    if (request.json["train_csv_path"]!="None") :
        train_csv_path = os.path.join(request.json["train_csv_path"])
    else:
        train_csv_path = None

    if request.json["test_csv_path"] !="None":
        test_csv_path = request.json["test_csv_path"]
    else:
        test_csv_path = None

    obj = ml_services.machine_learning_services()
    obj.train_test_model(product_id                 = product_id,
                         is_train                   = is_train,
                         is_HyperParameterTuning    = is_HyperParameterTuning,
                         ml_preprocessing_methods   = ml_preprocessing_methods,
                         word_embedding_method      = word_embedding_method,
                         word_embedding_params      = word_embedding_params,
                         algo_name                  = algo_name,
                         algo_params                = algo_params,
                         model_validation_methods   = model_validation_methods,
                         action_flag_dict           = action_flag_dict,
                         train_csv_path             = train_csv_path,
                         test_csv_path              = test_csv_path
                         )
    return jsonify({"model_trained": request.json}), 201

if __name__ == '__main__':
    app.run(debug=True)