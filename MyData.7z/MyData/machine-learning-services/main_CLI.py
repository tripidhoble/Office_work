#======================================================================================
#title           :main_CLI.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import sys
import logging
import utilities.utils as utils
import cliargsparser as cliargs
from utilities.logger import LogHandler
from mlsimplementation import machine_learning_services as ml_services

# import sys
# sys.path.append(os.path.realpath("machine-learning-services"))
import warnings
warnings.filterwarnings("ignore")

utl = utils.Utils()

def get_preprocessing_methods():
    obj = ml_services.machine_learning_services()
    mlp_names = obj.get_ml_preprocessing_methods()
    logging.info(mlp_names)
    print(mlp_names)
    return None

def get_word_embedding_methods():
    obj = ml_services.machine_learning_services()
    wordemb_names = obj.get_all_word_embedding()
    logging.info(wordemb_names)
    print(wordemb_names)
    return None

def get_packages():
    obj = ml_services.machine_learning_services()
    packages_names = obj.get_all_packages()
    logging.info(packages_names)
    print(packages_names)
    return None

def get_performance_metircs():
    obj = ml_services.machine_learning_services()
    metrics_names = obj.get_all_performance_mertrics()
    logging.info(metrics_names)
    print(metrics_names)
    return None

def get_comparison_results():
    obj = ml_services.machine_learning_services()
    comp_results = obj.get_compare_model_results()
    logging.info(comp_results)
    print(comp_results)
    return None

def commit_model(args):
    trainModelID = args["trainModelID"]
    productID = args["productID"]
    mls_obj = ml_services.machine_learning_services()
    mls_obj.commit_model(product_id = productID, train_model_id = trainModelID)
    print("model {} committed successfully.".format(trainModelID))
    return None

def get_model_config(args):
    product_id = args["productID"]
    obj = ml_services.machine_learning_services()
    modelConfig = obj.get_model_config(product_id=product_id)
    logging.info(modelConfig)
    print(modelConfig)
    return None

def get_all_train_models_config(args):
    product_id = args["productID"]
    obj = ml_services.machine_learning_services()
    modelConfig = obj.get_all_train_models_config(product_id=product_id)
    logging.info(modelConfig)
    print(modelConfig)
    return None

def train_test_model(args):
    # get the parameters
    logging.info('Training Model....')
    is_train                 = args["isTrain"]
    product_id               = args["productID"]
    is_HyperParameterTuning  = args["isHyperParameterTuning"]
    ml_preprocessing_methods = args["mlPreprocessingMethods"]
    word_embedding_method    = args["wordEmbeddingType"]
    algo_name                = args["algorithmName"]
    model_validation_methods = args["modelValidationMethods"]
    train_csv_path           = args["train_csv_path"]
    test_csv_path            = args["test_csv_path"]
    action_flag_dict         = utl.parse_vars(args["actionFlag"])
    word_embedding_params    = utl.parse_vars(args["wordEmbeddingParameters"])
    algo_params              = utl.parse_vars(args["alogrithmParameters"])

    obj = ml_services.machine_learning_services()
    obj.train_test_model(product_id=product_id,
                         is_train=is_train,
                         is_HyperParameterTuning=is_HyperParameterTuning,
                         ml_preprocessing_methods=ml_preprocessing_methods,
                         word_embedding_method=word_embedding_method,
                         word_embedding_params=word_embedding_params,
                         algo_name=algo_name,
                         algo_params=algo_params,
                         model_validation_methods=model_validation_methods,
                         action_flag_dict=action_flag_dict,
                         train_csv_path=train_csv_path,
                         test_csv_path=test_csv_path
                         )
    return None

def machine_learning_services(args):
    # Log file and logging level
    logging.info('New machine learning service instance created')
    function_map = {
                        "train_test_model"           : train_test_model,
                        "get_packages"               : get_packages,
                        "get_word_embedding_methods" : get_word_embedding_methods,
                        "get_preprocessing_methods"  : get_preprocessing_methods,
                        "get_performance_metircs"    : get_performance_metircs,
                        "get_comparison_results"     : get_comparison_results,
                        "commit_model"               : commit_model,
                        "get_model_config"           : get_model_config,
                        "get_all_train_models_config": get_all_train_models_config
                   }

    logging.info("Applying Machine Learning Services: {}".format(args['machine_learning_service']))
    try:
        function = function_map[args['machine_learning_service']]
    except:
        logging.error("machine_learning_service is None or invalid!")
        sys.exit("machine_learning_service is None or invalid!")

    if function in [train_test_model, commit_model, get_model_config, get_all_train_models_config] :
        function(args)
    else:
        function()

def main():
    log = LogHandler()
    log.create_obj("Jarvis_Log.log")

    cli_obj = cliargs.CLI_ArgumentParser()
    args = cli_obj.get_parse_args

    machine_learning_services(args)
    return None

if __name__ == "__main__":
    main()
