#======================================================================================
#title           :word_embedding.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================
import os
import sys
import logging
import pandas as pd
import utilities.utils as utils
import mlwordembedding.init_model as iwem
import mlwordembedding.model.word2vec as w2ve

class wordembedding():
     
    def __init__(self):
        self.utl = utils.Utils()
        return None
    
    def _buildVectorModel(self, vect_obj, vect_params, X_data):
        '''
        Build feature vectors
        '''
        vectorizer = vect_obj._initialize(vect_params)
        vectorizer .fit(X_data)
        logging.info("Built Vector Model using {}.".format(vect_obj))
        return vectorizer 

    def applyWord2vecEmbedding(self, data_frame, model_dir, word_embedding_method, model_params_dict=None):
        try:
            logging.info("Applying word2vec word embedding")
            w2v_obj, w2v_params = iwem.InitWordEmbeddingModel()._init_model(word_embedding_method, model_params_dict)

            # Converting logs file into sentacne
            list_of_sentance = self.utl.convertDocIntoListofSent(data_frame.Log_Data)

            # Creating word2vec model
            w2v_model = w2v_obj._initialize(list_of_sentance,w2v_params)
            w2v_model.save(os.path.join(model_dir, 'word2vec.model'))

            #get size for word2vec
            word2vec_vector_size = w2v_model.vector_size
            w2v_embedding = []

            w2v_obj = w2ve.Word2Vec_()
            if word_embedding_method == 'AVGWord2Vec_':
                w2v_embedding = w2v_obj.avgWord2Vec(w2v_model, list_of_sentance, word2vec_vector_size)

            elif word_embedding_method == 'TFIDFWord2Vec_':
                tfidf_obj, tfidf_params = iwem.InitWordEmbeddingModel()._init_model('TfidfVectorizer_', model_params_dict)
                tfidf_model = self._buildVectorModel(tfidf_obj, tfidf_params, data_frame.Log_Data)
                dictionary = dict(zip(tfidf_model.get_feature_names(), list(tfidf_model.idf_)))
                tfidf_dict_path = self.utl.dumpPickle(model_dir, "tfidf_dict.pickle", dictionary)
                w2v_embedding = w2v_obj.tfIdfWord2Vec(list_of_sentance, w2v_model, word2vec_vector_size, tfidf_dict_path)
            else:
                logging.error("unable to recognize {} as word_embedding_method".format(word_embedding_method))

            df = pd.DataFrame()
            df['word2vec'] = list(w2v_embedding)
            vector_dataset = pd.DataFrame(df.word2vec.values.tolist(), index=data_frame.index)
            vector_dataset.columns = ['X_'+str(col) for col in vector_dataset.columns]
            print(vector_dataset.head())
            return vector_dataset
        except Exception as err:
            logging.error("Error occurred while applying word2vec embedding")
            logging.error("Error: {}".format(err))

    def applywordembedding(self, dataset, model_dir, word_embedding_method, model_params_dict):
        try:
            logging.info("applying word embedding using method- {}".format(word_embedding_method))

            if word_embedding_method in ['AVGWord2Vec_', 'TFIDFWord2Vec_']:
                vector_dataset = self.applyWord2vecEmbedding(dataset, model_dir, word_embedding_method,
                                                             model_params_dict)
            else:
                weModel_obj, weModel_params = iwem.InitWordEmbeddingModel()._init_model(word_embedding_method,
                                                                                        model_params_dict)
                vectorizer = self._buildVectorModel(weModel_obj, weModel_params, dataset.Log_Data)
                self.utl._save_model(vectorizer, "Vector.pickle", model_dir)
                X_data_vector = vectorizer.transform(dataset.Log_Data)
                vector_dataset = pd.DataFrame(X_data_vector.toarray(), index=dataset.index,
                                              columns=vectorizer.get_feature_names())
            vector_dataset['Label'] = dataset.Label
            return vector_dataset

        except Exception as err:
            logging.error("Error occurred while applying word embedding")
            logging.error("Error: {}".format(err))
            sys.exit(err)

    def get_word_embedding_methods(self):
        initWemb_obj = iwem.InitWordEmbeddingModel()
        word_embedding_methods = initWemb_obj.word_embedding_methods
        return word_embedding_methods