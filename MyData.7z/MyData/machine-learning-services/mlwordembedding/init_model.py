#======================================================================================
#title           :init_model.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import sys
import mlwordembedding.model.word2vec as w2v
import mlwordembedding.model.count_vectorizer as cv
import mlwordembedding.model.tfidf_vectorizer as tf

class InitWordEmbeddingModel():
    def __init__(self):
        self.word_embedding_methods = ['CountVectorizer_', 'TfidfVectorizer_', 'AVGWord2Vec_', 'TFIDFWord2Vec_']
        return None
    
    def _init_model(self, model_ref, model_params = None):
        
        if  (model_ref == 'CountVectorizer_'):
            model_obj, model_params = cv.CountVectorizer_(), model_params['CountVectorizer_']
        
        elif(model_ref == 'TfidfVectorizer_'):
            if 'TfidfVectorizer_' not in model_params.keys():
                model_obj, model_params = tf.TfidfVectorizer_(), None
            else:
                model_obj, model_params = tf.TfidfVectorizer_(), model_params['TfidfVectorizer_']

        elif model_ref == 'AVGWord2Vec_':
            model_obj, model_params = w2v.Word2Vec_(), model_params['AVGWord2Vec_']

        elif model_ref == 'TFIDFWord2Vec_':
            model_obj, model_params = w2v.Word2Vec_(), model_params['TFIDFWord2Vec_']

        else:
            sys.exit("unable to recognise '{}' as valid reference model".format(model_ref))
        
        return model_obj, model_params

            