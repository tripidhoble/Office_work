##======================================================================================
##title           :TfidfVectorizer.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================
from sklearn.feature_extraction.text import TfidfVectorizer

class TfidfVectorizer_():
    def __init__(self):
        return None
    
    def _initialize(self,params={}):
        tfidf_params = {}
        if params is None:
            tfidf = TfidfVectorizer()
        else:
            tfidf_params.update(params)
            tfidf = TfidfVectorizer(**tfidf_params)
        return tfidf