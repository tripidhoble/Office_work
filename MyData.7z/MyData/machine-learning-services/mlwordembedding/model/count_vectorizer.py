##======================================================================================
##title           :count_ectorizer.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================

from sklearn.feature_extraction.text import CountVectorizer

class CountVectorizer_():
    def __init__(self):
        return None
    
    def _initialize(self,params={}):
        cv_params = {'ngram_range':(2, 2)}
        cv_params.update(params)
        cv = CountVectorizer(**cv_params)
        return cv
