##======================================================================================
##title           :Word2Vec.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================

import numpy as np
from tqdm import tqdm
import utilities.utils as utils
from gensim.models import Word2Vec


class Word2Vec_():
    def __init__(self):
        self.utl = utils.Utils()
        return None
    
    def _initialize(self, data, params={}):
        w2v = Word2Vec(data, **params)
        return w2v

    def avgWord2Vec(self, model, list_of_sentance, word2vec_vector_size):
        # average Word2Vec
        w2v_words = list(model.wv.vocab)
        # compute average word2vec for each review.
        sent_vectors = []  # the avg-w2v for each sentence/review is stored in this list
        for sent in tqdm(list_of_sentance):  # for each review/sentence
            sent_vec = np.zeros(
                word2vec_vector_size)  # as word vectors are of zero length 50, you might need to change this to 300 if you use google's w2v
            cnt_words = 0  # num of words with a valid vector in the sentence/review
            for word in sent:  # for each word in a review/sentence
                if word in w2v_words:
                    vec = model.wv[word]
                    sent_vec += vec
                    cnt_words += 1
            if cnt_words != 0:
                sent_vec /= cnt_words
            sent_vectors.append(sent_vec)
        return sent_vectors

    def tfIdfWord2Vec(self, data, model, word2vec_vector_size, pickle_path):
        # TF-IDF weighted Word2Vec
        print("---- Loading TFIDF file ----")
        dictionary = self.utl.readFromPickle(pickle_path)
        tfidf_feat = dictionary.keys()
        w2v_words = list(model.wv.vocab)
        # final_tf_idf is the sparse matrix with row= sentence, col=word and cell_val = tfidf
        tfidf_sent_vectors = []  # the tfidf-w2v for each sentence/review is stored in this list
        row = 0
        for sent in tqdm(data):  # for each review/sentence
            sent_vec = np.zeros(word2vec_vector_size)  # as word vectors are of zero length
            weight_sum = 0  # num of words with a valid vector in the sentence
            for word in sent:
                if word in w2v_words and word in tfidf_feat:
                    vec = model.wv[word]
                    tf_idf = dictionary[word] * (sent.count(word) / len(sent))
                    sent_vec += (vec * tf_idf)
                    weight_sum += tf_idf
            if weight_sum != 0:
                sent_vec /= weight_sum
            tfidf_sent_vectors.append(sent_vec)
            row += 1
        return tfidf_sent_vectors