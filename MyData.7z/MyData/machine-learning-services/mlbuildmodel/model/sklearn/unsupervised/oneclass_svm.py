##======================================================================================
##title           :OneClassSVM.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================

from sklearn.svm import OneClassSVM
import numpy as np

class OneClassSVM_():
    def __init__(self):
        return None
    
    def _initialize(self,params={}): 
        osvm_params = {'kernel':'rbf', 'nu':0.1, 'gamma':0.1}
        osvm_params.update(params)
        osvm_clf = OneClassSVM(**osvm_params)
        return osvm_clf
    
    def _param_grid(self):
        param_grid = {
                      'gamma' : np.logspace(-9, 3, 13),
                      'nu' : np.linspace(0.01, 0.99, 99)
                      }
        return param_grid