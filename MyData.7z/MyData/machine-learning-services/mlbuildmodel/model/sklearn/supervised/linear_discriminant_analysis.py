##======================================================================================
##title           :LinearDiscriminatAnalysis.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis


class LinearDiscriminantAnalysis_():
    def __init__(self):
        return None

    def _initialize(self, params={}):
        lda_params = {}
        lda_params.update(params)
        lda_clf = LinearDiscriminantAnalysis(**lda_params)
        return lda_clf

    def _param_grid(self):
        param_grid = {

                     }
        return param_grid