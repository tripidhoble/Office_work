##======================================================================================
##title           :RandomForestClassifier.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================
from sklearn.ensemble import RandomForestClassifier

class RandomForestClassifier_():
    def __init__(self):
        return None
    
    def _initialize(self,params={}):
        rf_params = {'random_state':0, 'n_jobs':-1, 'class_weight':"balanced"}
        rf_params.update(params)
        rf_clf = RandomForestClassifier(**rf_params)
        return rf_clf
    
    def _param_grid(self):
        param_grid = { 
                      'max_depth' : [2,3,4,5,6,7,8],
                      'criterion' :['gini', 'entropy'],
                      'n_estimators' : [50,100,150,200]  
                     }
        return param_grid
