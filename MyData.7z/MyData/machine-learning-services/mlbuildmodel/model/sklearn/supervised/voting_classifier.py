##======================================================================================
##title           :VotingClassifier.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================

from sklearn.ensemble import VotingClassifier

class VotingClassifier_():
    def __init__(self):
        return None
    
    def _initialize(self, ensemble_models,params={}):
        vc_params = {'estimators':ensemble_models, 'voting':'soft'}
        vc_params.update(params)
        voting_clf = VotingClassifier(**vc_params)
        return voting_clf
        
    