##======================================================================================
##title           :DecisionTreeClassifier.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================

from sklearn.tree import DecisionTreeClassifier


class DecisionTreeClassifier_():
    def __init__(self):
        return None

    def _initialize(self, params={}):
        dt_params = {}
        dt_params.update(params)
        decisiontree_clf = DecisionTreeClassifier(**dt_params)
        return decisiontree_clf

    def _param_grid(self):
        param_grid = {
                      'max_depth': [3,4,5]
                     }
        return param_grid