##======================================================================================
##title           : knn.py
##description     :
##author          : Vishal Chauhan
##date            :
##version         : 0.1
##notes           :
##python_version  : 3.7
##======================================================================================

from sklearn.neighbors import KNeighborsClassifier


class KNN_():
    def __init__(self):
        return None

    def _initialize(self, params={}):
        lr_params = {}
        lr_params.update(params)
        knn = KNeighborsClassifier(**params)
        return knn

    def _param_grid(self):
        param_grid = {
            'n_neighbors': [1,2,3,5,10]
        }
        return param_grid
