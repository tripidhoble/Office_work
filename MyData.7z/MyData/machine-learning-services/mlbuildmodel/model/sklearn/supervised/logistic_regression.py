##======================================================================================
##title           :LogisticRegression.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================

from sklearn.linear_model import LogisticRegression

class LogisticRegression_():
    def __init__(self):
        return None

    def _initialize(self, params={}):
        lr_params = {}
        lr_params.update(params)
        log_reg = LogisticRegression(**params)
        return log_reg

    def _param_grid(self):
        param_grid = { 
                      'C' : [0.1, 0.5, 1 ,8 ,15]
                     }
        return param_grid
    