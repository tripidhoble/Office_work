##======================================================================================
##title           :MultinomialNB.py
##description     :
##author          :Trupti Dhoble
##date            :
##version         :0.1
##notes           :
##python_version  :3.7
##======================================================================================
from sklearn.naive_bayes import MultinomialNB

class MultinomialNB_():
    def __init__(self):
        return None
    
    def _initialize(self, params={}):
        nb_params = {'alpha':1.0, 'fit_prior':True}
        nb_params.update(params)
        nb = MultinomialNB(**nb_params)
        return nb

    def _param_grid(self):
        param_grid = { 
                      'alpha' : [0.1, 1, 5]
                     }
        return param_grid