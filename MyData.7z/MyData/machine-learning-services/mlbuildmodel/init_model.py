#======================================================================================
#title           :init_model.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import sys
import mlbuildmodel.model.sklearn.supervised.knn as knn
import mlbuildmodel.model.sklearn.supervised.multinomial_nb as nb
import mlbuildmodel.model.sklearn.supervised.logistic_regression as lr
import mlbuildmodel.model.sklearn.supervised.voting_classifier as vclf
import mlbuildmodel.model.sklearn.supervised.randomforest_classifier as rf
import mlbuildmodel.model.sklearn.supervised.decision_tree_classifier as dt
import mlbuildmodel.model.sklearn.supervised.linear_discriminant_analysis as lda

import mlbuildmodel.model.sklearn.unsupervised.oneclass_svm as ocs

class InitMlModel():
    def __init__(self):
        self.algo_names = {'scikit-learn': ['LogisticRegression_', 'RandomForestClassifier_', 'OneClassSVM_',
                                       'MultinomialNB_', 'VotingClassifier_', 'KNN_', 'LDA_', 'DecisionTree_']}
        return None
    
    def _init_model(self,model_ref,model_params):

        if(model_ref == 'LogisticRegression_'):
            model_obj, model_params = lr.LogisticRegression_(), model_params['LogisticRegression_']
        
        elif(model_ref == 'RandomForestClassifier_'):
            model_obj, model_params = rf.RandomForestClassifier_(), model_params['RandomForestClassifier_']
        
        elif(model_ref == 'OneClassSVM_'):
            model_obj, model_params = ocs.OneClassSVM_(), model_params['OneClassSVM_']
        
        elif(model_ref == 'MultinomialNB_'):
            model_obj, model_params = nb.MultinomialNB_(), model_params['MultinomialNB_']
        
        # scikit-learne ensemble models
        elif(model_ref == 'VotingClassifier_'):
            model_obj, model_params = vclf.VotingClassifier_(), model_params['VotingClassifier_']

        elif (model_ref == 'KNN_'):
            model_obj, model_params = knn.KNN_(), model_params['KNN_']

        elif (model_ref == 'LDA_'):
            model_obj, model_params = lda.LinearDiscriminantAnalysis_(), model_params['LDA_']

        elif (model_ref == 'DecisionTree_'):
            model_obj, model_params = dt.DecisionTreeClassifier_(), model_params['DecisionTree_']
        
        else:
            sys.exit("unable to recognise '{}' as valid reference model".format(model_ref))
        return model_obj, model_params
            