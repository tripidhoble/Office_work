#======================================================================================
#title           :build_model.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import sys
import logging
import utilities.utils as utils
import mlbuildmodel.init_model as ibm
from sklearn.model_selection import GridSearchCV

class BuildModel():
     
    def __init__(self):
        self.utl =utils.Utils()
        return None
    
    def _grid_search(self, model_obj, model_params, X_train_vect, y_train):
        model = model_obj._initialize(model_params)
        grid_search_model = GridSearchCV(model, param_grid = model_obj._param_grid())
        grid_search_model.fit(X_train_vect, y_train)
        print("Predicted Log-Type using model finalised by grid_search algorithm for model- {}".format(model_obj))
        return grid_search_model

    
    def _single_model(self, model_obj, model_params, X_train_vect, y_train):
        logging.info("Initializing and fittong model '{}'.".format(model_obj))
        model = model_obj._initialize(model_params)
        model.fit(X_train_vect, y_train)
        return model  

    def applyModelBuilding(self, dataset, model_dir, isHyperParameterTuning, ref_model, params_dict):
        try:
            logging.info("Building '{}' model ".format(ref_model))
            X_data = dataset.drop('Label', axis=1)
            y_data = dataset.Label

            X_data_vect = self.utl._convert_DfToArray(X_data)

            model_obj, model_params = ibm.InitMlModel()._init_model(ref_model, params_dict)
            if isHyperParameterTuning:
                model = self._grid_search(model_obj, model_params, X_data_vect, y_data)
            else:
                model = self._single_model(model_obj, model_params, X_data_vect, y_data)

            self.utl._save_model(model, "Final_Model.pickle", model_dir)
            return model_dir
        except Exception as err:
            logging.error("Error while Building '{}' model ".format(ref_model))
            logging.error("Error: {}".format(err))
            sys.exit(err)


    def get_algorithm_names(self):
        initbm_obj = ibm.InitMlModel()
        algo_names = initbm_obj.algo_names
        return algo_names