#======================================================================================
#title           :processMessage.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================
import os, sys
import logging
import utilities.utils as utils
from mlsimplementation import machine_learning_services as ml_services
from TaskStatusImpl.Task_Status import TaskStatusOperations

class processMessage():
    def __init__(self):
        pass

    def processAmqpMessage(self, message):
        try:
            mls_obj = ml_services.machine_learning_services()
            utl = utils.Utils()
            command = message["command"].strip()

            if command == "PERFORMANCE_METRICS":
                metrics_names = mls_obj.get_all_performance_mertrics()
                messageToPublish = {"taskId": message["taskId"],
                                    "command": message["command"],
                                    "PERFORMANCE_METRICS": metrics_names}
                logging.info(messageToPublish)

            elif command == "SUPPORTED_METHODS":
                wordembedding_methods = mls_obj.get_all_word_embedding()
                ml_preprocessing_methods = mls_obj.get_ml_preprocessing_methods()
                packages = mls_obj.get_all_packages()
                messageToPublish = {"taskId": message["taskId"],
                                    "command": message["command"],
                                    "WORDEMBEDDING_METHODS": wordembedding_methods,
                                    "ML_PREPROCESSING_METHODS": ml_preprocessing_methods,
                                    "PACKAGES": packages}
                logging.info(messageToPublish)

            elif command == "TRAIN_TEST_DATA":
                task_status_obj = TaskStatusOperations()
                task_status_obj.add_status_rule(task_id= message.get("taskId"), command = "TRAIN_TEST_DATA")

                logging.info('Training Model....')
                is_train = message.get("isTrain",1)
                product_id = message.get("productID","Product-Id")


                if is_train == 1 or int(is_train)==1 :
                    is_HyperParameterTuning = message.get("isHyperParameterTuning",0)
                    ml_preprocessing_methods = message.get("mlPreprocessingMethods",1)
                    word_embedding_method = message.get("wordEmbeddingType","CountVectorizer_")
                    algo_name = message.get("algorithmName","LogisticRegression_")
                    model_validation_methods = message.get("modelValidationMethods","f1_score")

                    # alogrithmParameters, wordEmbeddingParameters and actionFlag params will be in dictionary format for REST and for CLI it will be separated bt'='
                    if str(message.get("actionFlag"))[0] == "{":
                        action_flag_dict = utl.convert_dict_params(message.get("actionFlag",{}))
                    elif str(message.get("actionFlag"))[0] == "[":
                        action_flag_dict = utl.parse_vars(message.get("actionFlag",[]))

                    if str(message.get("alogrithmParameters"))[0] == "{":
                        algo_params = utl.convert_dict_params(message.get("alogrithmParameters",{}))
                    elif str(message.get("alogrithmParameters"))[0] == "[":
                        algo_params = utl.parse_vars(message.get("alogrithmParameters",[]))

                    if str(message.get("wordEmbeddingParameters"))[0] == "{":
                        word_embedding_params = utl.convert_dict_params(message.get("wordEmbeddingParameters",{}))
                    elif str(message.get("wordEmbeddingParameters"))[0] == "[":
                        word_embedding_params = utl.parse_vars(message.get("wordEmbeddingParameters",[]))


                    # check for train and test csv paths
                    train_csv_path = message.get("train_csv_path", None)
                    if train_csv_path != None:
                        if not os.path.exists(train_csv_path):
                            raise Exception("Invalid path!")
                    model_validation_report = mls_obj.train_test_model(product_id=product_id,
                                                                       is_train=is_train,
                                                                       is_HyperParameterTuning=is_HyperParameterTuning,
                                                                       ml_preprocessing_methods=ml_preprocessing_methods,
                                                                       word_embedding_method=word_embedding_method,
                                                                       word_embedding_params=word_embedding_params,
                                                                       algo_name=algo_name,
                                                                       algo_params=algo_params,
                                                                       model_validation_methods=model_validation_methods,
                                                                       action_flag_dict=action_flag_dict,
                                                                       train_csv_path=train_csv_path)
                    messageToPublish = {"model_validation_report: ": model_validation_report}

                else:
                    logging.info("loading model config for commited model")
                    config_data = utl._load_json(file=os.path.join(os.path.realpath("machine-learning-services"),
                                                                   'config', 'mlconfig.json'))

                    config_path = os.path.join(utl.homedir, config_data["OUTPUT_DIRECTORY_NAME"], product_id,
                                               config_data['MODEL_CONFIG_FILENAME'])
                    modelConfig = utl._load_json(config_path)

                    ml_preprocessing_methods = modelConfig["preprocessing_filters_list"]
                    word_embedding_method = modelConfig["word_embedding_method"]
                    test_csv_path = message.get("test_csv_path", None)
                    if test_csv_path != None:
                        if not os.path.exists(test_csv_path):
                            raise Exception("Invalid path!")
                    test_result = mls_obj.train_test_model(product_id=product_id,
                                                                       is_train=is_train,
                                                                       ml_preprocessing_methods=ml_preprocessing_methods,
                                                                       word_embedding_method=word_embedding_method,
                                                                       test_csv_path=test_csv_path)
                    messageToPublish = {"test_result: ": test_result}
                task_status_obj.update_status_rule(task_id= message.get("taskId"), status ="COMPLETED")
                logging.info(messageToPublish)

            elif command == "COMMIT_ML_MODEL":
                trainModelID = message["trainModelID"]
                productID = message["productID"]
                mls_obj = ml_services.machine_learning_services()
                mls_obj.commit_model(product_id=productID, train_model_id=trainModelID)
                messageToPublish = {}
                logging.info(messageToPublish)

            elif command == "ACTIVE_ML_MODEL_CONFIG":
                # product_id = message["productID"]
                product_id = '3001'
                obj = ml_services.machine_learning_services()
                modelConfig = obj.get_all_train_models_config(product_id=product_id)
                messageToPublish = {"taskId": message["taskId"],
                                    "command": message["command"],
                                    "MODEL_CONFIG": modelConfig}
                logging.info(messageToPublish)

            elif command == "TRAIN_TEST_STATUS":
                task_status = TaskStatusOperations().get_status_rule(task_id= message['taskId'], command = "TRAIN_TEST_DATA")
                messageToPublish = {"status" : task_status, "taskId":message["taskId"], "command":"TRAIN_TEST_STATUS"}

            else:
                error_message = "Invalid command!"
                logging.error("{} for 'taskId': {} , 'command':{}".format(error_message, message["taskId"], message["command"]))
                messageToPublish = {"taskId": message["taskId"],
                                    "command": message["command"],
                                    "ERROR": error_message}
            print(messageToPublish)
            return messageToPublish

        except Exception as err:
            if command == "TRAIN_TEST_DATA":
                task_status_obj.update_status_rule(task_id=message.get("taskId"), status="FAILURE")
            logging.error("Error while executing command: {}".format(command))
            logging.error("Error: {}".format(err))
            sys.exit(err)