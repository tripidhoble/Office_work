import os
import time
import subprocess

import threading

def runinthread(cmd, iscmd):

    print("Command :- ", cmd)
    if iscmd == 0:
        os.environ['LOGGER_LEVEL'] = 'info'
        os.environ['LOGGER_FILE_PATH'] = os.path.join(os.getcwd(),'api-gateway','applog')
        os.chdir(os.path.relpath('api-gateway'))
        os.system(cmd)
        os.chdir('..')
        return 1
    return os.system(cmd)


class Mythread(threading.Thread):

    def __init__(self,cmd, iscmd = 1):
        super(Mythread, self).__init__()
        self.cmd = cmd
        self.iscmd = iscmd

    def run(self):
        runinthread(self.cmd,self.iscmd)


if __name__ == "__main__":
    print("Stopping All running instances of mongod...")
    try:
        os.system("taskkill /im mongod.exe /f")
    except Exception as e:
        print("Currently Mongod is not running")
    time.sleep(30)


    print("Please close MongoDB instances, if any running....")
    print("Starting MongoDB ...")
    t1 = Mythread("mongod")
    print("MongoDB started..")


    print("Starting Data Preprocessing Service..")
    t2 = Mythread("python data-fetch-and-preprocess/dps_main.py")
    print("Data Preprocessing Service started..")


    print("Starting Machine Learning Service..")
    t3 = Mythread("python machine-learning-services/main_AMQP.py")
    print("Machine Learning Service started..")


    print("Starting Nodejs Service..")
    t4 = Mythread("npm start",iscmd= 0)
    print("Starting Nodejs Service started..")


    t1.start()
    t2.start()
    t3.start()
    t4.start()

    t1.join()
    t2.join()
    t3.join()
    t4.join()





