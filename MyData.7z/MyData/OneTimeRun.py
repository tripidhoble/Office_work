import os
import sys
import pymongo
import subprocess

def init_DB(db_name):
    client = pymongo.MongoClient()  # Connect to MongoClient
    db = client[db_name]
    return db

def creating_collections(db, collection_names):
    for name in collection_names:
        print("Creating collection of", name)
        my_col = db[name]
    return my_col

if __name__ == "__main__":
    try:
        print("Installing python amqp library")
        os.chdir("python-amqp-library")
        os.system("python setup.py sdist bdist_wheel")
        os.chdir("..")
        os.system("python -m pip install python-amqp-library/dist/pythonamqplibrary-0.1-py3-none-any.whl")

        db = init_DB("jarvis_db")
        collection = ["task_status", "product_details", "module_filters"]
        print(creating_collections(db, collection))

        print("Installing Javascript-amqp-library....")
        os.chdir("javascript-amqp-library")
        os.system("npm install")
        os.system("npm run build")

        source_path = os.getcwd()
        os.chdir("..")
        print("Installing Api-Gateway....")
        os.chdir("api-gateway")
        # if sys.platform == 'win32' or sys.platform == 'win64':
        #     print(os.system("dir"))
        # else:
        #     print(os.system("ls"))
        os.system("npm install")

        des = os.path.join(os.getcwd(), "node_modules", "javascript-amqp-library")
        if sys.platform == 'win32' or sys.platform == 'win64':
            os.system("xcopy \""+source_path+ "\" \""+des+ "\"\* /E")
        else:
            os.system("cp -avr  \""+source_path+ "\" \""+des+ "\" ")
        # if sys.platform == 'win32' or sys.platform == 'win64':
        #     print(os.system("dir"))
        # else:
        #     print(os.system("ls"))
        os.chdir("..")
        os.chdir("api-gateway")
        os.system("npm run build")
        print("Adding Logger level")
        if sys.platform == 'win32' or sys.platform == 'win64':
            subprocess.Popen(['powershell.exe', "$env:LOGGER_LEVEL='info'"])
            subprocess.Popen(['powershell.exe', "$env:LOGGER_FILE_PATH='applog'"])
        else:
            pass
    except Exception as e:
        print(e)