#======================================================================================
#title           :main.py
#description     :
#author          :Trupti Dhoble
#date            :
#version         :0.1
#notes           :
#python_version  :3.7
#======================================================================================

import os
import requests
import cliargsparser as cliargs
from processCommand import processCommand

import sys
sys.path.append(os.getcwd())
import warnings
warnings.filterwarnings("ignore")

def main():
    cli_obj = cliargs.CLI_ArgumentParser()
    args = cli_obj.get_parse_args
    processCommand(args)
    return None

if __name__ == "__main__":
    main()
