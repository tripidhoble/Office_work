import os
import sys
import time
import requests
import json
import glob
from pprint import pprint
# Constants from "mlconfig.json" in machine_learning services
HOMEDIR                         = os.path.join(os.path.expanduser("~"), "Jarvis")
OUTPUT_DIRECTORY_NAME           = "output_dir"
TEST_RESULT_FILENAME            = "Test_Results.json"
TEMP_TRAINED_MODELS_FOLDER_NAME = "temp_trained_models"
SERVICE_NAME                    = "machine_learning_service"
VALIDATION_REPORT_FILENAME      = "validation_report.json"

def processCommand(args):
    try:
        command = args['command']
        if command == "PERFORMANCE_METRICS":
            URL = "http://localhost:8000/api/log-analyser/performance-metrics"
            r = requests.get(url=URL)
            data = r.json()
            print(data)

        elif command == "SUPPORTED_METHODS":
            URL = "http://localhost:8000/api/log-analyser/supported-methods"
            r = requests.get(url=URL)
            data = r.json()
            print(data)

        elif command == "TRAIN_TEST_DATA":
            print("command: ",command)
            URL = "http://localhost:8000/api/log-analyser/train-test-model"
            data = {
                        "command"                : command,
                        "isTrain"                : args["isTrain"],
                        "train_csv_path"         : args.get("train_csv_path"),
                        "test_csv_path"          : args.get("test_csv_path"),
                        "mlPreprocessingMethods" : args["mlPreprocessingMethods"],
                        "wordEmbeddingType"      : args["wordEmbeddingType"],
                        "wordEmbeddingParameters": args["wordEmbeddingParameters"],
                        "algorithmName"          : args["algorithmName"],
                        "isHyperParameterTuning" : args["isHyperParameterTuning"],
                        "alogrithmParameters"    : args["alogrithmParameters"],
                        "modelValidationMethods" : args["modelValidationMethods"],
                        "actionFlag"             : args["actionFlag"]
                    }
            header = {"Product-Id": args["productID"]}
            r = requests.post(url=URL, data=data, headers=header)
            res = r.json()
            PARAMS = {"command": "TRAIN_TEST_STATUS", "taskId": res["taskId"]}

            while (1):
                r = requests.get(url="http://localhost:8000" + res["pollUri"], params=PARAMS, headers=header)
                response = r.json()
                taskStatus = response["status"]
                print ("status: {}".format(taskStatus))
                if(taskStatus!="INPROGRESS"):
                    if(args["isTrain"]):
                        latestTrainedModel = max(glob.glob(os.path.join(HOMEDIR, TEMP_TRAINED_MODELS_FOLDER_NAME, SERVICE_NAME,args["productID"],'*/')), key=os.path.getmtime)
                        model = os.path.basename(os.path.normpath(latestTrainedModel))
                        report =  os.path.join(latestTrainedModel, VALIDATION_REPORT_FILENAME )
                        print("Model Validation Report for '{}':".format(model))
                        with open(report) as json_data_file:
                            validation_report = json.load(json_data_file)
                            pprint(validation_report)
                    else:
                        print(HOMEDIR, OUTPUT_DIRECTORY_NAME, SERVICE_NAME , args["productID"], TEST_RESULT_FILENAME)
                        test_result = os.path.join(HOMEDIR, OUTPUT_DIRECTORY_NAME , args["productID"], TEST_RESULT_FILENAME)
                        print("Test Result: ")
                        with open(test_result) as json_data_file:
                            validation_report = json.load(json_data_file)
                            pprint(validation_report)
                    break
                time.sleep(10)


        elif command == "COMMIT_MODEL":
            URL = "http://localhost:8000/api/model-commit/commit"
            data = {"trainModelID":args["trainModelID"], "filterModelID":args["filterModelID"]}
            header = {"Product-Id": args["productID"]}
            requests.post(url=URL, data=data, headers=header)
            print("train-model and filter-model commited successfully")

        elif command == "ACTIVE_MODEL_CONFIG":
            URL = "http://localhost:8000/api/model-config/all-model-config"
            header = {"Product-Id": args["productID"]}
            r = requests.get(url=URL, headers=header)
            res = r.json()
            print(res)

        elif command == "COPY_DATA":
            URL = "http://localhost:8000/api/data-pre-processing/copy-data"
            data = {}
            # data = {
            #     "command": command,
            #     "isTrain": args["isTrain"],
            #     "train_csv_path": args.get("train_csv_path"),
            #     "test_csv_path": args.get("test_csv_path"),
            #     "mlPreprocessingMethods": args["mlPreprocessingMethods"],
            #     "wordEmbeddingType": args["wordEmbeddingType"],
            #     "wordEmbeddingParameters": args["wordEmbeddingParameters"],
            #     "algorithmName": args["algorithmName"],
            #     "isHyperParameterTuning": args["isHyperParameterTuning"],
            #     "alogrithmParameters": args["alogrithmParameters"],
            #     "modelValidationMethods": args["modelValidationMethods"],
            #     "actionFlag": args["actionFlag"]
            # }
            # header = {"Product-Id": args["productID"]}
            # r = requests.post(url=URL, data=data, headers=header)
            # res = r.json()
            # PARAMS = {"command": "TRAIN_TEST_STATUS", "taskId": res["taskId"]}
            # r = requests.post(url=URL, data=data, headers=header)
            # data = r.json()
            # PARAMS = {"command": "COPY_STATUS", "taskId": data["taskId"]}
            PARAMS = {"command": "COPY_DATA", "taskId": "taskId"}
            header = {"Product-Id": args["productID"]}
            while (1):
                r = requests.get(url="http://localhost:8000" + data["pollUri"], params=PARAMS, headers=header)
                response = r.json()
                taskStatus = response["status"]
                print ("status: {}".format(taskStatus))
                if (taskStatus != "INPROGRESS"):
                    break
                time.sleep(10)
            print ("status: {}".format(taskStatus))

        elif command == "PRE_DEFINED_FILTERS":
            URL = "http://localhost:8000/api/data-pre-processing/predefined-filters"
            r = requests.get(url=URL)
            data = r.json()
            print(data)

        elif command == "FILTER_TRAIN_DATA":
            URL = "http://localhost:8000/api/data-pre-processing/apply-filters-for-train"
            data = {
                    "command": command,
                    "filterExpressions": args.get("filters"),
                    "path": args.get("path")
                }
            header = {"Product-Id": args["productID"]}
            r = requests.post(url=URL, data=data, headers=header)
            res = r.json()
            PARAMS = {"command": "FILTER_TRAIN_STATUS", "taskId": res["taskId"]}
            while (1):
                r = requests.get(url="http://localhost:8000" + res["pollUri"], params=PARAMS, headers=header)
                response = r.json()
                taskStatus = response["status"]
                if (taskStatus != "INPROGRESS"):
                    break
                print ("status: {}".format(taskStatus))
                time.sleep(10)
            print ("status: {}".format(taskStatus))

        elif command == "FILTER_TEST_DATA":
            URL = "http://localhost:8000/api/data-pre-processing/apply-filters-for-test"
            data = {
                "command": command,
                "labelData": args.get("data_with_labels"),
                "path": args.get("path")
            }
            header = {"Product-Id": args["productID"]}
            r = requests.post(url=URL, data=data, headers=header)
            res = r.json()
            PARAMS = {"command": "FILTER_TEST_DATA", "taskId": res["taskId"]}
            while (1):
                r = requests.get(url="http://localhost:8000" + res["pollUri"], params=PARAMS, headers=header)
                response = r.json()
                taskStatus = response["status"]
                if (taskStatus != "INPROGRESS"):
                    break
                print ("status: {}".format(taskStatus))
                time.sleep(10)
            print ("status: {}".format(taskStatus))

    except Exception as err:
        print("machine_learning_service execution aborted!")
        sys.exit(err)