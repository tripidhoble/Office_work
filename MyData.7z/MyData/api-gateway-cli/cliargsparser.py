# ======================================================================================
# title           :cliargsparser.py
# description     :
# author          :Trupti Dhoble
# date            :
# version         :0.1
# notes           :
# python_version  :3.7
# ======================================================================================

import argparse

class CLI_ArgumentParser():

    def __init__(self):
        return None

    @property
    def get_parse_args(self):
        # construct the argument parser and parse the arguments
        ap = argparse.ArgumentParser()

        # different information ids & methods
        ap.add_argument("-pr_id",
                        "--productID",
                        type=str,
                        default="productId",
                        help="product ID")

        ap.add_argument("-tr_id",
                        "--trainModelID",
                        type=str,
                        help="Train Model ID to commit the model")

        ap.add_argument("-filter_id",
                        "--filterModelID",
                        type=str,
                        help="filter ModelID to commit the model")

        ap.add_argument("-train_path",
                        "--train_csv_path",
                        type=str,
                        default=None,
                        help="folder path for train csv")

        ap.add_argument("-test_path",
                        "--test_csv_path",
                        type=str,
                        default=None,
                        help="folder path for test csv")

        ap.add_argument("-pk_name",
                        "--packagesName",
                        type=str,
                        default="packagesName",
                        choices=["scikit-learn"],
                        help="Package Name")

        ap.add_argument('-pr_methods',
                        '--mlPreprocessingMethods',
                        nargs='+',
                        default=["toLowercase", "removeExtendedSpaces",
                                 "removePunctuation", "removeStopwords",
                                 "removeSpecialCharacters", "strip"],
                        choices=["toLowercase", "removeExtendedSpaces",
                                 "removePunctuation", "removeStopwords",
                                 "removeSpecialCharacters", "strip"],
                        help="Preprocessing Methods to be applied on dataset")

        ap.add_argument("-we_type",
                        "--wordEmbeddingType",
                        type=str,
                        default="CountVectorizer_",
                        choices=["CountVectorizer_", "TfidfVectorizer_", "AVGWord2Vec_", "TFIDFWord2Vec_"],
                        help="word embedding method Type")

        ap.add_argument('-we_params',
                        '--wordEmbeddingParameters',
                        metavar="KEY=VALUE",
                        nargs='+',
                        default={},
                        help="Parameters for word embedding method")

        ap.add_argument("-algo_Name",
                        "--algorithmName",
                        type=str,
                        default="LogisticRegression_",
                        choices=["LogisticRegression_", "RandomForestClassifier_", "MultinomialNB_",
                                 "VotingClassifier_", "KNN_", "DecisionTree_", "LDA_"],
                        help="Algorithm Name")

        ap.add_argument('-algo_params',
                        '--alogrithmParameters',
                        metavar="KEY=VALUE",
                        nargs='+',
                        default={},
                        help="Parameters for algorithm ")

        ap.add_argument('-val_methods',
                        '--modelValidationMethods',
                        nargs='+',
                        default=["accuracy", "precision", "recall", "f1_score", "classification_report"],
                        choices=["accuracy", "precision", "recall", "f1_score", "classification_report"],
                        help="Model Validation Methods")

        # action Flags
        ap.add_argument("-param_tunning_Flag",
                        "--isHyperParameterTuning",
                        type=int,
                        default=0,
                        choices=[0, 1],
                        help="hyper Parameter tuning flag")

        ap.add_argument("-act_Flag",
                        "--actionFlag",
                        metavar="KEY=VALUE",
                        nargs='+',
                        default={ },
                        help="Preprocessing flag (to skip the preprocessing)")

        ap.add_argument("-tr_Flag",
                        "--isTrain",
                        type=int,
                        default=1,
                        choices=[0, 1],
                        help="test flag (to skip the test file prediction)")

        ap.add_argument('--filters',
                        type=str,
                        nargs='*',
                        default=argparse.SUPPRESS,
                        help="--filters name <filter_list>")

        ap.add_argument('--data_with_labels',
                        type=str,
                        nargs='*',
                        default=argparse.SUPPRESS,
                        help="-- 0 or 1 ")
        
        ap.add_argument('--path',
                        type=str,
                        nargs='*',
                        default="",
                        help="--path <complete_path> ")

        ap.add_argument("-cmd",
                        "--command",
                        type=str,
                        default=None,
                        choices=["SUPPORTED_METHODS","PERFORMANCE_METRICS","TRAIN_TEST_DATA","COMMIT_MODEL","ACTIVE_MODEL_CONFIG",
                                 "PRE_DEFINED_FILTERS", "FILTER_TRAIN_DATA", "FILTER_TEST_DATA"])

        args = vars(ap.parse_args())
        return args

