export default function ExchangeDetails(channelName, exchangeType, exchangeName, queueNames) {
    this.channelName = channelName;
    this.exchangeType = exchangeType;
    this.exchangeName = exchangeName;
    this.queueNames = queueNames;
};
