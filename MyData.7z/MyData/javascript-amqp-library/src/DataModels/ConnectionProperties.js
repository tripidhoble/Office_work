export default function ConnectionDetails(host, port, virtualHost, username, password) {
    this.host = host;
    this.port = port;
    this.virtualHost = virtualHost;
    this.username = username;
    this.password = password;
};

Object.defineProperty(ConnectionDetails.prototype, 'protocol', {
    value: 'amqp',
    writable: false,
    configurable: false,
    enumerable: false
});
