import amqp from 'amqplib';
import {channelStatusEnum, connectionStatusEnum} from '../EnumModels/StatusValue';

/**
 * API class to serve the connections to rabbitMQ.
 */
export default class RabbitMqMessageConnection {
    constructor() {
        this.allChannelProps={};
        this.channels = {};
        this.channelConsumerTags={};
    }

    /**
     * This will set the connection details which will include the host, port, virtual host details
     * along with the username and password to connect to the host.
     */
    setConnectionDetails(connectionDetails) {
        this.connectionDetails = connectionDetails;
        return this;
    }

    /**
     * This method will validate the passed parameters for the exchange and the queues
     * throws an error if the queue names are blank.
     * throws an error if more than 2 queues are passed for a single exchange
     * or if no queues are passed.
     * throws an error if the exchange name is blank
     * @param channelProps are the properties of type ExchangeDetails
     *  which have the channel, exchange and queue details
     */
    setChannelExchangeProperties(channelProps) {

        //Validate the passed properties and then save the values.
        if(channelProps.queueNames.length > 2) {
            throw "You can not have more than 2 queues for a exchange";
        }else if(channelProps.queueNames.length === 0) {
            throw "You must provide at least one queue for communication";
        }

        for(let index=0; index < channelProps.queueNames.length; index++) {
            const queueName = channelProps.queueNames[index];
            if(queueName === '') {
                throw "Queue name can not be left blank";
            }
        }

        if(channelProps.exchangeName === '') {
            throw "Exchange name can not be left blank";
        }

        //Queue details are valid, save the details
        this.allChannelProps[channelProps.channelName] = channelProps;
        return this;
    }

    /**
     * This method will add the error and close connection event listeners.
     * The listeners will be invoked only after the connection creation has been completed.
     * For any problems during connection creation, the promise will have the correct status.
     * @param channelStatusCallback which needs to be invoked once the setup is done
     */
    addConnectionEvents(connectionStatusCallback) {

        //TODO add error code handling
        this.connection.on('error', (error) => {
            connectionStatusCallback(connectionStatusEnum.ERROR, error.code);

            /*
                Simply push the handling to the end of the queue to
                avoid clearing events within the handler
            */
            setTimeout(() => {
                this.removeConnectionEvents();
            }, 1);
        });
        this.connection.on('close', (close) => {
            connectionStatusCallback(connectionStatusEnum.CLOSED, close);

            /*
                Simply push the handling to the end of the queue to
                avoid clearing events within the handler
            */
            setTimeout(() => {
                this.removeConnectionEvents();
            }, 1);
        });
    }

    /**
     * This will remove all the listeners that had been attached to the channel.
     * @param channel the instance on which the listeners need to be removed.
     */
    removeConnectionEvents() {
        this.connection.removeAllListeners();
        for(const key in this.channels) {

            //Remove all the event listeners for all the channels
            const channelInstance = this.channels[key];
            this.removeChannelEvents(channelInstance, false);
        }
        this.channels = {};
        this.connection = null;
    }

    /**
     * Create the connection and return a resolved promise once the connection has been established.
     * If any failure is encountered a rejected promise will be returned.
     * @returns A Promise indicating the status of the connection.
     */
    createConnection(connectionStatusCallback) {
        const amqplibConnectionDetails = {
            protocol: this.connectionDetails.protocol,
            hostname: this.connectionDetails.host,
            port: this.connectionDetails.port,
            vhost: this.connectionDetails.virtualHost,
            username: this.connectionDetails.username,
            password: this.connectionDetails.password
        };

        /*
          Return the connection promise. This promise will resolve only once all the promises inside
          have resolved successfully. Resolved promise indicates succesful connection and rejected promise
          indicates that one of the connections has failed.
        */
        return amqp.connect(amqplibConnectionDetails).then( connection => {

            /*
                Save the connection once it has been established.
                This will be used be the client to publish messages.
            */
            this.connection = connection;
            this.addConnectionEvents(connectionStatusCallback);
        }).catch(error => Promise.reject(error));
    }

    /**
     * This method will add the error and close channel event listeners.
     * The listeners will be invoked only after the channel creation has been completed.
     * For any problems during channel creation, the promise will have the correct status.
     * @param channel the instance which needs to listen to the events
     * @param channelStatusCallback which needs to be invoked once the setup is done
     * @param channelSetup which will signify whether setup is completed or not.
     */
    addChannelEvents(channel, channelStatusCallback, channelSetup) {
        //TODO add error code handling
        channel.on('error', (error) => {

            /*
                Publish the error only if the channel has already been setup, because
                during channel setup the Promise will be returned with the correct status
            */
            if(!channelSetup.progress) {
                channelStatusCallback(channelStatusEnum.ERROR, error.code);

                /*
                    Simply push the handling to the end of the queue to
                    avoid clearing events within the handler
                */
                setTimeout(() => {
                    this.removeChannelEvents(channel, true);
                }, 1);
            }
        });
        channel.on('close', (close) => {

            /*
                Publish the close event only if the channel has already been setup, because
                during channel setup the Promise will be returned with the correct status
            */
            if(!channelSetup.progress) {
                channelStatusCallback(channelStatusEnum.CLOSED, close);

                /*
                    Simply push the handling to the end of the queue to
                    avoid clearing events within the handler
                */
               setTimeout(() => {
                this.removeChannelEvents(channel, true);
            }, 1);
            }
        });
    }

    /**
     * This will remove all the listeners that had been attached to the channel.
     * @param channel the instance on which the listeners need to be removed.
     */
    removeChannelEvents(channel, deleteChannel) {
        channel.removeAllListeners();
        if(deleteChannel) {
            for(const key in this.channels) {

                //If the channel object is same then delete that value
                if(this.channels[key] === channel) {
                    delete this.channels[key];
                    break;
                }
            }
        }
    }

    /**
     * This method will begin the channel creation process. Once created, it will then proceed
     * to add channel error/close listeners, create the exchange, create upto two queues
     * that have been passed and bind the queues to the exchanges. Once everything is complete a
     * resolved promise will be returned. If even one of the steps fail, a rejected promise will
     * be returned.
     * @param channelName is the name of the channel which must be picked for setting up the channel
     * @returns a Promise which will resolve if everything is setup otherwise it will be rejected
     */
    createChannel(channelName, channelStatusCallback) {

        //Channel already exists simply return the final response
        if(this.channels[channelName]) {
            return Promise.resolve();
        }

        return this.connection.createConfirmChannel().then( channel => {
            const channelSetup = {
                progress: true
            };

            const channelProps = this.allChannelProps[channelName];
            this.channels[channelName] = channel;
            this.addChannelEvents(channel, channelStatusCallback, channelSetup);

            /*
                Once the channel has been created proceed to create the exchanges
                and queues that must be bound to it.
            */
            return channel.assertExchange(channelProps.exchangeName, channelProps.exchangeType,
                {durable: true}).then( () => {
                    const queuePromises = [];

                    for(let queueIndex = 0; queueIndex<channelProps.queueNames.length; queueIndex++) {
                        const queueName = channelProps.queueNames[queueIndex];

                        /*
                            For each queue present in an exchange, create it and bind it to
                            that exchange. Add all the promises to an array for which the function
                            must wait to be completed.
                        */
                        queuePromises.push(channel.assertQueue(queueName, {durable: true})
                            .then(() => {
                                return channel.bindQueue(queueName, channelProps.exchangeName, queueName)
                                    .then(() => Promise.resolve())
                                    .catch( error => Promise.reject(error));
                            }).catch( error => Promise.reject(error))
                        );
                    }

                    //Resolve the channel creation process if all the promises have resolved.
                    return Promise.all(queuePromises)
                        .then(() => {

                            /*
                              Ensure the progress is falsified so that furhter
                              errors invoke the callbacks
                            */
                            channelSetup.progress = false;
                            return Promise.resolve()
                        })
                        .catch(error => Promise.reject(error));

                }).catch( error => Promise.reject(error))
        }).catch( error => {
            const channelInstance = this.channels[channelName];
            if(channelInstance) {
                this.removeChannelEvents(channelInstance, true);
            }
            return Promise.reject(error)
        });
    }

    /**
     * This method will be passed as a callback to the "return" event handler.
     * If invoked it will change the status of the messagePublished to false
     * and it will reject the message publish promise.
     * @param reject reject handler of that promise within which this listener has been attached
     * @param messagePublished is an object with a status param which will be falsyfied.
     */
    publisherConfirmListener(reject, messagePublished) {
        return (message) => {
            messagePublished.status = false;
            let returnedMsg = '';
            if(message && message.content) {
                returnedMsg = message.content.toString();
            }

            reject('Message: ' + returnedMsg + ' has been returned because ' +
                'it was unroutable, please check whether the ' +
                'queue and exchange exist.');
        };
    }

    /**
     * This method will publish to the queue bound on the exchange within the provieded
     * channelName. If the publish was succesful, it will return a resolved promise
     * otherwise a rejected promise will be returned.
     * @param {string} channelName is the name of the channel where the message must be published
     * @param {string} exchangeQueueName is the queue name on which the message should be routed
     * @param {*} message is the message that needs to be sent
     * @param {*} messageProperties are the properties that need to be provided
     * @returns a promise indicating the success or failure of publishing.
     */
    publishMessage(channelName, exchangeQueueName, message, messageProperties = {}) {
        //TODO Create an interface for these messageProperties
        messageProperties = Object.assign(messageProperties, {
            persistent: true, mandatory: true, contentType: 'application/json'
        });

        return new Promise((resolve, reject) => {
            const channelProps = this.allChannelProps[channelName];

            //Non existant properties indicate an incorrect channel name, reject the promise and return
            if(!channelProps) {
                reject("Channel named " + channelName + " does not exist");
                return;
            }

            const channelInstance = this.channels[channelName];

            let queueFound = false;
            const messagePublished = {status: true};

            for(let queueIndex=0;queueIndex<channelProps.queueNames.length; queueIndex++) {
                const queueName = channelProps.queueNames[queueIndex];
                if(queueName === exchangeQueueName) {
                    queueFound = true;
                    const returnMessageEventListener = this.publisherConfirmListener(reject, messagePublished);

                    /*
                        Listen to returned message event. If fired, the message was not delivered.
                        This will be invoked before the acknowledged callback.
                        Once invoked, it will be removed from the event listener list
                        the next time the 'return' event is invoked.
                    */
                    channelInstance.once('return', returnMessageEventListener);

                    /*
                        Check whether the message was delivered or not. In case if
                        the message was delivered then wait for the callback to be
                        triggered to recieve either acknowledgement or unacknowledgement.
                    */
                    const publishedValue = channelInstance.publish(channelProps.exchangeName,
                        exchangeQueueName, new Buffer(JSON.stringify(message)), messageProperties,
                        (error, _)=> {

                        /*
                            Let the client handle the rejection by either
                            republishing the message at a later time
                            or dropping the request and returning an error to the client.
                            Proceed to check the status only if the message published is true
                        */
                        if(messagePublished.status) {

                            //Remove the listener that had been added because it was not invoked.
                            channelInstance.removeListener('return', returnMessageEventListener);
                            if(error) {
                                reject('Message nacked by broker');
                            }else {
                                resolve('Message acked by broker');
                            }
                        }
                    });

                    /*
                        If the publish method returns false, then the message was either not published
                        or it was unroutable. Hence reject the promise.
                    */
                    if(!publishedValue) {
                        messagePublished.status = false;
                        //Remove the listener that had been added because it was not invoked.
                        channelInstance.removeListener('return', returnMessageEventListener);
                        reject('Message can not be sent, make sure the connection exists');
                    }
                    break;
                }
            }

            if(!queueFound) {
                reject("Queue named " + exchangeQueueName + " does not exist");
            }
        });
    }

    /**
     * This method will begin consuming the messages and return a Promise for its status.
     * If either the channel or a queue is non-existant, then the promise will be rejected
     * with an appropriate error message.
     * @param channelName is the name of the channel on which consumption must begin
     * @param exchangeQueueName is the name of the queue which will begin consuming
     * @param callBack will be invoked whenever a message is received.
     * @returns a Promise which will resolve if consumption has started,
     * otherwise it will be rejected
     */
    consumeMessage(channelName, exchangeQueueName, callBack) {
        return new Promise((resolve, reject) => {
            const channelProps = this.allChannelProps[channelName];

            //Non existant properties indicate an incorrect channel name, reject the promise and return
            if(!channelProps) {
                reject("Channel named " + channelName + " does not exist");
                return;
            }
            const channelInstance = this.channels[channelName];

            let queueFound = false;
            for(let queueIndex=0;queueIndex<channelProps.queueNames.length; queueIndex++) {
                const queueName = channelProps.queueNames[queueIndex];
                if(queueName === exchangeQueueName) {
                    queueFound = true;

                    channelInstance.consume(exchangeQueueName, (message) => {

                        // The callback will be invoked for every message that exists
                        if(message && message.content) {
                            callBack(this, channelName, exchangeQueueName, message,
                                JSON.parse(message.content.toString()));
                            console.log("message is: ", message.content.toString());
                        }
                    }).then(consumptionReady => {
                        this.channelConsumerTags[exchangeQueueName] = consumptionReady.consumerTag;
                        return resolve();
                    }).catch(error=> reject(error));
                    break;
                }
            }

            if(!queueFound) {
                reject("Queue named " + exchangeQueueName + " does not exist")
            }
        });
    }

    /**
     * This method will stop consuming from the queue and return a Promise for its status.
     * If any of the input objects are wrong or if there is any mismatch, a rejected promise will
     * be returned, otherwise the promise will be resolved.
     * @param channelName is the channel on which consumption must be stopped
     * @param queueName is the name of the queue which must stop consuming
     * @returns a promise indicating the status of stopping consumption
     */
    stopConsume(channelName, exchangeQueueName) {
        const consumerTagForChannel = this.channelConsumerTags[exchangeQueueName];

        //Non existant consumer tag indicates an incorrect queue name, reject the promise and return
        if(!consumerTagForChannel) {
            return Promise.reject("Queue named " + exchangeQueueName + " does not exist");
        }

        const channelInstance = this.channels[channelName];

        //Non existant properties indicate an incorrect channel name, reject the promise and return
        if(!channelInstance) {
            return Promise.reject("Channel named " + channelName + " does not exist");
        }

        const channelProps = this.allChannelProps[channelName];
        let queueFound = false;

        /*
            Search for the queue in the passed channel, if they mismatch then
            a queue belonging to a different channel has been passed for closure
        */
        for(let index=0; index<channelProps.queueNames.length; index++) {
            const queueName = channelProps.queueNames[index];
            if(queueName === exchangeQueueName) {
                queueFound = true;
                break
            }
        }
        
        if(!queueFound) {
            return Promise.reject("Queue named " + exchangeQueueName + " does not exist " +
            "in channel named: " + channelName);
        }

        return channelInstance.cancel(consumerTagForChannel).then(() => {

            //Clear out stale info from object
            delete this.channelConsumerTags[exchangeQueueName];
            return Promise.resolve();
        }).catch(error => Promise.reject(error));
    }

    /**
     * This method will acknowledge the given message synchronously.
     * throws an error if the supplied channelName has not been declared.
     * @param messageProperties are the properties of the message that was delivered and
     * these properties will be checked for stopping the message
     * @param channelName is the name of the channel on which the acknowledgement must be sent
     */
    basicAck(messageProperties, channelName) {
        const channelInstance = this.channels[channelName];
        if(!channelInstance) {
            throw "Channel named " + channelName + " does not exist";
        }
        channelInstance.ack(messageProperties);
    }

    /**
     * This method will send a negative acknowledgement and will not instruct requeue.
     * Hence this method will discard the messages.
     * throws an error if the supplied channelName has not been declared.
     * @param messageProperties the properties of the message that was delivered and
     * these properties will be checked for stopping the message
     * @param channelName the channel on which to send the negative acknowledgement
     */
    basicNack(messageProperties, channelName) {
        const channelInstance = this.channels[channelName];
        if(!channelInstance) {
            throw "Channel named " + channelName + " does not exist";
        }
        channelInstance.nack(messageProperties, false, false);
    }

    /**
     * This method will send a negative acknowledgement but will instruct requeue.
     * Hence this method will reque the message for later processing.
     * throws an error if the supplied channelName has not been declared.
     * @param messageProperties the properties of the message that was delivered and
     * these properties will be checked for stopping the message
     * @param channelName the channel on which to send the negative acknowledgement
     */
    basicReject(messageProperties, channelName) {
        const channelInstance = this.channels[channelName];
        if(!channelInstance) {
            throw "Channel named " + channelName + " does not exist";
        }
        channelInstance.reject(messageProperties, true);
    }

    /**
     * This method will close the channel and return a Promise for its status.
     * Rejects the promise if the supplied channelName has not been declared.
     * Rejects the promise if the channel is already closed or is being closed.
     * @param channelName is the name of the channle which must be closed.
     * @returns a Promise with the status of the channel closure.
     */
    closeChannel(channelName) {
        const channelInstance = this.channels[channelName];

        //Non existant properties indicate an incorrect channel name, reject the promise and return
        if(!channelInstance) {
            return Promise.reject("Channel named " + channelName + " does not exist");
        }

        return channelInstance.close().then(() => {
            this.removeChannelEvents(channelInstance, true);
        }).catch( () => {
            return Promise.reject('Channel is either closed or it is currently being closed');
        });
    }

    /**
     * This method will close the connection and return a promise for its status.
     * If the channel is closed successfully then all the channel instances will be cleared.
     * Rejects the promise if the connection is being closed or is already closed.
     */
    closeConnection() {
        return this.connection.close().then(() => {
            this.removeConnectionEvents();
        }).catch( () => {
            return Promise.reject('Connection is either closed or it is currently being closed');
        });
    }
};

RabbitMqMessageConnection.prototype.exchangeTypes = {
    DIRECT: 'direct',
    FANOUT: 'fanout',
    TOPIC: 'topic',
    HEADERS: 'headers'
};

//Will prevent object properties from being added, deleted or changed.
Object.freeze(RabbitMqMessageConnection.prototype.exchangeTypes);
