function ChannelStatus() {};

Object.defineProperty(ChannelStatus.prototype, 'ERROR', {
    value: 'error',
    writable: false,
    configurable: false,
    enumerable: false
});

Object.defineProperty(ChannelStatus.prototype, 'CLOSED', {
    value: 'closed',
    writable: false,
    configurable: false,
    enumerable: false
});

const channelStatusEnum = new ChannelStatus();

function ConnectionStatus() {};

Object.defineProperty(ConnectionStatus.prototype, 'ERROR', {
    value: 'error',
    writable: false,
    configurable: false,
    enumerable: false
});

Object.defineProperty(ConnectionStatus.prototype, 'CLOSED', {
    value: 'closed',
    writable: false,
    configurable: false,
    enumerable: false
});

const connectionStatusEnum = new ConnectionStatus();

export {channelStatusEnum, connectionStatusEnum};
