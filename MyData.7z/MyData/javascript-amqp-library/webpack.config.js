const path = require('path');
const webpack = require('webpack');
//const CompressionPlugin = require('compression-webpack-plugin');
const nodeExternals = require('webpack-node-externals');

let mode;
if(process.env.NODE_ENV === 'production') {
    mode = 'production';
}else {
    mode = 'development';
}

var serverConfig = {
  entry: './src/index.js',
  mode: mode,
  target: 'node',
  externals: [nodeExternals()],
  output: {
    filename: 'index.js',
    path: path.resolve(__dirname, 'lib'),
    libraryTarget: 'commonjs2'
  },
  module: {
    rules: [
      { test: /\.js$/, exclude: /node_modules/, loader: "babel-loader" }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env': {
        'NODE_ENV': JSON.stringify(mode)
      }
    })/*,
    new CompressionPlugin({
      asset: "[path].gz[query]",
      algorithm: "gzip",
      test: /\.js$|\.css$|\.html$/,
      threshold: 10240,
      minRatio: 0.8
    })*/
  ]
};

module.exports = [serverConfig];
