from pythonamqplibrary.StatusEnums.StatusValues import ChannelStatus, PublishStatus

# Class that will handle all channel related requests.
#This is meant only for internal use and is not an actual API
class _RabbitMqChannelImpl(object):

    def __init__(self, rabbit_impl, channel_props, channel_name, channel_status_callback,
        confirm_publish_callback):
        self.channel_props = channel_props
        self.channel_name = channel_name
        self.channel_status_callback = channel_status_callback
        self.confirm_publish_callback = confirm_publish_callback

        # Save the instance so that the created channel can be adde to its dictionary
        self.rabbit_impl = rabbit_impl
        self.publish_status_received = False

    # This callback method will be invoked when a message has been published but was
    # unroutable, that is, it was unable to find the queue. Upon reception
    # it will set a flag to prevent the acknowledge feedback which is also received
    # even though the message was not delivered.
    # This method will invoke the same callback which listens to acknowledged messages
    def publish_rejected_callback(self, channel, method, properties, body):
        confirmation_type = PublishStatus.RETURN.value
        self.publish_status_received = True
        self.confirm_publish_callback(self.rabbit_impl, confirmation_type)

    # This callback will be invoked whenever any error in the channel occurs.
    # It will be invoked with the ChannelStatus.ERROR enum
    def channel_status_handler(self, channel, exception):

        # Channel closed, remove the instance from the parent
        self.rabbit_impl._setChannel(self.channel_name, None)
        self.channel = None

        #TODO add error code handling
        self.channel_status_callback(self.rabbit_impl, ChannelStatus.ERROR.value, exception)

    # This will return the ACK or NACK PublishStatus enum.
    # The acknowledgement will be ignored if the returned event was triggered
    def publish_status(self, method_frame):

        #Process the status only if the message has not been returned
        if self.publish_status_received == False:
            confirmation_type = method_frame.method.NAME.split('.')[1].lower()
            if confirmation_type == 'ack':
                confirmation_type = PublishStatus.ACK.value
            elif confirmation_type == 'nack':
                confirmation_type = PublishStatus.NACK.value

            self.confirm_publish_callback(self.rabbit_impl, confirmation_type)

        # Falsify the value so that all future requests are processed
        self.publish_status_received = False

    # This is a callback which will be called once the queue is bound successfully.
    # This will invoke the channel_status_callback which is passed in by the client
    # with the ChannelStatus.OPENED enum value.
    def queue_bound(self, __unused_frame):
        self.channel.confirm_delivery(self.publish_status)
        self.channel_status_callback(self.rabbit_impl, ChannelStatus.OPENED.value)

    # This is a callback which will be called once the queue has been created succesfully.
    # This will then proceed to bind the queue with the exchange and pass another
    # callback which will be invoked once the queue has been bound successfully.
    def queue_declared(self, queue_details):
        queue_name = queue_details.method.queue
        #If a blank name is sent then the created queue's name will be sent to the binding
        self.channel.queue_bind(queue_name, self.channel_props.exchange_name,
            callback=self.queue_bound)

    # This is a callback which will be called once the exchange has been created succesfully.
    # This will then proceed to create those queues that need to be bound to this exchange.
    # Once created the callback that binds the queues to the exchange will be called.
    def exchange_declared(self, __unused_frame):
        for queue_name in self.channel_props.queue_names:

            # make queue durable so that after restart the queue is recreated
            # and the message is not lost
            self.channel.queue_declare(queue_name, durable=True, callback=self.queue_declared)

    # This is a callback which will be called once the channel has been created successfully.
    # This will then add the callbacks which will listen to the channel closed and message
    # returned callbacks. After this, it will proceed to declare an exchange. Once declared,
    # the callback which creates the queues will be called.
    def channel_open(self, channel):

        # Save the created channel instance to the dictionary of the rabbit implementation class.
        self.rabbit_impl._setChannel(self.channel_name, channel)
        self.channel = channel
        self.channel.add_on_return_callback(self.publish_rejected_callback)
        self.channel.add_on_close_callback(self.channel_status_handler)

        self.channel.exchange_declare(self.channel_props.exchange_name,
            self.channel_props.exchange_type, durable=True, callback=self.exchange_declared)