import pika
from pika.exceptions import AMQPConnectionError, AMQPChannelError, ConnectionClosed, ChannelClosed, ReentrancyError

from pythonamqplibrary.MessageServiceApi.MessageConnectionApi import MessageQueueConnection
from pythonamqplibrary.MessageServiceImpl.RabbitChannelImpl import _RabbitMqChannelImpl
from pythonamqplibrary.ConnectionExceptions.InputExceptionClass import NoQueueError, QueueCreationError, ExchangeCreationError, ChannelWrongNameError
from pythonamqplibrary.ConnectionExceptions.ConnectionExceptionClass import ChannelCloseException, ConnectionCloseException
from pythonamqplibrary.StatusEnums.StatusValues import ChannelStatus, ConnectionSetupStatus

import json
import functools
from enum import Enum

#API class to serve the connections to rabbitMQ.
class RabbitMqConnectionImpl(MessageQueueConnection):
    ExchangeTypes = Enum('ExchangeTypes', {
        'DIRECT': 'direct',
        'FANOUT': 'fanout',
        'TOPIC': 'topic',
        'HEADERS': 'headers'
    })

    def __init__(self):
        self.__all_channel_props={}
        self.__channels = {}
        self.__consumer_tags= {}

    # This will set the connection details which will include the host, port, virtual host details
    # along with the username and password to connect to the host.
    def set_connection_details(self, connection_details):
        self.connection_details = connection_details
        return self

    # This method will validate the passed parameters for the exchange and the queues
    # raises QueueCreationError if the queue names are blank.
    # raises QueueCreationError if more than 2 queues are passed for a single exchange
    # raises ExchangeCreationError if the exchange name is blank
    # or if no queues are passed.
    def set_channel_exchange_properties(self, channel_exchange_props):
        if len(channel_exchange_props.queue_names) > 2:
            raise QueueCreationError("You can not have more than 2 queues for a exchange")
        elif len(channel_exchange_props.queue_names) == 0: 
            raise QueueCreationError("You must provide at least one queue for communication")

        for queue_name in channel_exchange_props.queue_names:
            if queue_name == '':
                raise QueueCreationError("Queue name can not be left blank")

        if channel_exchange_props.exchange_name == '':
            raise ExchangeCreationError("Exchange name can not be left blank")

        #Queue details are valid, save the details
        self.__all_channel_props[channel_exchange_props.channel_name] = channel_exchange_props
        return self

    # For internal use only. This method will set the channel instance
    # corresponding to the provided channel name.
    def _setChannel(self, channel_name, channel_instance):
        if channel_instance is None:
            self.__channels.pop(channel_name, None)
        else:
            self.__channels[channel_name] = channel_instance

    # This method will invoke the passed callback in a threadsafe manner.
    # For any form of processing once a new thread has been passed, this
    # method must be called with the necessary parameters.
    def invoke_threadsafe_callback(self, callback, channel_name, delivery_tag = None, *args, **kwargs):
        callbackToTrigger = functools.partial(callback, self, channel_name, delivery_tag, args, kwargs )
        self.connection.ioloop.add_callback_threadsafe(callbackToTrigger)

    # For internal use only. This method will create a closure to handle the connection statuses
    # If the connection experiences an error then the ioloop for that connection will be
    # stopped. If the connection is stopped then the connection instance will be nullified
    def __connection_callback_closure(self, type, connection_callback):
        def callback_handler(connection, exception=None):
            if type == ConnectionSetupStatus.STOPPED.value or type == ConnectionSetupStatus.ERROR.value:

                #remove all channel instances from the dictionary
                self.__channels.clear()
                self.connection.ioloop.stop()
                self.connection = None

            # TODO add error code handling
            # if exception is not None:
            #     #Check the exception instance and pass the custom exception instance
            #     if isinstance(exception, AMQPConnectionError):
            #         exception = ConnectToAmqpError("No connection to host " + str(self.connection_details.host) +
            #             " please check your connection and try again")

            connection_callback(self, type, exception)

        return callback_handler

    # This method will create the connection with the necessary parameters.
    # This will also trigger the event loop to listen to all incoming requests and to respond
    # or publish messages.
    def create_connection(self, connection_callback):
        credentials = pika.PlainCredentials(self.connection_details.username, self.connection_details.password)

        self.connection = pika.SelectConnection(
            pika.ConnectionParameters(self.connection_details.host, self.connection_details.port,
                self.connection_details.virtual_host, credentials),
            on_open_callback=self.__connection_callback_closure(ConnectionSetupStatus.STARTED.value, connection_callback),
            on_close_callback=self.__connection_callback_closure(ConnectionSetupStatus.STOPPED.value, connection_callback),
            on_open_error_callback=self.__connection_callback_closure(ConnectionSetupStatus.ERROR.value, connection_callback)
        )
        self.connection.ioloop.start()

    # This method will begin the channel creation process. Once created, it will then proceed
    # to add channel error listeners, create the exchange, create upto two queues that have been passed,
    # bind the queues to the exchanges and listen to the returned or unroutable messages
    def create_channel(self, channel_name, channel_status_callback, confirm_publish_callback):

        # if the channel instance for the given name exists, then the channel already exists
        # simply return back since nothing needs to be processed
        channel_instance = self.__channels.get(channel_name)
        if channel_instance is not None:

            # delay execution of callback by a short interval
            # to allow the method to return and then execute the callback, simulating
            # an actual channel open scenario
            self.connection.ioloop.call_later(1, channel_status_callback, self, ChannelStatus.OPENED.value)
            return None

        channel_props = self.__all_channel_props.get(channel_name)
        if channel_props is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        channelHandler = _RabbitMqChannelImpl(self, channel_props, channel_name, channel_status_callback,
            confirm_publish_callback)
        self.connection.channel(on_open_callback=channelHandler.channel_open)

    # This method will publish the message to the queue that has been specified within the
    # channel that has been specified.
    # raises ChannelWrongNameError if the channel_name wasn't set during declaration.
    # raises NoQueueError if the queue name was not declared as per the channel configurations
    def publish_message(self, channel_name, exchange_queue_name, message, message_properties={}):
        #TODO add all properties. Create an interface for these messages
        properties=pika.BasicProperties(
            delivery_mode= 2, # make message persistent
            content_type="application/json"
        )

        channel_props = self.__all_channel_props.get(channel_name)
        if channel_props is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        channel_instance = self.__channels.get(channel_name)

        queue_found = False
        for queue_name in channel_props.queue_names:
            if queue_name == exchange_queue_name:
                queue_found = True

                #The mandatory flag will raise a returned message if the message was not routed.
                channel_instance.basic_publish(channel_props.exchange_name, queue_name,
                    json.dumps(message), properties, mandatory=True)
                break

        if queue_found != True:
            raise NoQueueError("Queue named " + exchange_queue_name + " does not exist")

    # For internal use only. This will create a closure which allows passing custom attributes,
    # to the callback that has been passed by the user.
    def __consumption_callback(self, channel_name, queue_name, callback):
        def pika_consumption_callback(channel, method, properties, body):

            # Pass the current instance so that the methods are easily accessible.
            callback(self, channel_name, queue_name, method.delivery_tag, json.loads(body))

        return pika_consumption_callback

    # This method will begin listening for incoming messages.
    # For every messages received, the callback passed by the user will be invoked.
    def consume_message(self, channel_name, exchange_queue_name, callback):
        channel_props = self.__all_channel_props.get(channel_name)
        if channel_props is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        channel_instance = self.__channels.get(channel_name)

        queue_found = False
        for queue_name in channel_props.queue_names:
            if queue_name == exchange_queue_name:
                queue_found = True

                # Save the callback and call it later
                self.__consumer_tags[queue_name] = channel_instance.basic_consume(queue_name,
                    self.__consumption_callback(channel_name, queue_name, callback))
                break

        if queue_found != True:
            raise NoQueueError("Queue named " + exchange_queue_name + " does not exist")

    # For internal use only. This will create a closure so that custom properties
    # can be passed to the callback that has been requested by the client.
    def __stop_consume_closure(self, queue_name, cancel_callback):
        def stop_handler(__unused_response_properties):

            # Remove the consumer tag from the dictionary
            self.__consumer_tags.pop(queue_name, None)
            cancel_callback(self, __unused_response_properties)
        
        return stop_handler

    # this will close the consumption that has been going on per channel.
    # This method requires two parameters to detrmine the queue that must stop
    # consuming: the channel_name and the queue_name
    # raises NoQueueError if the queue has not been consuming or if the queue
    # does not belong to the current channel.
    # raises ChannelWrongNameError, if the channel_name has not been declared.
    def stop_consume(self, channel_name, exchange_queue_name, cancel_callback):
        consumer_tag_for_channel = self.__consumer_tags.get(exchange_queue_name)
        if consumer_tag_for_channel is None:
            raise NoQueueError("Queue named " + exchange_queue_name + " does not exist")

        channel_instance = self.__channels.get(channel_name)
        if channel_instance is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        channel_props = self.__all_channel_props.get(channel_name)

        # Search for the queue in the passed channel, if they mismatch then
        # a queue belonging to a different channel has been passed for closure
        for queue_name in channel_props.queue_names:
            if queue_name == exchange_queue_name:
                queue_found = True
                break

        if queue_found != True:
            raise NoQueueError("Queue named " + exchange_queue_name + " does not exist " +
                "in channel named: " + channel_name)

        channel_instance.basic_cancel(consumer_tag_for_channel,
            self.__stop_consume_closure(exchange_queue_name, cancel_callback))

    # This method will acknowledge the given message synchronously.
    # raises ChannelWrongNameError if the supplied channel_name has not been declared.
    def basic_ack(self, delivery_tag, channel_name):
        channel_instance = self.__channels.get(channel_name)
        if channel_instance is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        channel_instance.basic_ack(delivery_tag)

    # This method will negatively acknowledge the given message synchronously.
    # This will prohibit rabbit MQ to re-queue the message.
    # raises ChannelWrongNameError if the supplied channel_name has not been declared.
    def basic_nack(self, delivery_tag, channel_name):
        channel_instance = self.__channels.get(channel_name)
        if channel_instance is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        channel_instance.basic_ack(delivery_tag, False, False)

    # This method will negatively acknowledge the given message synchronously.
    # This will allow rabbit MQ to re-queue the message for later delivery.
    # raises ChannelWrongNameError if the supplied channel_name has not been declared.
    def basic_reject(self, delivery_tag, channel_name):
        channel_instance = self.__channels.get(channel_name)
        if channel_instance is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        channel_instance.basic_reject(delivery_tag, True)

    # This method will close the channel.
    # raises ChannelWrongNameError if the supplied channel_name has not been declared.
    # raises ChannelCloseException if the channel clould not be closed either because it was
    # already closing or because it has already been closed.
    def close_channel(self, channel_name):
        channel_instance = self.__channels.get(channel_name)
        if channel_instance is None:
            raise ChannelWrongNameError("Channel named " + channel_name + " does not exist")

        try:
            channel_instance.close()
            self.__channels.pop(channel_name, None)
        except AMQPChannelError:
            raise ChannelCloseException("Channel is either closed or it is currently being closed")

    # This method will close the connection.
    # raises ConnectionCloseException if the connection is being closed or is already closed.
    def close_connection(self):
        try:

            # On closing the channel, the channel closed callback will be hit
            # this will clean up any existing channel instances that exist.
            self.connection.close()
        except AMQPConnectionError:
            raise ConnectionCloseException("Connection is either closed or it is currently being closed")
