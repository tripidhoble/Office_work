from abc import ABC, abstractmethod

class MessageQueueConnection(ABC):
    
    @abstractmethod
    def set_connection_details(self, connection_details):
        pass

    @abstractmethod
    def set_channel_exchange_properties(self, channel_exchange_props):
        pass

    @abstractmethod
    def create_connection(self, connection_callback):
        pass

    @abstractmethod
    def create_channel(self, channel_name, channel_status_callback, confirm_publish_callback):
        pass

    @abstractmethod
    def publish_message(self, channel_name, exchange_queue_name, message, message_properties={}):
        pass

    @abstractmethod
    def consume_message(self, channel_name, exchange_queue_name, callback):
        pass

    @abstractmethod
    def stop_consume(self, channel_name, exchange_queue_name, cancel_callback):
        pass

    @abstractmethod
    def basic_ack(self, delivery_tag, channel_name):
        pass

    @abstractmethod
    def basic_nack(self, delivery_tag, channel_name):
        pass

    @abstractmethod
    def basic_reject(self, delivery_tag, channel_name):
        pass

    @abstractmethod
    def close_channel(self, channel_name):
        pass

    @abstractmethod
    def close_connection(self):
        pass