from enum import Enum

ConnectionSetupStatus = Enum('ConnectionSetupStatus', {
    'STARTED': 'started',
    'ERROR': 'error',
    'STOPPED': 'stopped'
})

ChannelStatus = Enum('ChannelStatus', {
    'OPENED': 'opened',
    'ERROR': 'error',
    'CLOSED': 'closed'
})

PublishStatus = Enum('PublishStatus', {
    'ACK': 'ack',
    'NACK': 'nack',
    'RETURN': 'returned'
})