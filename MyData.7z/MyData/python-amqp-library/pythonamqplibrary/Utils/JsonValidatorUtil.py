def check_json_validity(property_dict, json_dict):
    for property, property_type in property_dict.items():
        json_property_value = json_dict.get(property)

        # The property of the custom object exists in the provided JSON object,
        # proceed to validate the type
        if json_property_value is not None:
            if isinstance(json_property_value, property_type) == False:
                raise ValueError('property: ' + property + ' must be an instance of: ' + str(property_type) + 
                    ' however, found it to be an instance of: ' + str(type(json_property_value)))