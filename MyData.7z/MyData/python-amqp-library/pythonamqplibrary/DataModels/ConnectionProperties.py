import json
from pythonamqplibrary.Utils.JsonValidatorUtil import check_json_validity

class ConnectionDetails(object):
    __properties_with_type={
        'host': str,
        'port': str,
        'virtual_host': str,
        'username': str,
        'password': str
    }

    def __init__(self, host, port, virtual_host, username, password):
        self.host = host
        self.port = port
        self.virtual_host = virtual_host
        self.username = username
        self.password = password

    def to_json(self):

        # Simply return the current values as a JSON object.
        # __dict__ is what python uses to represent keys and their values.
        return json.dumps(self.__dict__)

    @classmethod
    def from_json(cls, json_str):
        json_dict = json.loads(json_str)
        check_json_validity(cls.__properties_with_type, json_dict)
        return cls(**json_dict)