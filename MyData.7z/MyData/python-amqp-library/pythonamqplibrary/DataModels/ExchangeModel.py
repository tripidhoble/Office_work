import json
from pythonamqplibrary.Utils.JsonValidatorUtil import check_json_validity

class ExchangeDetails():
    __properties_with_type={
        'channel_name': str,
        'exchange_type': str,
        'exchange_name': str,
        'queue_names': list,
    }

    def __init__(self, channel_name, exchange_type, exchange_name, queue_names):
        self.channel_name = channel_name
        self.exchange_type = exchange_type
        self.exchange_name = exchange_name
        self.queue_names = queue_names

    def to_json(self):

        # Simply return the current values as a JSON object.
        # __dict__ is what python uses to represent keys and their values.
        return json.dumps(self.__dict__)

    @classmethod
    def from_json(cls, json_str):
        json_dict = json.loads(json_str)
        check_json_validity(cls.__properties_with_type, json_dict)
        return cls(**json_dict)
