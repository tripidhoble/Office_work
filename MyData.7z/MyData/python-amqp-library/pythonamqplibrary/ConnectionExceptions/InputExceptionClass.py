class NoQueueError(Exception):
    pass

class QueueCreationError(Exception):
    pass

class ExchangeCreationError(Exception):
    pass

class ChannelWrongNameError(Exception):
    pass