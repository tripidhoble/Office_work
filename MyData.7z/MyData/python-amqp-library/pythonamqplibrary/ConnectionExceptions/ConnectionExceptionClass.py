class ChannelCloseException(Exception):
    pass

class ConnectionCloseException(Exception):
    pass