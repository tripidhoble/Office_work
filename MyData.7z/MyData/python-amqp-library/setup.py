from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()
setup(
     name='pythonamqplibrary',
     version='0.1',
     author="Capgemini",
     author_email="vishal.chauhan@capgemini.com",
     description="AMQB library for jarvis",
     long_description=long_description,
   long_description_content_type="text/markdown",
     url="http://10.207.148.100/Jarvis_Repo/python-amqp-library",
     packages= find_packages(),
     classifiers=[
         "Programming Language :: Python :: 3",
         "License :: OSI Approved :: MIT License",
         "Operating System :: OS Independent",
     ],
 )