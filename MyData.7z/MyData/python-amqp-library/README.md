FOR CREATING PACKAGE
python setup.py sdist bdist_wheel

FOR INSTALLING PACKAGE
python -m pip install pythonamqplibrary-0.1-py3-none-any.whl